"""Book hold queues, priority waitlists, notifications, and hold expiry."""

from datetime import timedelta
from typing import Dict, List, Optional

from library_management.catalog import CatalogService
from library_management.exceptions import (
    ActiveReservationExistsError,
    ReservationLimitExceededError,
    ReservationNotFoundError,
    ValidationError,
)
from library_management.member import MemberService
from library_management.models import BookStatus, Reservation, ReservationStatus
from library_management.utils import Clock, IdGenerator

MAX_ACTIVE_RESERVATIONS_PER_MEMBER = 3
HOLD_PICKUP_WINDOW_DAYS = 3


class ReservationService:
    """Manages hold queues, priority sequence, hold fulfillment, and expiration."""

    def __init__(
        self,
        member_service: MemberService,
        catalog_service: CatalogService,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.member_service = member_service
        self.catalog_service = catalog_service
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._reservations: Dict[str, Reservation] = {}
        self._book_waitlist: Dict[str, List[str]] = {}  # book_id -> list of reservation_ids in FIFO order

    def reserve_book(self, member_id: str, book_id: str) -> Reservation:
        """Places member on waitlist for a currently unavailable book."""
        self.member_service.validate_member_in_good_standing(member_id)
        book = self.catalog_service.get_book(book_id)

        if book.is_reference_only:
            raise ValidationError("Reference-only books cannot be reserved.")

        # Check member's active reservations limit
        active_res = self.get_active_reservations_for_member(member_id)
        if len(active_res) >= MAX_ACTIVE_RESERVATIONS_PER_MEMBER:
            raise ReservationLimitExceededError(member_id, MAX_ACTIVE_RESERVATIONS_PER_MEMBER)

        # Check duplicate active reservation
        for res in active_res:
            if res.book_id == book_id and res.status in (
                ReservationStatus.PENDING,
                ReservationStatus.READY_FOR_PICKUP,
            ):
                raise ActiveReservationExistsError(member_id, book_id)

        res_id = self.id_gen.generate("RES")
        now = self.clock.now()

        reservation = Reservation(
            reservation_id=res_id,
            member_id=member_id,
            book_id=book_id,
            requested_at=now,
            status=ReservationStatus.PENDING,
        )

        self._reservations[res_id] = reservation
        if book_id not in self._book_waitlist:
            self._book_waitlist[book_id] = []
        self._book_waitlist[book_id].append(res_id)

        return reservation

    def cancel_reservation(self, reservation_id: str) -> Reservation:
        """Cancels a pending or ready reservation."""
        res = self.get_reservation(reservation_id)
        if res.status not in (ReservationStatus.PENDING, ReservationStatus.READY_FOR_PICKUP):
            raise ValidationError(f"Cannot cancel reservation with status '{res.status.value}'.")

        res.status = ReservationStatus.CANCELLED
        res.cancelled_at = self.clock.now()

        # If a copy was reserved for pickup, free it back to available
        if res.assigned_barcode:
            self.catalog_service.update_copy_status(res.assigned_barcode, BookStatus.AVAILABLE)
            res.assigned_barcode = None

        if res.book_id in self._book_waitlist and reservation_id in self._book_waitlist[res.book_id]:
            self._book_waitlist[res.book_id].remove(reservation_id)

        return res

    def process_returned_copy_for_holds(self, book_id: str, barcode: str) -> Optional[Reservation]:
        """Checks waitlist when a copy is returned; allocates it to the next queued member."""
        waitlist = self._book_waitlist.get(book_id, [])
        while waitlist:
            next_res_id = waitlist[0]
            res = self._reservations.get(next_res_id)
            if not res or res.status != ReservationStatus.PENDING:
                waitlist.pop(0)
                continue

            # Assign copy for pickup
            now = self.clock.now()
            res.status = ReservationStatus.READY_FOR_PICKUP
            res.assigned_barcode = barcode
            res.pickup_deadline = now + timedelta(days=HOLD_PICKUP_WINDOW_DAYS)

            self.catalog_service.update_copy_status(barcode, BookStatus.RESERVED)
            return res

        return None

    def fulfill_reservation(self, reservation_id: str) -> Reservation:
        """Marks hold fulfilled upon member checking out the held copy."""
        res = self.get_reservation(reservation_id)
        if res.status != ReservationStatus.READY_FOR_PICKUP:
            raise ValidationError("Reservation is not ready for pickup.")

        res.status = ReservationStatus.FULFILLED
        res.fulfilled_at = self.clock.now()

        if res.book_id in self._book_waitlist and reservation_id in self._book_waitlist[res.book_id]:
            self._book_waitlist[res.book_id].remove(reservation_id)

        return res

    def check_expired_holds(self) -> List[Reservation]:
        """Identifies holds whose pickup window expired and returns copies to pool."""
        now = self.clock.now()
        expired: List[Reservation] = []

        for res in self._reservations.values():
            if res.status == ReservationStatus.READY_FOR_PICKUP:
                if res.pickup_deadline and now > res.pickup_deadline:
                    res.status = ReservationStatus.EXPIRED
                    if res.assigned_barcode:
                        self.catalog_service.update_copy_status(res.assigned_barcode, BookStatus.AVAILABLE)
                        res.assigned_barcode = None
                    if res.book_id in self._book_waitlist and res.reservation_id in self._book_waitlist[res.book_id]:
                        self._book_waitlist[res.book_id].remove(res.reservation_id)
                    expired.append(res)

        return expired

    def get_reservation(self, reservation_id: str) -> Reservation:
        """Retrieves reservation by ID."""
        if reservation_id not in self._reservations:
            raise ReservationNotFoundError(reservation_id)
        return self._reservations[reservation_id]

    def get_active_reservations_for_member(self, member_id: str) -> List[Reservation]:
        """Lists active reservations for member."""
        return [
            r for r in self._reservations.values()
            if r.member_id == member_id and r.status in (ReservationStatus.PENDING, ReservationStatus.READY_FOR_PICKUP)
        ]

