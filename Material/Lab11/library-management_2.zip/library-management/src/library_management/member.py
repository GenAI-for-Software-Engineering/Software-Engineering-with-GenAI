"""Member registration, tiers, expiry, suspension, and account balances."""

from datetime import timedelta
from decimal import Decimal
from typing import Dict, List, Optional

from library_management.exceptions import (
    DuplicateMemberError,
    InsufficientBalanceError,
    MemberExpiredError,
    MemberNotFoundError,
    MemberSuspendedError,
    ValidationError,
)
from library_management.models import Member, MemberStatus, MembershipType
from library_management.utils import (
    Clock,
    IdGenerator,
    round_currency,
    validate_email,
    validate_phone,
)

# Membership duration in days
MEMBERSHIP_VALIDITY_DAYS = {
    MembershipType.STUDENT: 180,      # 1 semester / 6 months
    MembershipType.FACULTY: 365,      # 1 year
    MembershipType.PUBLIC: 90,        # 3 months
    MembershipType.RESEARCHER: 365,   # 1 year
}

# Maximum active concurrent book loans per tier
MEMBERSHIP_LOAN_LIMITS = {
    MembershipType.STUDENT: 4,
    MembershipType.FACULTY: 10,
    MembershipType.PUBLIC: 2,
    MembershipType.RESEARCHER: 8,
}

# Loan duration in days per tier
MEMBERSHIP_LOAN_PERIOD_DAYS = {
    MembershipType.STUDENT: 14,
    MembershipType.FACULTY: 30,
    MembershipType.PUBLIC: 7,
    MembershipType.RESEARCHER: 21,
}

# Max renewals allowed
MEMBERSHIP_MAX_RENEWALS = {
    MembershipType.STUDENT: 2,
    MembershipType.FACULTY: 5,
    MembershipType.PUBLIC: 1,
    MembershipType.RESEARCHER: 3,
}

# Outstanding fine threshold blocking new loans
FINE_BLOCKING_THRESHOLD = Decimal("100.00")


class MemberService:
    """Manages member registration, profiles, membership validity, and prepaid account."""

    def __init__(self, clock: Optional[Clock] = None, id_gen: Optional[IdGenerator] = None):
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._members: Dict[str, Member] = {}
        self._email_index: Dict[str, str] = {}
        self._card_index: Dict[str, str] = {}

    def register_member(
        self,
        name: str,
        email: str,
        phone: str,
        membership_type: MembershipType,
        initial_balance: Decimal = Decimal("0.00"),
    ) -> Member:
        """Registers a new library member."""
        if not name or not name.strip():
            raise ValidationError("Member name cannot be empty.")

        clean_email = validate_email(email)
        clean_phone = validate_phone(phone)

        if clean_email in self._email_index:
            raise DuplicateMemberError(f"Email '{clean_email}'")

        if initial_balance < Decimal("0.00"):
            raise ValidationError("Initial balance cannot be negative.")

        member_id = self.id_gen.generate("MEM")
        card_number = self.id_gen.generate("CRD")

        now = self.clock.now()
        validity_days = MEMBERSHIP_VALIDITY_DAYS[membership_type]
        expires_at = now + timedelta(days=validity_days)

        member = Member(
            member_id=member_id,
            name=name.strip(),
            email=clean_email,
            phone=clean_phone,
            membership_type=membership_type,
            status=MemberStatus.ACTIVE,
            card_number=card_number,
            account_balance=round_currency(initial_balance),
            created_at=now,
            expires_at=expires_at,
        )

        self._members[member_id] = member
        self._email_index[clean_email] = member_id
        self._card_index[card_number] = member_id
        return member

    def get_member(self, member_id: str) -> Member:
        """Retrieves member by ID."""
        if member_id not in self._members:
            raise MemberNotFoundError(member_id)
        return self._members[member_id]

    def get_member_by_card(self, card_number: str) -> Member:
        """Retrieves member by card number."""
        clean_card = card_number.strip()
        member_id = self._card_index.get(clean_card)
        if not member_id:
            raise MemberNotFoundError(f"card={clean_card}")
        return self._members[member_id]

    def validate_member_in_good_standing(self, member_id: str) -> Member:
        """Verifies member is active and membership has not expired."""
        member = self.get_member(member_id)

        if member.status == MemberStatus.SUSPENDED:
            raise MemberSuspendedError(member_id, "Account is currently suspended.")
        if member.status == MemberStatus.DEACTIVATED:
            raise MemberSuspendedError(member_id, "Account is deactivated.")

        now = self.clock.now()
        if member.expires_at and now > member.expires_at:
            member.status = MemberStatus.EXPIRED
            raise MemberExpiredError(member_id)

        return member

    def suspend_member(self, member_id: str, reason: str = "") -> Member:
        """Suspends member privileges."""
        member = self.get_member(member_id)
        member.status = MemberStatus.SUSPENDED
        return member

    def reactivate_member(self, member_id: str) -> Member:
        """Reactivates suspended or expired member."""
        member = self.get_member(member_id)
        member.status = MemberStatus.ACTIVE
        # Extend validity if expired
        now = self.clock.now()
        if member.expires_at and now >= member.expires_at:
            validity_days = MEMBERSHIP_VALIDITY_DAYS[member.membership_type]
            member.expires_at = now + timedelta(days=validity_days)
        return member

    def add_account_funds(self, member_id: str, amount: Decimal) -> Decimal:
        """Adds prepaid funds to member's account."""
        member = self.get_member(member_id)
        if amount <= Decimal("0.00"):
            raise ValidationError("Deposit amount must be positive.")
        member.account_balance = round_currency(member.account_balance + amount)
        return member.account_balance

    def deduct_account_funds(self, member_id: str, amount: Decimal) -> Decimal:
        """Deducts prepaid balance."""
        member = self.get_member(member_id)
        if amount <= Decimal("0.00"):
            raise ValidationError("Deduct amount must be positive.")
        amount = round_currency(amount)
        if member.account_balance < amount:
            raise InsufficientBalanceError(required=str(amount), available=str(member.account_balance))
        member.account_balance = round_currency(member.account_balance - amount)
        return member.account_balance

    def list_members(self) -> List[Member]:
        """Returns all registered members."""
        return list(self._members.values())

