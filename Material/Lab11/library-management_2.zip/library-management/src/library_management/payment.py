"""Fine payment processing, mockable payment gateway, and transaction ledger."""

from abc import ABC, abstractmethod
from decimal import Decimal
from typing import Dict, List, Optional

from library_management.exceptions import (
    DuplicatePaymentError,
    PaymentFailedError,
    ValidationError,
)
from library_management.fine import FineService
from library_management.member import MemberService
from library_management.models import PaymentMethod, PaymentStatus, Transaction
from library_management.utils import Clock, IdGenerator, round_currency


class PaymentGateway(ABC):
    """Abstract interface for third-party payment gateways."""

    @abstractmethod
    def charge(self, transaction_id: str, amount: Decimal, metadata: Dict[str, str]) -> bool:
        """Processes payment charge."""
        pass

    @abstractmethod
    def refund(self, original_ref: str, amount: Decimal) -> bool:
        """Processes refund."""
        pass


class MockPaymentGateway(PaymentGateway):
    """Mock gateway implementation with controllable failure simulation."""

    def __init__(self, default_success: bool = True):
        self.default_success = default_success
        self.failure_triggers: Dict[str, str] = {}
        self.processed_ids: List[str] = []

    def set_failure_trigger(self, trigger_key: str, reason: str) -> None:
        """Registers a key that forces decline when present."""
        self.failure_triggers[trigger_key] = reason

    def charge(self, transaction_id: str, amount: Decimal, metadata: Dict[str, str]) -> bool:
        """Simulates transaction charge."""
        self.processed_ids.append(transaction_id)
        for key in self.failure_triggers:
            if key in metadata or key in metadata.values():
                return False
        return self.default_success

    def refund(self, original_ref: str, amount: Decimal) -> bool:
        """Simulates refund."""
        if "FAIL_REFUND" in original_ref:
            return False
        return True


class PaymentService:
    """Handles payments for overdue fines, lost book fees, and ledger accounting."""

    def __init__(
        self,
        fine_service: FineService,
        member_service: MemberService,
        gateway: Optional[PaymentGateway] = None,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.fine_service = fine_service
        self.member_service = member_service
        self.gateway = gateway or MockPaymentGateway()
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._transactions: Dict[str, Transaction] = {}
        self._fine_transaction_map: Dict[str, List[str]] = {}

    def pay_fine(
        self,
        fine_id: str,
        amount: Decimal,
        payment_method: PaymentMethod,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Transaction:
        """Settles fine balance using prepaid account, cash, card, or UPI."""
        fine = self.fine_service.get_fine(fine_id)

        if fine.is_paid:
            raise DuplicatePaymentError(fine_id)

        remaining_due = fine.amount - fine.paid_amount
        pay_amount = round_currency(amount)

        if pay_amount <= Decimal("0.00") or pay_amount > remaining_due:
            raise ValidationError(
                f"Payment amount ({pay_amount}) must be between 0.01 and remaining due ({remaining_due})."
            )

        tx_id = self.id_gen.generate("TXN")
        now = self.clock.now()
        meta = metadata or {}

        # 1. Prepaid library account method
        if payment_method == PaymentMethod.LIBRARY_ACCOUNT:
            self.member_service.deduct_account_funds(fine.member_id, pay_amount)
            fine.paid_amount = round_currency(fine.paid_amount + pay_amount)
            if fine.paid_amount == fine.amount:
                fine.is_paid = True
                fine.paid_at = now

            tx = Transaction(
                transaction_id=tx_id,
                fine_id=fine_id,
                member_id=fine.member_id,
                amount=pay_amount,
                payment_method=payment_method,
                status=PaymentStatus.COMPLETED,
                created_at=now,
                gateway_reference=f"ACC-DEBIT-{tx_id}",
                notes="Paid from library account",
            )
            self._record_transaction(tx)
            return tx

        # 2. Cash method
        if payment_method == PaymentMethod.CASH:
            fine.paid_amount = round_currency(fine.paid_amount + pay_amount)
            if fine.paid_amount == fine.amount:
                fine.is_paid = True
                fine.paid_at = now

            tx = Transaction(
                transaction_id=tx_id,
                fine_id=fine_id,
                member_id=fine.member_id,
                amount=pay_amount,
                payment_method=payment_method,
                status=PaymentStatus.COMPLETED,
                created_at=now,
                gateway_reference="CASH-DESK",
                notes="Cash collected at front desk",
            )
            self._record_transaction(tx)
            return tx

        # 3. Card or UPI via gateway
        success = self.gateway.charge(tx_id, pay_amount, meta)
        if not success:
            tx = Transaction(
                transaction_id=tx_id,
                fine_id=fine_id,
                member_id=fine.member_id,
                amount=pay_amount,
                payment_method=payment_method,
                status=PaymentStatus.FAILED,
                created_at=now,
                notes="Gateway rejected payment",
            )
            self._record_transaction(tx)
            raise PaymentFailedError("Payment gateway declined transaction.")

        fine.paid_amount = round_currency(fine.paid_amount + pay_amount)
        if fine.paid_amount == fine.amount:
            fine.is_paid = True
            fine.paid_at = now

        tx = Transaction(
            transaction_id=tx_id,
            fine_id=fine_id,
            member_id=fine.member_id,
            amount=pay_amount,
            payment_method=payment_method,
            status=PaymentStatus.COMPLETED,
            created_at=now,
            gateway_reference=f"GW-{tx_id}",
            notes="Gateway payment settled",
        )
        self._record_transaction(tx)
        return tx

    def _record_transaction(self, tx: Transaction) -> None:
        """Internal ledger record storage."""
        self._transactions[tx.transaction_id] = tx
        if tx.fine_id:
            if tx.fine_id not in self._fine_transaction_map:
                self._fine_transaction_map[tx.fine_id] = []
            self._fine_transaction_map[tx.fine_id].append(tx.transaction_id)

    def get_transaction(self, transaction_id: str) -> Transaction:
        """Retrieves transaction by ID."""
        if transaction_id not in self._transactions:
            raise ValidationError(f"Transaction '{transaction_id}' not found.")
        return self._transactions[transaction_id]

    def list_member_transactions(self, member_id: str) -> List[Transaction]:
        """Lists transactions for a member."""
        return [t for t in self._transactions.values() if t.member_id == member_id]

