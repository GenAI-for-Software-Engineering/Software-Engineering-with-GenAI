"""Custom exceptions for the Library Management System."""


class LibraryManagementError(Exception):
    """Base exception for all domain errors in Library Management System."""

    def __init__(self, message: str, code: str = "LMS_ERROR"):
        super().__init__(message)
        self.message = message
        self.code = code

    def __str__(self) -> str:
        return f"[{self.code}] {self.message}"


class ValidationError(LibraryManagementError):
    """Raised when an input or parameter fails validation rules."""

    def __init__(self, message: str):
        super().__init__(message, code="VALIDATION_ERROR")


class MemberNotFoundError(LibraryManagementError):
    """Raised when requested member cannot be found."""

    def __init__(self, member_id: str):
        super().__init__(f"Member '{member_id}' not found.", code="MEMBER_NOT_FOUND")


class DuplicateMemberError(LibraryManagementError):
    """Raised when registering an already existing member."""

    def __init__(self, identifier: str):
        super().__init__(f"Member already exists with identifier: {identifier}", code="DUPLICATE_MEMBER")


class MemberSuspendedError(LibraryManagementError):
    """Raised when a suspended member attempts an unauthorized operation."""

    def __init__(self, member_id: str, reason: str = ""):
        super().__init__(
            f"Member '{member_id}' is suspended. {reason}".strip(),
            code="MEMBER_SUSPENDED",
        )


class MemberExpiredError(LibraryManagementError):
    """Raised when a member's card or membership has expired."""

    def __init__(self, member_id: str):
        super().__init__(f"Membership for member '{member_id}' has expired.", code="MEMBERSHIP_EXPIRED")


class BookNotFoundError(LibraryManagementError):
    """Raised when requested book cannot be found."""

    def __init__(self, book_id: str):
        super().__init__(f"Book '{book_id}' not found.", code="BOOK_NOT_FOUND")


class DuplicateBookError(LibraryManagementError):
    """Raised when adding a book with an already existing ISBN."""

    def __init__(self, isbn: str):
        super().__init__(f"Book with ISBN '{isbn}' already exists in catalog.", code="DUPLICATE_BOOK")


class BookCopyNotFoundError(LibraryManagementError):
    """Raised when a specific copy of a book cannot be found."""

    def __init__(self, barcode: str):
        super().__init__(f"Book copy with barcode '{barcode}' not found.", code="COPY_NOT_FOUND")


class BookNotAvailableError(LibraryManagementError):
    """Raised when no copies of a book are available for checkout."""

    def __init__(self, book_id: str):
        super().__init__(f"No available copies for book '{book_id}'.", code="BOOK_NOT_AVAILABLE")


class ReferenceOnlyBookError(LibraryManagementError):
    """Raised when a member tries to checkout a reference-only book."""

    def __init__(self, book_id: str):
        super().__init__(f"Book '{book_id}' is reference-only and cannot be borrowed.", code="REFERENCE_ONLY")


class LoanLimitExceededError(LibraryManagementError):
    """Raised when a member exceeds the maximum allowed borrowed books."""

    def __init__(self, member_id: str, limit: int):
        super().__init__(
            f"Member '{member_id}' has reached the maximum borrowing limit of {limit} books.",
            code="LOAN_LIMIT_EXCEEDED",
        )


class OutstandingFinesBlockError(LibraryManagementError):
    """Raised when outstanding unpaid fines block new loans or renewals."""

    def __init__(self, member_id: str, total_fine: str, threshold: str):
        super().__init__(
            f"Member '{member_id}' has unpaid fines of {total_fine}, exceeding threshold {threshold}.",
            code="OUTSTANDING_FINES_BLOCK",
        )


class LoanNotFoundError(LibraryManagementError):
    """Raised when a loan record does not exist."""

    def __init__(self, loan_id: str):
        super().__init__(f"Loan record '{loan_id}' not found.", code="LOAN_NOT_FOUND")


class RenewalLimitExceededError(LibraryManagementError):
    """Raised when a book loan has reached its maximum renewal count."""

    def __init__(self, loan_id: str, max_renewals: int):
        super().__init__(
            f"Loan '{loan_id}' has already reached the maximum renewal limit of {max_renewals}.",
            code="RENEWAL_LIMIT_EXCEEDED",
        )


class ReservationNotFoundError(LibraryManagementError):
    """Raised when reservation record cannot be found."""

    def __init__(self, reservation_id: str):
        super().__init__(f"Reservation '{reservation_id}' not found.", code="RESERVATION_NOT_FOUND")


class ActiveReservationExistsError(LibraryManagementError):
    """Raised when member already has an active reservation for the book."""

    def __init__(self, member_id: str, book_id: str):
        super().__init__(
            f"Member '{member_id}' already has an active reservation for book '{book_id}'.",
            code="ACTIVE_RESERVATION_EXISTS",
        )


class ReservationLimitExceededError(LibraryManagementError):
    """Raised when member exceeds allowed active reservations."""

    def __init__(self, member_id: str, limit: int):
        super().__init__(
            f"Member '{member_id}' has reached max active reservation limit of {limit}.",
            code="RESERVATION_LIMIT_EXCEEDED",
        )


class PaymentFailedError(LibraryManagementError):
    """Raised when fine payment processing fails."""

    def __init__(self, reason: str):
        super().__init__(f"Payment failed: {reason}", code="PAYMENT_FAILED")


class DuplicatePaymentError(LibraryManagementError):
    """Raised when paying for an already settled fine."""

    def __init__(self, fine_id: str):
        super().__init__(f"Fine '{fine_id}' is already fully paid.", code="DUPLICATE_PAYMENT")


class InsufficientBalanceError(LibraryManagementError):
    """Raised when member's prepaid library account has insufficient balance."""

    def __init__(self, required: str, available: str):
        super().__init__(
            f"Insufficient account balance: required {required}, available {available}.",
            code="INSUFFICIENT_BALANCE",
        )

