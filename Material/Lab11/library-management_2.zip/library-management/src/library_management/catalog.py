"""Book catalog management, copies, search, and rack locations."""

from datetime import date
from decimal import Decimal
from typing import Dict, List, Optional

from library_management.exceptions import (
    BookCopyNotFoundError,
    BookNotFoundError,
    DuplicateBookError,
    ValidationError,
)
from library_management.models import Book, BookCopy, BookFormat, BookStatus
from library_management.utils import Clock, IdGenerator, validate_isbn


class CatalogService:
    """Manages library book inventory, physical copies, and search indexing."""

    def __init__(self, clock: Optional[Clock] = None, id_gen: Optional[IdGenerator] = None):
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._books: Dict[str, Book] = {}
        self._isbn_index: Dict[str, str] = {}
        self._copy_index: Dict[str, BookCopy] = {}

    def add_book(
        self,
        isbn: str,
        title: str,
        author: str,
        publisher: str,
        publication_year: int,
        category: str,
        format: BookFormat = BookFormat.PAPERBACK,
        is_reference_only: bool = False,
        price: Decimal = Decimal("500.00"),
    ) -> Book:
        """Adds a new title to the library catalog."""
        clean_isbn = validate_isbn(isbn)
        if clean_isbn in self._isbn_index:
            raise DuplicateBookError(clean_isbn)

        if not title or not title.strip():
            raise ValidationError("Book title cannot be empty.")
        if not author or not author.strip():
            raise ValidationError("Author cannot be empty.")
        if publication_year < 1450 or publication_year > self.clock.now().year + 1:
            raise ValidationError(f"Invalid publication year: {publication_year}.")
        if price <= Decimal("0.00"):
            raise ValidationError("Book price must be positive.")

        book_id = self.id_gen.generate("BOK")
        book = Book(
            book_id=book_id,
            isbn=clean_isbn,
            title=title.strip(),
            author=author.strip(),
            publisher=publisher.strip(),
            publication_year=publication_year,
            category=category.strip(),
            format=format,
            is_reference_only=is_reference_only,
            price=price,
            copies=[],
        )

        self._books[book_id] = book
        self._isbn_index[clean_isbn] = book_id
        return book

    def add_copy(
        self,
        book_id: str,
        rack_location: str,
        barcode: Optional[str] = None,
        acquisition_date: Optional[date] = None,
    ) -> BookCopy:
        """Adds a physical copy with unique barcode to a cataloged book."""
        book = self.get_book(book_id)

        raw_barcode = barcode if barcode else self.id_gen.generate("BC")
        clean_barcode = raw_barcode.strip().upper()
        if clean_barcode in self._copy_index:
            raise ValidationError(f"Barcode '{clean_barcode}' already exists.")

        if not rack_location or not rack_location.strip():
            raise ValidationError("Rack location is required.")

        copy = BookCopy(
            barcode=clean_barcode,
            book_id=book_id,
            rack_location=rack_location.strip(),
            status=BookStatus.AVAILABLE,
            acquisition_date=acquisition_date or self.clock.now().date(),
        )

        book.copies.append(copy)
        self._copy_index[clean_barcode] = copy
        return copy

    def get_book(self, book_id: str) -> Book:
        """Retrieves book by ID."""
        if book_id not in self._books:
            raise BookNotFoundError(book_id)
        return self._books[book_id]

    def get_book_by_isbn(self, isbn: str) -> Book:
        """Retrieves book by ISBN."""
        clean_isbn = validate_isbn(isbn)
        book_id = self._isbn_index.get(clean_isbn)
        if not book_id:
            raise BookNotFoundError(f"isbn={clean_isbn}")
        return self._books[book_id]

    def get_copy(self, barcode: str) -> BookCopy:
        """Retrieves specific copy by barcode."""
        clean_barcode = barcode.strip().upper()
        if clean_barcode not in self._copy_index:
            raise BookCopyNotFoundError(clean_barcode)
        return self._copy_index[clean_barcode]

    def update_copy_status(self, barcode: str, status: BookStatus) -> BookCopy:
        """Updates availability or physical status of a copy."""
        copy = self.get_copy(barcode)
        copy.status = status
        return copy

    def search_books(
        self,
        query: Optional[str] = None,
        category: Optional[str] = None,
        author: Optional[str] = None,
    ) -> List[Book]:
        """Multi-criteria search over title, author, and category."""
        results = list(self._books.values())

        if query:
            q = query.strip().lower()
            results = [b for b in results if q in b.title.lower() or q in b.author.lower() or q in b.isbn]

        if category:
            cat = category.strip().lower()
            results = [b for b in results if b.category.lower() == cat]

        if author:
            auth = author.strip().lower()
            results = [b for b in results if auth in b.author.lower()]

        return results

    def get_available_copy(self, book_id: str) -> Optional[BookCopy]:
        """Finds first available copy of a book."""
        book = self.get_book(book_id)
        for copy in book.copies:
            if copy.status == BookStatus.AVAILABLE:
                return copy
        return None

    def list_books(self) -> List[Book]:
        """Lists all cataloged books."""
        return list(self._books.values())
