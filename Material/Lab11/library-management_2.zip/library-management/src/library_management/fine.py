"""Overdue fine calculation, grace periods, lost book charges, and waivers."""

from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional

from library_management.exceptions import ValidationError
from library_management.models import FineRecord, Loan, MembershipType
from library_management.utils import Clock, IdGenerator, round_currency

# Daily overdue rate in INR per tier
DAILY_OVERDUE_FINE_RATE = {
    MembershipType.STUDENT: Decimal("2.00"),
    MembershipType.FACULTY: Decimal("1.00"),
    MembershipType.PUBLIC: Decimal("5.00"),
    MembershipType.RESEARCHER: Decimal("2.00"),
}

# Grace period in days before fines start accumulating
GRACE_PERIOD_DAYS = 2

# Processing fee for lost book replacement
LOST_BOOK_PROCESSING_FEE = Decimal("100.00")

# Maximum fine cap per loan (to avoid astronomical debts)
MAX_FINE_PER_LOAN = Decimal("500.00")


class FineService:
    """Computes overdue fines, damages, lost replacement charges, and waivers."""

    def __init__(self, clock: Optional[Clock] = None, id_gen: Optional[IdGenerator] = None):
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._fines: Dict[str, FineRecord] = {}
        self._member_fines: Dict[str, List[str]] = {}

    def calculate_overdue_fine(
        self,
        due_date: datetime,
        return_date: datetime,
        membership_type: MembershipType,
    ) -> Decimal:
        """Calculates fine for late return with grace period and capping."""
        if return_date <= due_date:
            return Decimal("0.00")

        # Elapsed days overdue
        delta = return_date - due_date
        overdue_days = delta.days
        if delta.seconds > 0 and overdue_days == 0:
            overdue_days = 1

        chargeable_days = max(0, overdue_days - GRACE_PERIOD_DAYS)
        if chargeable_days == 0:
            return Decimal("0.00")

        daily_rate = DAILY_OVERDUE_FINE_RATE[membership_type]
        calculated_fine = Decimal(str(chargeable_days)) * daily_rate
        actual_fine = min(calculated_fine, MAX_FINE_PER_LOAN)
        return round_currency(actual_fine)

    def assess_fine(
        self,
        member_id: str,
        amount: Decimal,
        reason: str,
        loan_id: Optional[str] = None,
    ) -> FineRecord:
        """Records an outstanding fine for a member."""
        if amount <= Decimal("0.00"):
            raise ValidationError("Fine amount must be greater than zero.")

        fine_id = self.id_gen.generate("FIN")
        fine = FineRecord(
            fine_id=fine_id,
            loan_id=loan_id,
            member_id=member_id,
            amount=round_currency(amount),
            paid_amount=Decimal("0.00"),
            is_paid=False,
            reason=reason.strip(),
            assessed_at=self.clock.now(),
        )

        self._fines[fine_id] = fine
        if member_id not in self._member_fines:
            self._member_fines[member_id] = []
        self._member_fines[member_id].append(fine_id)
        return fine

    def calculate_lost_book_charge(self, book_price: Decimal) -> Decimal:
        """Calculates replacement charge for lost book: full book price + processing fee."""
        if book_price <= Decimal("0.00"):
            raise ValidationError("Book price must be positive.")
        return round_currency(book_price + LOST_BOOK_PROCESSING_FEE)

    def waive_fine(self, fine_id: str, waived_amount: Decimal, reason: str = "") -> FineRecord:
        """Allows authorized staff to partially or fully waive an outstanding fine."""
        if fine_id not in self._fines:
            raise ValidationError(f"Fine '{fine_id}' not found.")

        fine = self._fines[fine_id]
        if fine.is_paid:
            raise ValidationError("Cannot waive an already settled fine.")

        remaining = fine.amount - fine.paid_amount
        if waived_amount <= Decimal("0.00") or waived_amount > remaining:
            raise ValidationError(f"Waived amount ({waived_amount}) must be between 0 and remaining {remaining}.")

        fine.amount = round_currency(fine.amount - waived_amount)
        if fine.amount == fine.paid_amount:
            fine.is_paid = True
            fine.paid_at = self.clock.now()

        fine.reason += f" [Waived: {waived_amount} - {reason}]"
        return fine

    def get_fine(self, fine_id: str) -> FineRecord:
        """Retrieves fine record by ID."""
        if fine_id not in self._fines:
            raise ValidationError(f"Fine '{fine_id}' not found.")
        return self._fines[fine_id]

    def get_unpaid_fines_for_member(self, member_id: str) -> List[FineRecord]:
        """Retrieves all unpaid fines for a member."""
        fine_ids = self._member_fines.get(member_id, [])
        return [self._fines[fid] for fid in fine_ids if not self._fines[fid].is_paid]

    def get_total_outstanding_fines(self, member_id: str) -> Decimal:
        """Sums unpaid fine balances for a member."""
        unpaid = self.get_unpaid_fines_for_member(member_id)
        total = sum((f.amount - f.paid_amount) for f in unpaid)
        return round_currency(Decimal(str(total)))

