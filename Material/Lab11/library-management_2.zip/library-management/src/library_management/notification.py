"""Notification service with mockable email and SMS dispatch channels."""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional

from library_management.exceptions import ValidationError
from library_management.models import NotificationMessage
from library_management.utils import Clock, IdGenerator


class NotificationChannel(ABC):
    """Abstract interface for delivery channels."""

    @abstractmethod
    def send(self, recipient: str, subject: str, message: str) -> bool:
        """Sends notification payload."""
        pass


class MockEmailService(NotificationChannel):
    """Mock Email channel capturing dispatched notices."""

    def __init__(self, should_succeed: bool = True):
        self.should_succeed = should_succeed
        self.sent_messages: List[Dict[str, str]] = []

    def send(self, recipient: str, subject: str, message: str) -> bool:
        """Simulates email delivery."""
        if not self.should_succeed or "fail" in recipient.lower():
            return False
        self.sent_messages.append({"recipient": recipient, "subject": subject, "body": message})
        return True


class MockSmsService(NotificationChannel):
    """Mock SMS channel capturing dispatched text alerts."""

    def __init__(self, should_succeed: bool = True):
        self.should_succeed = should_succeed
        self.sent_messages: List[Dict[str, str]] = []

    def send(self, recipient: str, subject: str, message: str) -> bool:
        """Simulates SMS delivery."""
        if not self.should_succeed or "fail" in recipient.lower():
            return False
        self.sent_messages.append({"recipient": recipient, "subject": subject, "body": message})
        return True


class NotificationService:
    """Dispatches notifications for checkouts, due date reminders, holds, and fines."""

    def __init__(
        self,
        email_channel: Optional[NotificationChannel] = None,
        sms_channel: Optional[NotificationChannel] = None,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.email_channel = email_channel or MockEmailService()
        self.sms_channel = sms_channel or MockSmsService()
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._history: List[NotificationMessage] = []

    def notify(
        self,
        recipient_id: str,
        contact_point: str,
        channel: str,
        subject: str,
        body: str,
    ) -> NotificationMessage:
        """Dispatches an alert through specified channel."""
        if not recipient_id or not contact_point or not body:
            raise ValidationError("Recipient ID, contact point, and body cannot be empty.")

        ch_upper = channel.strip().upper()
        if ch_upper == "EMAIL":
            success = self.email_channel.send(contact_point, subject, body)
        elif ch_upper == "SMS":
            success = self.sms_channel.send(contact_point, subject, body)
        else:
            raise ValidationError(f"Unsupported notification channel: '{channel}'.")

        msg = NotificationMessage(
            notification_id=self.id_gen.generate("NOTIF"),
            recipient_id=recipient_id,
            channel=ch_upper,
            subject=subject,
            body=body,
            sent_at=self.clock.now(),
            success=success,
        )
        self._history.append(msg)
        return msg

    def notify_checkout(
        self,
        member_id: str,
        email: str,
        book_title: str,
        due_date_str: str,
    ) -> NotificationMessage:
        """Sends loan confirmation notice."""
        return self.notify(
            recipient_id=member_id,
            contact_point=email,
            channel="EMAIL",
            subject="Book Checkout Confirmation",
            body=f"You borrowed '{book_title}'. Return due date is {due_date_str}.",
        )

    def notify_hold_ready(
        self,
        member_id: str,
        phone: str,
        book_title: str,
        deadline_str: str,
    ) -> NotificationMessage:
        """Sends SMS alert that reserved book is ready for pickup."""
        return self.notify(
            recipient_id=member_id,
            contact_point=phone,
            channel="SMS",
            subject="Hold Ready for Pickup",
            body=f"'{book_title}' is ready for pickup at circulation desk until {deadline_str}.",
        )

    def notify_overdue(
        self,
        member_id: str,
        email: str,
        book_title: str,
        fine_amount: str,
    ) -> NotificationMessage:
        """Sends overdue notice with current accumulated fine."""
        return self.notify(
            recipient_id=member_id,
            contact_point=email,
            channel="EMAIL",
            subject="Overdue Book Notice",
            body=f"Your loan for '{book_title}' is overdue. Total fine assessed: {fine_amount}.",
        )

    def get_history(self, recipient_id: Optional[str] = None) -> List[NotificationMessage]:
        """Filters message audit log."""
        if recipient_id is None:
            return list(self._history)
        return [m for m in self._history if m.recipient_id == recipient_id]

