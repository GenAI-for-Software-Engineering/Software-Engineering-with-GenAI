"""Library statistics, circulation reports, popular books, and overdue tracking."""

from collections import Counter
from decimal import Decimal
from typing import Any, Dict, List

from library_management.catalog import CatalogService
from library_management.fine import FineService
from library_management.lending import LendingService
from library_management.member import MemberService
from library_management.models import BookStatus, LoanStatus
from library_management.utils import round_currency


class AnalyticsService:
    """Computes circulation analytics, inventory utilization, and revenue totals."""

    def __init__(
        self,
        catalog_service: CatalogService,
        lending_service: LendingService,
        member_service: MemberService,
        fine_service: FineService,
    ):
        self.catalog_service = catalog_service
        self.lending_service = lending_service
        self.member_service = member_service
        self.fine_service = fine_service

    def get_inventory_summary(self) -> Dict[str, Any]:
        """Summarizes book inventory, total copies, and physical copy statuses."""
        books = self.catalog_service.list_books()
        total_copies = 0
        status_counts: Counter = Counter()

        for book in books:
            total_copies += len(book.copies)
            for copy in book.copies:
                status_counts[copy.status.value] += 1

        return {
            "total_titles": len(books),
            "total_copies": total_copies,
            "status_breakdown": dict(status_counts),
        }

    def get_circulation_summary(self) -> Dict[str, Any]:
        """Aggregates loan activity."""
        all_loans = list(self.lending_service._loans.values())
        active_loans = [l for l in all_loans if l.status == LoanStatus.ACTIVE]
        returned_loans = [l for l in all_loans if l.status == LoanStatus.RETURNED]
        lost_loans = [l for l in all_loans if l.status == LoanStatus.LOST]

        return {
            "total_loans_created": len(all_loans),
            "currently_active_loans": len(active_loans),
            "returned_loans": len(returned_loans),
            "lost_books_count": len(lost_loans),
        }

    def get_most_borrowed_books(self, top_n: int = 5) -> List[Dict[str, Any]]:
        """Identifies top-N most frequently borrowed book titles."""
        book_counts: Counter = Counter()
        for loan in self.lending_service._loans.values():
            book_counts[loan.book_id] += 1

        top_books = []
        for book_id, count in book_counts.most_common(top_n):
            book = self.catalog_service.get_book(book_id)
            top_books.append({
                "book_id": book_id,
                "title": book.title,
                "author": book.author,
                "borrow_count": count,
            })
        return top_books

    def get_revenue_summary(self) -> Dict[str, Any]:
        """Summarizes fine assessments and collections."""
        fines = list(self.fine_service._fines.values())
        total_assessed = Decimal("0.00")
        total_collected = Decimal("0.00")

        for f in fines:
            total_assessed += f.amount
            total_collected += f.paid_amount

        outstanding = total_assessed - total_collected

        return {
            "total_fines_count": len(fines),
            "total_assessed": round_currency(total_assessed),
            "total_collected": round_currency(total_collected),
            "total_outstanding": round_currency(outstanding),
        }

    def get_member_loan_history(self, member_id: str) -> Dict[str, Any]:
        """Detailed borrowing history and metrics for a specific member."""
        member = self.member_service.get_member(member_id)
        member_loans = [l for l in self.lending_service._loans.values() if l.member_id == member_id]
        active = [l for l in member_loans if l.status == LoanStatus.ACTIVE]
        returned = [l for l in member_loans if l.status == LoanStatus.RETURNED]
        fines = self.fine_service.get_unpaid_fines_for_member(member_id)

        return {
            "member_id": member_id,
            "member_name": member.name,
            "membership_type": member.membership_type.value,
            "total_lifetime_loans": len(member_loans),
            "active_loans": len(active),
            "returned_loans": len(returned),
            "unpaid_fines_count": len(fines),
            "total_unpaid_fine_amount": self.fine_service.get_total_outstanding_fines(member_id),
        }

