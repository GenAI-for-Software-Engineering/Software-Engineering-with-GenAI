"""Domain data models, enumerations, and dataclasses for Library Management System."""

from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import List, Optional


class MembershipType(str, Enum):
    """Member tiers governing loan limits and durations."""
    STUDENT = "STUDENT"
    FACULTY = "FACULTY"
    PUBLIC = "PUBLIC"
    RESEARCHER = "RESEARCHER"


class MemberStatus(str, Enum):
    """Lifecycle status of a library member."""
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"
    EXPIRED = "EXPIRED"
    DEACTIVATED = "DEACTIVATED"


class BookFormat(str, Enum):
    """Media and binding format of catalog item."""
    HARDCOVER = "HARDCOVER"
    PAPERBACK = "PAPERBACK"
    EBOOK = "EBOOK"
    AUDIOBOOK = "AUDIOBOOK"
    JOURNAL = "JOURNAL"


class BookStatus(str, Enum):
    """Physical copy availability status."""
    AVAILABLE = "AVAILABLE"
    BORROWED = "BORROWED"
    RESERVED = "RESERVED"
    LOST = "LOST"
    DAMAGED = "DAMAGED"
    IN_MAINTENANCE = "IN_MAINTENANCE"


class LoanStatus(str, Enum):
    """Borrowing record lifecycle status."""
    ACTIVE = "ACTIVE"
    RETURNED = "RETURNED"
    OVERDUE = "OVERDUE"
    LOST = "LOST"


class ReservationStatus(str, Enum):
    """Book hold/reservation status."""
    PENDING = "PENDING"
    READY_FOR_PICKUP = "READY_FOR_PICKUP"
    FULFILLED = "FULFILLED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"


class PaymentMethod(str, Enum):
    """Supported fine/fee payment methods."""
    CASH = "CASH"
    CARD = "CARD"
    UPI = "UPI"
    LIBRARY_ACCOUNT = "LIBRARY_ACCOUNT"


class PaymentStatus(str, Enum):
    """Payment transaction settlement status."""
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    REFUNDED = "REFUNDED"


@dataclass
class Member:
    """Library member entity."""
    member_id: str
    name: str
    email: str
    phone: str
    membership_type: MembershipType
    status: MemberStatus = MemberStatus.ACTIVE
    card_number: Optional[str] = None
    account_balance: Decimal = field(default_factory=lambda: Decimal("0.00"))
    created_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None


@dataclass
class BookCopy:
    """Represents a physical or cataloged copy with unique barcode."""
    barcode: str
    book_id: str
    rack_location: str
    status: BookStatus = BookStatus.AVAILABLE
    acquisition_date: Optional[date] = None
    condition_notes: Optional[str] = None


@dataclass
class Book:
    """Book metadata catalog record."""
    book_id: str
    isbn: str
    title: str
    author: str
    publisher: str
    publication_year: int
    category: str
    format: BookFormat = BookFormat.PAPERBACK
    is_reference_only: bool = False
    price: Decimal = field(default_factory=lambda: Decimal("500.00"))
    copies: List[BookCopy] = field(default_factory=list)


@dataclass
class Loan:
    """Record of a borrowed book copy."""
    loan_id: str
    member_id: str
    book_id: str
    barcode: str
    checkout_date: datetime
    due_date: datetime
    returned_date: Optional[datetime] = None
    renewal_count: int = 0
    status: LoanStatus = LoanStatus.ACTIVE


@dataclass
class Reservation:
    """Book reservation hold request by a member."""
    reservation_id: str
    member_id: str
    book_id: str
    requested_at: datetime
    status: ReservationStatus = ReservationStatus.PENDING
    assigned_barcode: Optional[str] = None
    pickup_deadline: Optional[datetime] = None
    fulfilled_at: Optional[datetime] = None
    cancelled_at: Optional[datetime] = None


@dataclass
class FineRecord:
    """Fine assessment record for overdue, lost, or damaged books."""
    fine_id: str
    loan_id: Optional[str]
    member_id: str
    amount: Decimal
    paid_amount: Decimal = field(default_factory=lambda: Decimal("0.00"))
    is_paid: bool = False
    reason: str = ""
    assessed_at: Optional[datetime] = None
    paid_at: Optional[datetime] = None


@dataclass
class Transaction:
    """Payment ledger record."""
    transaction_id: str
    fine_id: Optional[str]
    member_id: str
    amount: Decimal
    payment_method: PaymentMethod
    status: PaymentStatus
    created_at: datetime
    gateway_reference: Optional[str] = None
    notes: Optional[str] = None


@dataclass
class NotificationMessage:
    """Simulated notification delivery dispatch."""
    notification_id: str
    recipient_id: str
    channel: str
    subject: str
    body: str
    sent_at: datetime
    success: bool

