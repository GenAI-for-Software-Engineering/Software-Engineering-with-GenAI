"""Utilities, deterministic clock, sequential ID generator, and format validators."""

from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
import re
from typing import Optional
import uuid

from library_management.exceptions import ValidationError


class Clock:
    """Testable system clock interface supporting time injection and time-travel."""

    def __init__(self, fixed_time: Optional[datetime] = None):
        self._fixed_time = fixed_time

    def now(self) -> datetime:
        """Returns current UTC datetime or fixed test time."""
        if self._fixed_time is not None:
            return self._fixed_time
        return datetime.now(timezone.utc)

    def set_time(self, new_time: datetime) -> None:
        """Sets a fixed test time."""
        self._fixed_time = new_time

    def advance_days(self, days: float) -> None:
        """Advances current test time by days."""
        from datetime import timedelta
        base = self.now()
        self._fixed_time = base + timedelta(days=days)


class IdGenerator:
    """Testable identifier generator with optional deterministic sequence."""

    def __init__(self, prefix_seed: Optional[str] = None):
        self._counter = 0
        self._prefix_seed = prefix_seed

    def generate(self, prefix: str) -> str:
        """Generates an ID. If prefix_seed is set, generates sequential deterministic IDs."""
        if self._prefix_seed is not None:
            self._counter += 1
            return f"{prefix}-{self._prefix_seed}-{self._counter:04d}"
        random_suffix = uuid.uuid4().hex[:8]
        return f"{prefix}-{random_suffix}"


EMAIL_REGEX = re.compile(r"^[\w\.-]+@([\w-]+\.)+[\w-]{2,4}$")
PHONE_REGEX = re.compile(r"^\+?[1-9]\d{7,14}$")
ISBN10_REGEX = re.compile(r"^\d{9}[\dX]$")
ISBN13_REGEX = re.compile(r"^(978|979)\d{10}$")


def validate_email(email: str) -> str:
    """Validates and normalizes email address."""
    if not email or not isinstance(email, str):
        raise ValidationError("Email must be a non-empty string.")
    normalized = email.strip().lower()
    if not EMAIL_REGEX.match(normalized):
        raise ValidationError(f"Invalid email format: '{email}'.")
    return normalized


def validate_phone(phone: str) -> str:
    """Validates phone number format."""
    if not phone or not isinstance(phone, str):
        raise ValidationError("Phone must be a non-empty string.")
    cleaned = phone.strip().replace(" ", "").replace("-", "")
    if not PHONE_REGEX.match(cleaned):
        raise ValidationError(f"Invalid phone number format: '{phone}'.")
    return cleaned


def validate_isbn(isbn: str) -> str:
    """Validates ISBN-10 or ISBN-13 format and checksum."""
    if not isbn or not isinstance(isbn, str):
        raise ValidationError("ISBN must be a non-empty string.")
    cleaned = isbn.strip().replace("-", "").replace(" ", "").upper()

    if len(cleaned) == 10:
        if not ISBN10_REGEX.match(cleaned):
            raise ValidationError(f"Invalid ISBN-10 format: '{isbn}'.")
        total = 0
        for i in range(9):
            total += int(cleaned[i]) * (10 - i)
        checksum = 10 if cleaned[9] == "X" else int(cleaned[9])
        total += checksum
        if total % 11 != 0:
            raise ValidationError(f"Invalid ISBN-10 checksum for '{isbn}'.")
        return cleaned

    elif len(cleaned) == 13:
        if not ISBN13_REGEX.match(cleaned):
            raise ValidationError(f"Invalid ISBN-13 format: '{isbn}'.")
        total = 0
        for i in range(12):
            factor = 1 if i % 2 == 0 else 3
            total += int(cleaned[i]) * factor
        remainder = total % 10
        check = (10 - remainder) % 10
        if int(cleaned[12]) != check:
            raise ValidationError(f"Invalid ISBN-13 checksum for '{isbn}'.")
        return cleaned

    else:
        raise ValidationError(f"ISBN must be either 10 or 13 digits, got {len(cleaned)}.")


def round_currency(amount: Decimal) -> Decimal:
    """Rounds monetary value to 2 decimal places."""
    if not isinstance(amount, Decimal):
        amount = Decimal(str(amount))
    return amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

