"""Library Management System package exports."""

from library_management.analytics import AnalyticsService
from library_management.catalog import CatalogService
from library_management.exceptions import (
    ActiveReservationExistsError,
    BookCopyNotFoundError,
    BookNotAvailableError,
    BookNotFoundError,
    DuplicateBookError,
    DuplicateMemberError,
    DuplicatePaymentError,
    InsufficientBalanceError,
    LibraryManagementError,
    LoanLimitExceededError,
    LoanNotFoundError,
    MemberExpiredError,
    MemberNotFoundError,
    MemberSuspendedError,
    OutstandingFinesBlockError,
    PaymentFailedError,
    ReferenceOnlyBookError,
    RenewalLimitExceededError,
    ReservationLimitExceededError,
    ReservationNotFoundError,
    ValidationError,
)
from library_management.fine import (
    DAILY_OVERDUE_FINE_RATE,
    FineService,
)
from library_management.lending import LendingService
from library_management.member import (
    FINE_BLOCKING_THRESHOLD,
    MEMBERSHIP_LOAN_LIMITS,
    MEMBERSHIP_LOAN_PERIOD_DAYS,
    MEMBERSHIP_MAX_RENEWALS,
    MEMBERSHIP_VALIDITY_DAYS,
    MemberService,
)
from library_management.models import (
    Book,
    BookCopy,
    BookFormat,
    BookStatus,
    FineRecord,
    Loan,
    LoanStatus,
    Member,
    MembershipType,
    MemberStatus,
    NotificationMessage,
    PaymentMethod,
    PaymentStatus,
    Reservation,
    ReservationStatus,
    Transaction,
)
from library_management.notification import (
    MockEmailService,
    MockSmsService,
    NotificationChannel,
    NotificationService,
)
from library_management.payment import (
    MockPaymentGateway,
    PaymentGateway,
    PaymentService,
)
from library_management.reservation import ReservationService
from library_management.system import LibraryManagementSystem
from library_management.utils import Clock, IdGenerator, round_currency, validate_isbn

__all__ = [
    # Top-level Orchestrator
    "LibraryManagementSystem",
    # Core domain models and enums
    "Book",
    "BookCopy",
    "BookFormat",
    "BookStatus",
    "FineRecord",
    "Loan",
    "LoanStatus",
    "Member",
    "MemberStatus",
    "MembershipType",
    "NotificationMessage",
    "PaymentMethod",
    "PaymentStatus",
    "Reservation",
    "ReservationStatus",
    "Transaction",
    # Services
    "AnalyticsService",
    "CatalogService",
    "FineService",
    "LendingService",
    "MemberService",
    "NotificationService",
    "PaymentService",
    "ReservationService",
    # Mocks / Adapters
    "MockEmailService",
    "MockPaymentGateway",
    "MockSmsService",
    "NotificationChannel",
    "PaymentGateway",
    # Utilities & Constants
    "Clock",
    "IdGenerator",
    "round_currency",
    "validate_isbn",
    "DAILY_OVERDUE_FINE_RATE",
    "FINE_BLOCKING_THRESHOLD",
    "MEMBERSHIP_LOAN_LIMITS",
    "MEMBERSHIP_LOAN_PERIOD_DAYS",
    "MEMBERSHIP_MAX_RENEWALS",
    "MEMBERSHIP_VALIDITY_DAYS",
    # Exceptions
    "ActiveReservationExistsError",
    "BookCopyNotFoundError",
    "BookNotAvailableError",
    "BookNotFoundError",
    "DuplicateBookError",
    "DuplicateMemberError",
    "DuplicatePaymentError",
    "InsufficientBalanceError",
    "LibraryManagementError",
    "LoanLimitExceededError",
    "LoanNotFoundError",
    "MemberExpiredError",
    "MemberNotFoundError",
    "MemberSuspendedError",
    "OutstandingFinesBlockError",
    "PaymentFailedError",
    "ReferenceOnlyBookError",
    "RenewalLimitExceededError",
    "ReservationLimitExceededError",
    "ReservationNotFoundError",
    "ValidationError",
]
