"""Top-level facade system integrating all library services into a unified interface."""

from decimal import Decimal
from typing import Any, Dict, List, Optional

from library_management.analytics import AnalyticsService
from library_management.catalog import CatalogService
from library_management.fine import FineService
from library_management.lending import LendingService
from library_management.member import MemberService
from library_management.models import (
    Book,
    BookCopy,
    BookFormat,
    BookStatus,
    FineRecord,
    Loan,
    Member,
    MembershipType,
    PaymentMethod,
    Reservation,
    Transaction,
)
from library_management.notification import NotificationService
from library_management.payment import MockPaymentGateway, PaymentGateway, PaymentService
from library_management.reservation import ReservationService
from library_management.utils import Clock, IdGenerator


class LibraryManagementSystem:
    """Unified facade exposing all library workflows for circulation, catalog, and testing."""

    def __init__(
        self,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
        payment_gateway: Optional[PaymentGateway] = None,
    ):
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self.gateway = payment_gateway or MockPaymentGateway()

        # Wire all modular services
        self.member_service = MemberService(clock=self.clock, id_gen=self.id_gen)
        self.catalog_service = CatalogService(clock=self.clock, id_gen=self.id_gen)
        self.fine_service = FineService(clock=self.clock, id_gen=self.id_gen)
        self.lending_service = LendingService(
            member_service=self.member_service,
            catalog_service=self.catalog_service,
            fine_service=self.fine_service,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.reservation_service = ReservationService(
            member_service=self.member_service,
            catalog_service=self.catalog_service,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.payment_service = PaymentService(
            fine_service=self.fine_service,
            member_service=self.member_service,
            gateway=self.gateway,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.notification_service = NotificationService(
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.analytics_service = AnalyticsService(
            catalog_service=self.catalog_service,
            lending_service=self.lending_service,
            member_service=self.member_service,
            fine_service=self.fine_service,
        )

    # --- Convenience Workflows ---

    def register_member(
        self,
        name: str,
        email: str,
        phone: str,
        membership_type: MembershipType,
        initial_balance: Decimal = Decimal("0.00"),
    ) -> Member:
        """Registers a new library member."""
        return self.member_service.register_member(
            name=name,
            email=email,
            phone=phone,
            membership_type=membership_type,
            initial_balance=initial_balance,
        )

    def catalog_new_book(
        self,
        isbn: str,
        title: str,
        author: str,
        publisher: str,
        publication_year: int,
        category: str,
        number_of_copies: int = 1,
        rack_location_prefix: str = "A1-R",
        format: BookFormat = BookFormat.PAPERBACK,
        is_reference_only: bool = False,
        price: Decimal = Decimal("500.00"),
    ) -> Book:
        """Adds a title and initializes physical copies with unique barcodes."""
        book = self.catalog_service.add_book(
            isbn=isbn,
            title=title,
            author=author,
            publisher=publisher,
            publication_year=publication_year,
            category=category,
            format=format,
            is_reference_only=is_reference_only,
            price=price,
        )

        for i in range(1, number_of_copies + 1):
            rack = f"{rack_location_prefix}{i}"
            self.catalog_service.add_copy(book.book_id, rack_location=rack)

        return book

    def borrow_book(self, member_id: str, book_id: str) -> Loan:
        """Executes borrow workflow and sends confirmation notification."""
        loan = self.lending_service.checkout_book(member_id, book_id)
        member = self.member_service.get_member(member_id)
        book = self.catalog_service.get_book(book_id)

        self.notification_service.notify_checkout(
            member_id=member_id,
            email=member.email,
            book_title=book.title,
            due_date_str=loan.due_date.strftime("%Y-%m-%d"),
        )
        return loan

    def return_book_with_hold_check(self, barcode: str) -> Dict[str, Any]:
        """Returns book, checks waitlist, and alerts next queued member if hold exists."""
        loan = self.lending_service.return_book(barcode)
        next_hold = self.reservation_service.process_returned_copy_for_holds(loan.book_id, barcode)

        if next_hold:
            queued_member = self.member_service.get_member(next_hold.member_id)
            book = self.catalog_service.get_book(loan.book_id)
            deadline = next_hold.pickup_deadline.strftime("%Y-%m-%d") if next_hold.pickup_deadline else ""
            self.notification_service.notify_hold_ready(
                member_id=queued_member.member_id,
                phone=queued_member.phone,
                book_title=book.title,
                deadline_str=deadline,
            )

        return {
            "loan": loan,
            "next_hold": next_hold,
        }

    def settle_fine(
        self,
        fine_id: str,
        amount: Decimal,
        payment_method: PaymentMethod,
    ) -> Transaction:
        """Settles fine debt."""
        return self.payment_service.pay_fine(
            fine_id=fine_id,
            amount=amount,
            payment_method=payment_method,
        )

