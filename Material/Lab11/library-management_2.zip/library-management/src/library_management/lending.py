"""Book checkout, returns, loan renewals, and borrowing limit enforcement."""

from datetime import timedelta
from typing import Dict, List, Optional

from library_management.catalog import CatalogService
from library_management.exceptions import (
    BookNotAvailableError,
    LoanLimitExceededError,
    LoanNotFoundError,
    OutstandingFinesBlockError,
    ReferenceOnlyBookError,
    RenewalLimitExceededError,
    ValidationError,
)
from library_management.fine import FineService
from library_management.member import (
    FINE_BLOCKING_THRESHOLD,
    MEMBERSHIP_LOAN_LIMITS,
    MEMBERSHIP_LOAN_PERIOD_DAYS,
    MEMBERSHIP_MAX_RENEWALS,
    MemberService,
)
from library_management.models import BookStatus, Loan, LoanStatus
from library_management.utils import Clock, IdGenerator


class LendingService:
    """Coordinates book checkouts, renewals, returns, and inventory status synchronization."""

    def __init__(
        self,
        member_service: MemberService,
        catalog_service: CatalogService,
        fine_service: FineService,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.member_service = member_service
        self.catalog_service = catalog_service
        self.fine_service = fine_service
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._loans: Dict[str, Loan] = {}
        self._member_active_loans: Dict[str, List[str]] = {}

    def checkout_book(self, member_id: str, book_id: str, barcode: Optional[str] = None) -> Loan:
        """Issues a book copy to a qualified member."""
        member = self.member_service.validate_member_in_good_standing(member_id)

        # 1. Check outstanding unpaid fines threshold
        outstanding_fine = self.fine_service.get_total_outstanding_fines(member_id)
        if outstanding_fine > FINE_BLOCKING_THRESHOLD:
            raise OutstandingFinesBlockError(
                member_id=member_id,
                total_fine=str(outstanding_fine),
                threshold=str(FINE_BLOCKING_THRESHOLD),
            )

        # 2. Check loan count limit for member's tier
        active_loans = self.get_active_loans_for_member(member_id)
        allowed_limit = MEMBERSHIP_LOAN_LIMITS[member.membership_type]
        if len(active_loans) >= allowed_limit:
            raise LoanLimitExceededError(member_id, allowed_limit)

        # 3. Check reference only restriction
        book = self.catalog_service.get_book(book_id)
        if book.is_reference_only:
            raise ReferenceOnlyBookError(book_id)

        # 4. Locate available copy
        if barcode:
            copy = self.catalog_service.get_copy(barcode)
            if copy.book_id != book_id:
                raise ValidationError(f"Barcode '{barcode}' does not belong to book '{book_id}'.")
            if copy.status != BookStatus.AVAILABLE:
                raise BookNotAvailableError(book_id)
        else:
            copy = self.catalog_service.get_available_copy(book_id)
            if not copy:
                raise BookNotAvailableError(book_id)

        # 5. Create loan record
        loan_id = self.id_gen.generate("LON")
        now = self.clock.now()
        period_days = MEMBERSHIP_LOAN_PERIOD_DAYS[member.membership_type]
        due_date = now + timedelta(days=period_days)

        loan = Loan(
            loan_id=loan_id,
            member_id=member_id,
            book_id=book_id,
            barcode=copy.barcode,
            checkout_date=now,
            due_date=due_date,
            status=LoanStatus.ACTIVE,
        )

        # Update copy status to BORROWED
        self.catalog_service.update_copy_status(copy.barcode, BookStatus.BORROWED)

        self._loans[loan_id] = loan
        if member_id not in self._member_active_loans:
            self._member_active_loans[member_id] = []
        self._member_active_loans[member_id].append(loan_id)

        return loan

    def renew_loan(self, loan_id: str) -> Loan:
        """Extends loan due date if renewal limit is not exceeded."""
        loan = self.get_loan(loan_id)
        if loan.status != LoanStatus.ACTIVE:
            raise ValidationError(f"Cannot renew non-active loan (status: {loan.status.value}).")

        member = self.member_service.validate_member_in_good_standing(loan.member_id)

        # Check unpaid fines blocking renewals
        outstanding = self.fine_service.get_total_outstanding_fines(loan.member_id)
        if outstanding > FINE_BLOCKING_THRESHOLD:
            raise OutstandingFinesBlockError(loan.member_id, str(outstanding), str(FINE_BLOCKING_THRESHOLD))

        max_renewals = MEMBERSHIP_MAX_RENEWALS[member.membership_type]
        if loan.renewal_count >= max_renewals:
            raise RenewalLimitExceededError(loan_id, max_renewals)

        period_days = MEMBERSHIP_LOAN_PERIOD_DAYS[member.membership_type]
        now = self.clock.now()
        base_date = max(loan.due_date, now)
        loan.due_date = base_date + timedelta(days=period_days)
        loan.renewal_count += 1
        return loan

    def return_book(self, barcode: str) -> Loan:
        """Processes book return, updates copy availability, and triggers overdue fines if late."""
        copy = self.catalog_service.get_copy(barcode)
        loan = self.get_active_loan_by_barcode(barcode)
        if not loan:
            raise ValidationError(f"No active loan found for barcode '{barcode}'.")

        member = self.member_service.get_member(loan.member_id)
        now = self.clock.now()

        loan.returned_date = now
        loan.status = LoanStatus.RETURNED
        self.catalog_service.update_copy_status(barcode, BookStatus.AVAILABLE)

        # Remove from active list
        if loan.member_id in self._member_active_loans and loan.loan_id in self._member_active_loans[loan.member_id]:
            self._member_active_loans[loan.member_id].remove(loan.loan_id)

        # Assess overdue fine if returned past due date
        overdue_fine = self.fine_service.calculate_overdue_fine(
            due_date=loan.due_date,
            return_date=now,
            membership_type=member.membership_type,
        )
        if overdue_fine > 0:
            self.fine_service.assess_fine(
                member_id=loan.member_id,
                amount=overdue_fine,
                reason=f"Overdue return for book copy {barcode}",
                loan_id=loan.loan_id,
            )

        return loan

    def mark_book_lost(self, loan_id: str) -> Loan:
        """Marks borrowed copy as lost and assesses replacement cost fine."""
        loan = self.get_loan(loan_id)
        if loan.status != LoanStatus.ACTIVE:
            raise ValidationError("Only active loans can be marked as lost.")

        book = self.catalog_service.get_book(loan.book_id)
        lost_charge = self.fine_service.calculate_lost_book_charge(book.price)

        loan.status = LoanStatus.LOST
        self.catalog_service.update_copy_status(loan.barcode, BookStatus.LOST)

        # Clear from active loans
        if loan.member_id in self._member_active_loans and loan.loan_id in self._member_active_loans[loan.member_id]:
            self._member_active_loans[loan.member_id].remove(loan.loan_id)

        # Assess replacement charge
        self.fine_service.assess_fine(
            member_id=loan.member_id,
            amount=lost_charge,
            reason=f"Replacement fee for lost book: {book.title} (barcode {loan.barcode})",
            loan_id=loan_id,
        )

        return loan

    def get_loan(self, loan_id: str) -> Loan:
        """Retrieves loan record."""
        if loan_id not in self._loans:
            raise LoanNotFoundError(loan_id)
        return self._loans[loan_id]

    def get_active_loans_for_member(self, member_id: str) -> List[Loan]:
        """Lists active unreturned loans for a member."""
        loan_ids = self._member_active_loans.get(member_id, [])
        return [self._loans[lid] for lid in loan_ids if self._loans[lid].status == LoanStatus.ACTIVE]

    def get_active_loan_by_barcode(self, barcode: str) -> Optional[Loan]:
        """Finds active loan holding the given barcode copy."""
        for loan in self._loans.values():
            if loan.barcode == barcode and loan.status == LoanStatus.ACTIVE:
                return loan
        return None
