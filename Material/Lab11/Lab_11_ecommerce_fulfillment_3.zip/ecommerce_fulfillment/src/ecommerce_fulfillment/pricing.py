"""Pricing engine, tax calculations by category, coupons, and tiered shipping fees."""

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional

from ecommerce_fulfillment.exceptions import CouponError, ValidationError
from ecommerce_fulfillment.models import (
    MembershipTier,
    OrderItem,
    PricingBreakdown,
    ProductCategory,
)
from ecommerce_fulfillment.utils import round_currency

# GST / Category Tax Rates
CATEGORY_TAX_RATES = {
    ProductCategory.GROCERY: Decimal("0.05"),          # 5%
    ProductCategory.BOOKS: Decimal("0.00"),            # 0% exempt
    ProductCategory.APPAREL: Decimal("0.12"),          # 12%
    ProductCategory.ELECTRONICS: Decimal("0.18"),      # 18%
    ProductCategory.HOME_APPLIANCES: Decimal("0.18"),  # 18%
}

# Shipping parameters
BASE_SHIPPING_FEE = Decimal("50.00")
FREE_SHIPPING_THRESHOLD_STANDARD = Decimal("500.00")


@dataclass
class Coupon:
    """Promotional discount code model."""
    code: str
    discount_percent: Decimal
    max_discount: Decimal
    min_order_value: Decimal
    expiry_date: datetime
    max_usages: int
    usage_count: int = 0
    is_active: bool = True


class PricingService:
    """Computes invoice subtotals, category taxes, coupons, and loyalty shipping discounts."""

    def __init__(self):
        self._coupons: Dict[str, Coupon] = {}

    def create_coupon(
        self,
        code: str,
        discount_percent: Decimal,
        max_discount: Decimal,
        min_order_value: Decimal,
        expiry_date: datetime,
        max_usages: int = 100,
    ) -> Coupon:
        """Registers a discount coupon."""
        clean_code = code.strip().upper()
        if not clean_code:
            raise ValidationError("Coupon code cannot be empty.")
        if discount_percent <= Decimal("0") or discount_percent > Decimal("100"):
            raise ValidationError("Discount percent must be between 1 and 100.")

        coupon = Coupon(
            code=clean_code,
            discount_percent=discount_percent,
            max_discount=round_currency(max_discount),
            min_order_value=round_currency(min_order_value),
            expiry_date=expiry_date,
            max_usages=max_usages,
        )
        self._coupons[clean_code] = coupon
        return coupon

    def validate_and_apply_coupon(
        self,
        coupon_code: str,
        items_subtotal: Decimal,
        current_time: datetime,
    ) -> Decimal:
        """Validates coupon constraints and calculates discount amount."""
        clean_code = coupon_code.strip().upper()
        if clean_code not in self._coupons:
            raise CouponError(f"Coupon '{coupon_code}' does not exist.")

        coupon = self._coupons[clean_code]

        if not coupon.is_active:
            raise CouponError("Coupon is inactive.")
        if current_time > coupon.expiry_date:
            raise CouponError("Coupon has expired.")
        if coupon.usage_count >= coupon.max_usages:
            raise CouponError("Coupon usage limit reached.")
        if items_subtotal < coupon.min_order_value:
            raise CouponError(
                f"Order subtotal {items_subtotal} is less than required minimum {coupon.min_order_value}."
            )

        calc_discount = (items_subtotal * coupon.discount_percent) / Decimal("100")
        actual_discount = min(calc_discount, coupon.max_discount)
        return round_currency(actual_discount)

    def record_coupon_usage(self, coupon_code: str) -> None:
        """Increments coupon usage counter."""
        clean = coupon_code.strip().upper()
        if clean in self._coupons:
            self._coupons[clean].usage_count += 1

    def calculate_shipping_fee(
        self,
        items_subtotal: Decimal,
        customer_tier: MembershipTier,
    ) -> Decimal:
        """Calculates delivery shipping fee based on tier and order threshold."""
        # Prime and VIP members enjoy unconditionally free shipping
        if customer_tier in (MembershipTier.PRIME, MembershipTier.VIP):
            return Decimal("0.00")

        # Standard members get free shipping over threshold
        if items_subtotal >= FREE_SHIPPING_THRESHOLD_STANDARD:
            return Decimal("0.00")

        return BASE_SHIPPING_FEE

    def calculate_invoice(
        self,
        items: List[OrderItem],
        customer_tier: MembershipTier,
        coupon_code: Optional[str] = None,
        current_time: Optional[datetime] = None,
    ) -> PricingBreakdown:
        """Calculates detailed line items, discounts, taxes, and final total."""
        if not items:
            raise ValidationError("Order must contain at least one item.")

        items_subtotal = Decimal("0.00")
        total_tax = Decimal("0.00")

        for item in items:
            item_total = item.unit_price * Decimal(str(item.quantity))
            items_subtotal += item_total
            tax_rate = CATEGORY_TAX_RATES.get(item.category, Decimal("0.18"))
            item_tax = round_currency(item_total * tax_rate)
            total_tax += item_tax

        items_subtotal = round_currency(items_subtotal)

        # Apply coupon discount if supplied
        discount = Decimal("0.00")
        if coupon_code and current_time:
            discount = self.validate_and_apply_coupon(coupon_code, items_subtotal, current_time)

        shipping_fee = self.calculate_shipping_fee(items_subtotal, customer_tier)

        net_subtotal = max(Decimal("0.00"), items_subtotal - discount)
        final_total = round_currency(net_subtotal + shipping_fee + total_tax)

        return PricingBreakdown(
            items_subtotal=items_subtotal,
            discount_amount=discount,
            shipping_fee=shipping_fee,
            tax_amount=total_tax,
            final_total=final_total,
        )

