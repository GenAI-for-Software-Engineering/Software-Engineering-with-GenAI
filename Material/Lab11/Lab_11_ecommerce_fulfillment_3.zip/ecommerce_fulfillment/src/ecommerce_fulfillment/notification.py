"""Customer notifications with mockable Email and SMS communication channels."""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional

from ecommerce_fulfillment.exceptions import ValidationError
from ecommerce_fulfillment.models import NotificationMessage
from ecommerce_fulfillment.utils import Clock, IdGenerator


class NotificationChannel(ABC):
    """Abstract messaging channel interface."""

    @abstractmethod
    def send(self, recipient: str, subject: str, message: str) -> bool:
        """Sends payload."""
        pass


class MockEmailService(NotificationChannel):
    """Mock Email provider capturing sent messages."""

    def __init__(self, should_succeed: bool = True):
        self.should_succeed = should_succeed
        self.sent_emails: List[Dict[str, str]] = []

    def send(self, recipient: str, subject: str, message: str) -> bool:
        """Simulates email delivery."""
        if not self.should_succeed or "fail" in recipient.lower():
            return False
        self.sent_emails.append({"recipient": recipient, "subject": subject, "body": message})
        return True


class MockSmsService(NotificationChannel):
    """Mock SMS provider capturing sent texts."""

    def __init__(self, should_succeed: bool = True):
        self.should_succeed = should_succeed
        self.sent_sms: List[Dict[str, str]] = []

    def send(self, recipient: str, subject: str, message: str) -> bool:
        """Simulates SMS delivery."""
        if not self.should_succeed or "fail" in recipient.lower():
            return False
        self.sent_sms.append({"recipient": recipient, "subject": subject, "body": message})
        return True


class NotificationService:
    """Dispatches order confirmations, shipping updates, delivery notices, and refund receipts."""

    def __init__(
        self,
        email_channel: Optional[NotificationChannel] = None,
        sms_channel: Optional[NotificationChannel] = None,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.email_channel = email_channel or MockEmailService()
        self.sms_channel = sms_channel or MockSmsService()
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._history: List[NotificationMessage] = []

    def notify(
        self,
        recipient_id: str,
        contact: str,
        channel: str,
        subject: str,
        body: str,
    ) -> NotificationMessage:
        """Sends notification through selected channel."""
        if not recipient_id or not contact or not body:
            raise ValidationError("Recipient, contact, and body cannot be empty.")

        ch = channel.strip().upper()
        if ch == "EMAIL":
            success = self.email_channel.send(contact, subject, body)
        elif ch == "SMS":
            success = self.sms_channel.send(contact, subject, body)
        else:
            raise ValidationError(f"Unsupported notification channel: '{channel}'.")

        msg = NotificationMessage(
            notification_id=self.id_gen.generate("NOTIF"),
            recipient_id=recipient_id,
            channel=ch,
            subject=subject,
            body=body,
            sent_at=self.clock.now(),
            success=success,
        )
        self._history.append(msg)
        return msg

    def notify_order_confirmed(
        self,
        customer_id: str,
        email: str,
        order_id: str,
        amount_str: str,
    ) -> NotificationMessage:
        """Sends order confirmation invoice receipt."""
        return self.notify(
            recipient_id=customer_id,
            contact=email,
            channel="EMAIL",
            subject=f"Order Confirmed: #{order_id}",
            body=f"Your order #{order_id} has been confirmed. Total paid: {amount_str}.",
        )

    def notify_shipment_dispatched(
        self,
        customer_id: str,
        phone: str,
        order_id: str,
        tracking_number: str,
    ) -> NotificationMessage:
        """Sends SMS with courier tracking details."""
        return self.notify(
            recipient_id=customer_id,
            contact=phone,
            channel="SMS",
            subject="Order Dispatched",
            body=f"Your order #{order_id} has been shipped! Track via {tracking_number}.",
        )

    def get_history(self, recipient_id: Optional[str] = None) -> List[NotificationMessage]:
        """Filters message audit history."""
        if recipient_id is None:
            return list(self._history)
        return [m for m in self._history if m.recipient_id == recipient_id]

