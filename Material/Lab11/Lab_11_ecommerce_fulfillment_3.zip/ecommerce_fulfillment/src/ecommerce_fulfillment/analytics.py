"""E-commerce business metrics, seller revenue, category sales, and return rate analytics."""

from collections import Counter
from decimal import Decimal
from typing import Any, Dict, List

from ecommerce_fulfillment.order import OrderService
from ecommerce_fulfillment.models import OrderStatus
from ecommerce_fulfillment.utils import round_currency

# Platform commission fee on seller gross sales (10%)
PLATFORM_SELLER_COMMISSION_RATE = Decimal("0.10")


class AnalyticsService:
    """Computes gross merchandise value (GMV), seller payouts, return rates, and order metrics."""

    def __init__(self, order_service: OrderService):
        self.order_service = order_service

    def get_order_summary(self) -> Dict[str, Any]:
        """Summarizes all order lifecycle statuses."""
        all_orders = list(self.order_service._orders.values())
        counts: Counter = Counter()

        for o in all_orders:
            counts[o.status.value] += 1

        total_gmv = Decimal("0.00")
        for o in all_orders:
            if o.status in (OrderStatus.CONFIRMED, OrderStatus.PACKED, OrderStatus.SHIPPED, OrderStatus.DELIVERED):
                if o.pricing:
                    total_gmv += o.pricing.final_total

        return {
            "total_orders": len(all_orders),
            "status_breakdown": dict(counts),
            "gross_merchandise_value": round_currency(total_gmv),
        }

    def get_category_sales_metrics(self) -> Dict[str, Any]:
        """Aggregates units sold and sales revenue by product category."""
        category_units: Counter = Counter()
        category_revenue: Dict[str, Decimal] = {}

        for order in self.order_service._orders.values():
            if order.status not in (OrderStatus.CANCELLED, OrderStatus.CREATED):
                for item in order.items:
                    cat = item.category.value
                    category_units[cat] += item.quantity
                    category_revenue[cat] = category_revenue.get(cat, Decimal("0.00")) + item.total_price

        return {
            "units_by_category": dict(category_units),
            "revenue_by_category": {k: round_currency(v) for k, v in category_revenue.items()},
        }

    def calculate_seller_payout(self, seller_id: str) -> Dict[str, Any]:
        """Calculates seller net earnings from fulfilled orders after platform commission."""
        seller_sales = Decimal("0.00")
        items_sold_count = 0

        for order in self.order_service._orders.values():
            if order.status == OrderStatus.DELIVERED:
                for item in order.items:
                    product = self.order_service.inventory_service.get_product(item.product_id)
                    if product.seller_id == seller_id:
                        seller_sales += item.total_price
                        items_sold_count += item.quantity

        commission = round_currency(seller_sales * PLATFORM_SELLER_COMMISSION_RATE)
        net_payout = round_currency(seller_sales - commission)

        return {
            "seller_id": seller_id,
            "items_sold": items_sold_count,
            "gross_sales": round_currency(seller_sales),
            "platform_commission": commission,
            "net_payout": net_payout,
        }

    def get_return_rate_percentage(self) -> float:
        """Computes percentage of delivered orders that were returned."""
        all_orders = list(self.order_service._orders.values())
        delivered_count = sum(1 for o in all_orders if o.status == OrderStatus.DELIVERED)
        returned_count = sum(1 for o in all_orders if o.status == OrderStatus.RETURNED)

        total_eligible = delivered_count + returned_count
        if total_eligible == 0:
            return 0.0

        rate = (returned_count / total_eligible) * 100.0
        return round(rate, 2)

