"""Payment processing, gateway mock interface, wallet debits, and transaction ledger."""

from abc import ABC, abstractmethod
from decimal import Decimal
from typing import Dict, List, Optional

from ecommerce_fulfillment.exceptions import (
    DuplicatePaymentError,
    PaymentFailedError,
    ValidationError,
)
from ecommerce_fulfillment.models import (
    OrderStatus,
    PaymentMethod,
    PaymentStatus,
    Transaction,
)
from ecommerce_fulfillment.order import OrderService
from ecommerce_fulfillment.user import UserService
from ecommerce_fulfillment.utils import Clock, IdGenerator, round_currency


class PaymentGateway(ABC):
    """Abstract interface for payment service providers."""

    @abstractmethod
    def charge(self, transaction_id: str, amount: Decimal, metadata: Dict[str, str]) -> bool:
        """Processes transaction charge."""
        pass

    @abstractmethod
    def refund(self, original_ref: str, amount: Decimal) -> bool:
        """Processes transaction refund."""
        pass


class MockPaymentGateway(PaymentGateway):
    """Mock gateway implementation with configurable failure simulation."""

    def __init__(self, default_success: bool = True):
        self.default_success = default_success
        self.failure_triggers: Dict[str, str] = {}
        self.processed_ids: List[str] = []

    def set_failure_trigger(self, key: str, reason: str) -> None:
        """Forces decline when trigger key is matched."""
        self.failure_triggers[key] = reason

    def charge(self, transaction_id: str, amount: Decimal, metadata: Dict[str, str]) -> bool:
        """Simulates charging card or external UPI account."""
        self.processed_ids.append(transaction_id)
        for key in self.failure_triggers:
            if key in metadata or key in metadata.values():
                return False
        return self.default_success

    def refund(self, original_ref: str, amount: Decimal) -> bool:
        """Simulates refunding payment."""
        if "FAIL_REFUND" in original_ref:
            return False
        return True


class PaymentService:
    """Manages order checkout settlement, refunds, and financial ledger."""

    def __init__(
        self,
        order_service: OrderService,
        user_service: UserService,
        gateway: Optional[PaymentGateway] = None,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.order_service = order_service
        self.user_service = user_service
        self.gateway = gateway or MockPaymentGateway()
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._transactions: Dict[str, Transaction] = {}
        self._order_transaction_map: Dict[str, str] = {}

    def process_order_payment(
        self,
        order_id: str,
        payment_method: PaymentMethod,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Transaction:
        """Settles payment for a created order and transitions it to CONFIRMED."""
        order = self.order_service.get_order(order_id)

        if order_id in self._order_transaction_map:
            raise DuplicatePaymentError(order_id)

        if not order.pricing:
            raise ValidationError("Order has no calculated pricing to settle.")

        amount = order.pricing.final_total
        tx_id = self.id_gen.generate("TXN")
        now = self.clock.now()
        meta = metadata or {}

        # 1. In-App Wallet payment
        if payment_method == PaymentMethod.WALLET:
            self.user_service.deduct_wallet_funds(order.customer_id, amount)
            tx = Transaction(
                transaction_id=tx_id,
                order_id=order_id,
                customer_id=order.customer_id,
                amount=amount,
                payment_method=payment_method,
                status=PaymentStatus.COMPLETED,
                created_at=now,
                gateway_reference=f"WALLET-PAY-{tx_id}",
                notes="Settled via in-app wallet balance",
            )
            self._save_transaction(tx)
            self.order_service.confirm_order(order_id)
            return tx

        # 2. Cash on Delivery (COD)
        if payment_method == PaymentMethod.CASH_ON_DELIVERY:
            tx = Transaction(
                transaction_id=tx_id,
                order_id=order_id,
                customer_id=order.customer_id,
                amount=amount,
                payment_method=payment_method,
                status=PaymentStatus.COMPLETED,
                created_at=now,
                gateway_reference="COD-PENDING-COLLECTION",
                notes="Cash on delivery mode confirmed",
            )
            self._save_transaction(tx)
            self.order_service.confirm_order(order_id)
            return tx

        # 3. Card / UPI via Gateway
        success = self.gateway.charge(tx_id, amount, meta)
        if not success:
            tx = Transaction(
                transaction_id=tx_id,
                order_id=order_id,
                customer_id=order.customer_id,
                amount=amount,
                payment_method=payment_method,
                status=PaymentStatus.FAILED,
                created_at=now,
                notes="Gateway declined charge",
            )
            self._save_transaction(tx)
            raise PaymentFailedError("Payment gateway declined transaction.")

        tx = Transaction(
            transaction_id=tx_id,
            order_id=order_id,
            customer_id=order.customer_id,
            amount=amount,
            payment_method=payment_method,
            status=PaymentStatus.COMPLETED,
            created_at=now,
            gateway_reference=f"GW-{tx_id}",
            notes="Payment processed successfully",
        )
        self._save_transaction(tx)
        self.order_service.confirm_order(order_id)
        return tx

    def _save_transaction(self, tx: Transaction) -> None:
        """Internal ledger record storage."""
        self._transactions[tx.transaction_id] = tx
        self._order_transaction_map[tx.order_id] = tx.transaction_id

    def get_transaction(self, transaction_id: str) -> Transaction:
        """Retrieves transaction by ID."""
        if transaction_id not in self._transactions:
            raise ValidationError(f"Transaction '{transaction_id}' not found.")
        return self._transactions[transaction_id]

    def get_transaction_by_order(self, order_id: str) -> Optional[Transaction]:
        """Gets payment record for given order."""
        tx_id = self._order_transaction_map.get(order_id)
        if not tx_id:
            return None
        return self._transactions.get(tx_id)

