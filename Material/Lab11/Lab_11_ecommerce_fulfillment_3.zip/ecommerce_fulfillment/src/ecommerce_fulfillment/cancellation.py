"""Order cancellation, restocking fees, 7-day return policy, and automated refunds."""

from datetime import timedelta
from decimal import Decimal
from typing import Dict, Optional

from ecommerce_fulfillment.exceptions import (
    ReturnPolicyViolationError,
    ValidationError,
)
from ecommerce_fulfillment.models import (
    Order,
    OrderStatus,
    PaymentMethod,
    PaymentStatus,
    Transaction,
)
from ecommerce_fulfillment.order import OrderService
from ecommerce_fulfillment.payment import PaymentGateway, PaymentService
from ecommerce_fulfillment.user import UserService
from ecommerce_fulfillment.utils import Clock, IdGenerator, round_currency

RETURN_WINDOW_DAYS = 7
RESTOCKING_FEE_SHIPPED = Decimal("50.00")


class ReturnCancellationService:
    """Handles order cancellations, inventory restock, return window checks, and refunds."""

    def __init__(
        self,
        order_service: OrderService,
        payment_service: PaymentService,
        user_service: UserService,
        gateway: Optional[PaymentGateway] = None,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.order_service = order_service
        self.payment_service = payment_service
        self.user_service = user_service
        self.gateway = gateway or self.payment_service.gateway
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._refunds: Dict[str, str] = {}  # orig_tx_id -> refund_tx_id

    def cancel_order(self, order_id: str, reason: str = "Customer requested") -> Order:
        """Cancels order, releases inventory back to warehouse, and initiates full/partial refund."""
        order = self.order_service.get_order(order_id)

        if order.status in (OrderStatus.DELIVERED, OrderStatus.CANCELLED, OrderStatus.RETURNED):
            raise ValidationError(f"Cannot cancel order with current status '{order.status.value}'.")

        # Deduct restocking fee if cancelled after SHIPPED / OUT_FOR_DELIVERY
        fee = Decimal("0.00")
        if order.status in (OrderStatus.SHIPPED, OrderStatus.OUT_FOR_DELIVERY):
            fee = RESTOCKING_FEE_SHIPPED

        now = self.clock.now()
        order.status = OrderStatus.CANCELLED
        order.cancelled_at = now
        order.cancellation_reason = reason.strip()

        # Release stock back to available pool
        for item in order.items:
            self.order_service.inventory_service.release_stock(item.product_id, item.quantity)

        # Issue refund if payment was settled
        orig_tx = self.payment_service.get_transaction_by_order(order_id)
        if orig_tx and orig_tx.status == PaymentStatus.COMPLETED and orig_tx.payment_method != PaymentMethod.CASH_ON_DELIVERY:
            refund_amount = max(Decimal("0.00"), orig_tx.amount - fee)
            if refund_amount > Decimal("0.00"):
                self.process_refund(order_id, refund_amount, reason=f"Cancellation refund (fee {fee})")

        return order

    def request_return(self, order_id: str, reason: str) -> Order:
        """Processes return for delivered orders within 7-day policy window."""
        order = self.order_service.get_order(order_id)

        if order.status != OrderStatus.DELIVERED:
            raise ValidationError("Returns can only be requested for DELIVERED orders.")

        now = self.clock.now()
        if order.delivered_at:
            elapsed_days = (now - order.delivered_at).days
            if elapsed_days > RETURN_WINDOW_DAYS:
                raise ReturnPolicyViolationError(
                    f"Return requested {elapsed_days} days after delivery. Allowed policy is {RETURN_WINDOW_DAYS} days."
                )

        order.status = OrderStatus.RETURNED
        order.returned_at = now
        order.cancellation_reason = f"Returned: {reason.strip()}"

        # Restock inventory
        for item in order.items:
            # Replenish stock back into inventory
            self.order_service.inventory_service.add_warehouse_stock(
                warehouse_id="WH-RETURN",
                product_id=item.product_id,
                quantity=item.quantity,
            )

        # Process full refund
        orig_tx = self.payment_service.get_transaction_by_order(order_id)
        if orig_tx and orig_tx.status == PaymentStatus.COMPLETED:
            self.process_refund(order_id, orig_tx.amount, reason=f"Return refund: {reason}")

        return order

    def process_refund(
        self,
        order_id: str,
        refund_amount: Decimal,
        reason: str = "Refund",
    ) -> Transaction:
        """Executes refund through original payment instrument or customer wallet."""
        orig_tx = self.payment_service.get_transaction_by_order(order_id)
        if not orig_tx:
            raise ValidationError(f"No payment record found for order '{order_id}'.")

        if orig_tx.transaction_id in self._refunds:
            raise ValidationError(f"Transaction '{orig_tx.transaction_id}' has already been refunded.")

        actual_refund = round_currency(refund_amount)
        if actual_refund <= Decimal("0.00") or actual_refund > orig_tx.amount:
            raise ValidationError(f"Invalid refund amount: {actual_refund}.")

        refund_tx_id = self.id_gen.generate("RFD")
        now = self.clock.now()

        # Wallet or COD refunds credited directly to customer wallet
        if orig_tx.payment_method in (PaymentMethod.WALLET, PaymentMethod.CASH_ON_DELIVERY):
            self.user_service.add_wallet_funds(orig_tx.customer_id, actual_refund)
            refund_tx = Transaction(
                transaction_id=refund_tx_id,
                order_id=order_id,
                customer_id=orig_tx.customer_id,
                amount=actual_refund,
                payment_method=PaymentMethod.WALLET,
                status=PaymentStatus.REFUNDED,
                created_at=now,
                gateway_reference=f"WALLET-REFUND-{refund_tx_id}",
                notes=reason,
            )
        else:
            # External Gateway refund (Card/UPI)
            gw_ok = self.gateway.refund(orig_tx.gateway_reference or "", actual_refund)
            if not gw_ok:
                raise ValidationError("Payment gateway failed to process refund.")

            refund_tx = Transaction(
                transaction_id=refund_tx_id,
                order_id=order_id,
                customer_id=orig_tx.customer_id,
                amount=actual_refund,
                payment_method=orig_tx.payment_method,
                status=PaymentStatus.REFUNDED,
                created_at=now,
                gateway_reference=f"GW-REF-{refund_tx_id}",
                notes=reason,
            )

        self._refunds[orig_tx.transaction_id] = refund_tx_id
        self.payment_service._transactions[refund_tx_id] = refund_tx
        orig_tx.status = PaymentStatus.REFUNDED
        return refund_tx

