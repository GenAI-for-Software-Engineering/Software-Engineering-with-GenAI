"""Unified facade orchestrating the entire e-commerce shopping and fulfillment pipeline."""

from decimal import Decimal
from typing import Any, Dict, List, Optional

from ecommerce_fulfillment.analytics import AnalyticsService
from ecommerce_fulfillment.cancellation import ReturnCancellationService
from ecommerce_fulfillment.inventory import InventoryService
from ecommerce_fulfillment.models import (
    Address,
    MembershipTier,
    Order,
    PaymentMethod,
    Product,
    ProductCategory,
    Shipment,
    Transaction,
    User,
    UserRole,
)
from ecommerce_fulfillment.notification import NotificationService
from ecommerce_fulfillment.order import OrderService
from ecommerce_fulfillment.payment import MockPaymentGateway, PaymentGateway, PaymentService
from ecommerce_fulfillment.pricing import PricingService
from ecommerce_fulfillment.shipping import ShippingService
from ecommerce_fulfillment.user import UserService
from ecommerce_fulfillment.utils import Clock, IdGenerator


class EcommerceFulfillmentSystem:
    """Top-level facade exposing all domain services for clean testing and orchestration."""

    def __init__(
        self,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
        payment_gateway: Optional[PaymentGateway] = None,
    ):
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self.gateway = payment_gateway or MockPaymentGateway()

        # Wire core modular services
        self.user_service = UserService(clock=self.clock, id_gen=self.id_gen)
        self.inventory_service = InventoryService(id_gen=self.id_gen)
        self.pricing_service = PricingService()
        self.order_service = OrderService(
            user_service=self.user_service,
            inventory_service=self.inventory_service,
            pricing_service=self.pricing_service,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.shipping_service = ShippingService(
            order_service=self.order_service,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.payment_service = PaymentService(
            order_service=self.order_service,
            user_service=self.user_service,
            gateway=self.gateway,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.cancellation_service = ReturnCancellationService(
            order_service=self.order_service,
            payment_service=self.payment_service,
            user_service=self.user_service,
            gateway=self.gateway,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.notification_service = NotificationService(
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.analytics_service = AnalyticsService(
            order_service=self.order_service,
        )

    # --- High-level workflows ---

    def register_customer(
        self,
        name: str,
        email: str,
        phone: str,
        tier: MembershipTier = MembershipTier.STANDARD,
        initial_wallet: Decimal = Decimal("0.00"),
    ) -> User:
        """Registers a customer."""
        return self.user_service.register_user(
            name=name,
            email=email,
            phone=phone,
            role=UserRole.CUSTOMER,
            tier=tier,
            initial_wallet=initial_wallet,
        )

    def register_seller(
        self,
        name: str,
        email: str,
        phone: str,
    ) -> User:
        """Registers a merchant / seller."""
        return self.user_service.register_user(
            name=name,
            email=email,
            phone=phone,
            role=UserRole.SELLER,
        )

    def place_order_and_pay(
        self,
        customer_id: str,
        shipping_address: Address,
        item_specs: List[Dict[str, int]],
        payment_method: PaymentMethod,
        coupon_code: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Places an order, reserves inventory, computes invoice, and executes payment."""
        order = self.order_service.create_order(
            customer_id=customer_id,
            shipping_address=shipping_address,
            item_specs=item_specs,
            coupon_code=coupon_code,
        )

        transaction = self.payment_service.process_order_payment(
            order_id=order.order_id,
            payment_method=payment_method,
        )

        customer = self.user_service.get_user(customer_id)
        if order.pricing:
            amount_str = f"INR {order.pricing.final_total:.2f}"
            self.notification_service.notify_order_confirmed(
                customer_id=customer_id,
                email=customer.email,
                order_id=order.order_id,
                amount_str=amount_str,
            )

        return {
            "order": order,
            "transaction": transaction,
        }

    def fulfill_order_to_delivery(self, order_id: str) -> Shipment:
        """Simulates full warehouse packing, courier dispatch, and customer delivery."""
        self.order_service.pack_order(order_id)
        shipment = self.shipping_service.dispatch_shipment(order_id)

        customer_id = self.order_service.get_order(order_id).customer_id
        customer = self.user_service.get_user(customer_id)

        self.notification_service.notify_shipment_dispatched(
            customer_id=customer_id,
            phone=customer.phone,
            order_id=order_id,
            tracking_number=shipment.tracking_number,
        )

        self.order_service.mark_out_for_delivery(order_id)
        self.shipping_service.confirm_delivery(shipment.tracking_number)
        return shipment

