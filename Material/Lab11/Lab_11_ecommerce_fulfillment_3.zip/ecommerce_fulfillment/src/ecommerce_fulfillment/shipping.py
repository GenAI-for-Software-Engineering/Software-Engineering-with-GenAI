"""Logistics courier allocation, tracking numbers, and delivery checkpoint progression."""

from datetime import timedelta
from typing import Dict, List, Optional

from ecommerce_fulfillment.exceptions import ShipmentNotFoundError, ValidationError
from ecommerce_fulfillment.models import CourierPartner, Order, OrderStatus, Shipment
from ecommerce_fulfillment.order import OrderService
from ecommerce_fulfillment.utils import Clock, IdGenerator

STANDARD_DELIVERY_DAYS = 3


class ShippingService:
    """Manages courier selection, dispatch, tracking updates, and delivery confirmations."""

    def __init__(
        self,
        order_service: OrderService,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.order_service = order_service
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._shipments: Dict[str, Shipment] = {}  # tracking_number -> Shipment
        self._order_shipment_map: Dict[str, str] = {}  # order_id -> tracking_number

    def select_courier(self, total_weight_kg: float, destination_pincode: str) -> CourierPartner:
        """Deterministically selects courier based on weight and postal zone."""
        # Heavy packages (> 10kg) route through BlueDart
        if total_weight_kg > 10.0:
            return CourierPartner.BLUE_DART

        # Metro zones (starting with 110, 400, 560, 600) route through Ekart
        metro_prefixes = ("110", "400", "560", "600", "700")
        if destination_pincode.startswith(metro_prefixes):
            return CourierPartner.EKART

        return CourierPartner.DELHIVERY

    def dispatch_shipment(self, order_id: str) -> Shipment:
        """Creates tracking record, selects carrier, and sets estimated delivery."""
        order = self.order_service.get_order(order_id)
        if order.status != OrderStatus.PACKED:
            raise ValidationError(f"Cannot dispatch order in status '{order.status.value}'. Must be PACKED.")

        total_weight = sum(
            self.order_service.inventory_service.get_product(item.product_id).weight_kg * item.quantity
            for item in order.items
        )

        courier = self.select_courier(total_weight, order.shipping_address.pincode)
        tracking_num = self.id_gen.generate("TRK")

        now = self.clock.now()
        estimated = now + timedelta(days=STANDARD_DELIVERY_DAYS)

        shipment = Shipment(
            tracking_number=tracking_num,
            order_id=order_id,
            courier=courier,
            dispatched_at=now,
            estimated_delivery=estimated,
            current_checkpoint="Dispatched from Fulfillment Hub",
        )

        # Transition order to SHIPPED
        self.order_service.ship_order(order_id)

        self._shipments[tracking_num] = shipment
        self._order_shipment_map[order_id] = tracking_num
        return shipment

    def update_checkpoint(self, tracking_number: str, checkpoint: str) -> Shipment:
        """Updates transit checkpoint location."""
        shipment = self.get_shipment(tracking_number)
        if not checkpoint.strip():
            raise ValidationError("Checkpoint cannot be empty.")
        shipment.current_checkpoint = checkpoint.strip()
        return shipment

    def confirm_delivery(self, tracking_number: str) -> Shipment:
        """Marks shipment delivered and synchronizes order status to DELIVERED."""
        shipment = self.get_shipment(tracking_number)
        now = self.clock.now()
        shipment.delivered_at = now
        shipment.current_checkpoint = "Delivered to Customer"

        self.order_service.mark_delivered(shipment.order_id)
        return shipment

    def get_shipment(self, tracking_number: str) -> Shipment:
        """Retrieves shipment by tracking number."""
        if tracking_number not in self._shipments:
            raise ShipmentNotFoundError(tracking_number)
        return self._shipments[tracking_number]

    def get_shipment_by_order(self, order_id: str) -> Optional[Shipment]:
        """Gets shipment record for order if dispatched."""
        trk = self._order_shipment_map.get(order_id)
        if not trk:
            return None
        return self._shipments.get(trk)

