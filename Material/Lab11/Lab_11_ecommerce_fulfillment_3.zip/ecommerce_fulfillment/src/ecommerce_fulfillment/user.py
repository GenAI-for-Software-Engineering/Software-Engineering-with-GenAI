"""Customer and Seller registration, addresses, wallet operations, and loyalty tiers."""

from decimal import Decimal
from typing import Dict, List, Optional

from ecommerce_fulfillment.exceptions import (
    DuplicateUserError,
    InsufficientWalletBalanceError,
    UserNotFoundError,
    ValidationError,
)
from ecommerce_fulfillment.models import Address, MembershipTier, User, UserRole
from ecommerce_fulfillment.utils import (
    Clock,
    IdGenerator,
    round_currency,
    validate_email,
    validate_phone,
    validate_pincode,
)


class UserService:
    """Manages user profiles, tier perks, delivery addresses, and wallet balances."""

    def __init__(self, clock: Optional[Clock] = None, id_gen: Optional[IdGenerator] = None):
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._users: Dict[str, User] = {}
        self._email_index: Dict[str, str] = {}

    def register_user(
        self,
        name: str,
        email: str,
        phone: str,
        role: UserRole = UserRole.CUSTOMER,
        tier: MembershipTier = MembershipTier.STANDARD,
        initial_wallet: Decimal = Decimal("0.00"),
    ) -> User:
        """Registers a customer or seller profile."""
        if not name or not name.strip():
            raise ValidationError("Name cannot be empty.")

        clean_email = validate_email(email)
        clean_phone = validate_phone(phone)

        if clean_email in self._email_index:
            raise DuplicateUserError(clean_email)

        if initial_wallet < Decimal("0.00"):
            raise ValidationError("Initial wallet balance cannot be negative.")

        prefix = "CUST" if role == UserRole.CUSTOMER else "SELL"
        user_id = self.id_gen.generate(prefix)

        user = User(
            user_id=user_id,
            name=name.strip(),
            email=clean_email,
            phone=clean_phone,
            role=role,
            tier=tier,
            wallet_balance=round_currency(initial_wallet),
            created_at=self.clock.now(),
        )

        self._users[user_id] = user
        self._email_index[clean_email] = user_id
        return user

    def add_address(
        self,
        user_id: str,
        street: str,
        city: str,
        state: str,
        pincode: str,
    ) -> Address:
        """Adds a verified postal shipping address to user's profile."""
        user = self.get_user(user_id)
        clean_pin = validate_pincode(pincode)

        if not street.strip() or not city.strip() or not state.strip():
            raise ValidationError("Street, city, and state cannot be empty.")

        addr = Address(
            street=street.strip(),
            city=city.strip(),
            state=state.strip(),
            pincode=clean_pin,
            is_serviceable=True,
        )
        user.addresses.append(addr)
        return addr

    def upgrade_tier(self, user_id: str, new_tier: MembershipTier) -> User:
        """Upgrades customer membership tier."""
        user = self.get_user(user_id)
        user.tier = new_tier
        return user

    def add_wallet_funds(self, user_id: str, amount: Decimal) -> Decimal:
        """Adds funds to in-app wallet balance."""
        user = self.get_user(user_id)
        if amount <= Decimal("0.00"):
            raise ValidationError("Funds to add must be positive.")
        user.wallet_balance = round_currency(user.wallet_balance + amount)
        return user.wallet_balance

    def deduct_wallet_funds(self, user_id: str, amount: Decimal) -> Decimal:
        """Deducts funds from wallet balance."""
        user = self.get_user(user_id)
        if amount <= Decimal("0.00"):
            raise ValidationError("Funds to deduct must be positive.")
        amount = round_currency(amount)
        if user.wallet_balance < amount:
            raise InsufficientWalletBalanceError(required=str(amount), available=str(user.wallet_balance))
        user.wallet_balance = round_currency(user.wallet_balance - amount)
        return user.wallet_balance

    def get_user(self, user_id: str) -> User:
        """Retrieves user profile."""
        if user_id not in self._users:
            raise UserNotFoundError(user_id)
        return self._users[user_id]

    def list_users(self) -> List[User]:
        """Returns all registered users."""
        return list(self._users.values())

