"""Order creation, state machine transitions, packing, and history."""

from decimal import Decimal
from typing import Dict, List, Optional

from ecommerce_fulfillment.exceptions import (
    InvalidOrderStateTransitionError,
    OrderNotFoundError,
    ValidationError,
)
from ecommerce_fulfillment.inventory import InventoryService
from ecommerce_fulfillment.models import (
    Address,
    Order,
    OrderItem,
    OrderStatus,
    PricingBreakdown,
)
from ecommerce_fulfillment.pricing import PricingService
from ecommerce_fulfillment.user import UserService
from ecommerce_fulfillment.utils import Clock, IdGenerator

VALID_ORDER_TRANSITIONS = {
    OrderStatus.CREATED: [OrderStatus.CONFIRMED, OrderStatus.CANCELLED],
    OrderStatus.CONFIRMED: [OrderStatus.PACKED, OrderStatus.CANCELLED],
    OrderStatus.PACKED: [OrderStatus.SHIPPED, OrderStatus.CANCELLED],
    OrderStatus.SHIPPED: [OrderStatus.OUT_FOR_DELIVERY, OrderStatus.CANCELLED],
    OrderStatus.OUT_FOR_DELIVERY: [OrderStatus.DELIVERED, OrderStatus.CANCELLED],
    OrderStatus.DELIVERED: [OrderStatus.RETURNED],
    OrderStatus.CANCELLED: [],
    OrderStatus.RETURNED: [],
}


class OrderService:
    """Orchestrates order placement, stock locking, pricing calculations, and lifecycle transitions."""

    def __init__(
        self,
        user_service: UserService,
        inventory_service: InventoryService,
        pricing_service: PricingService,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.user_service = user_service
        self.inventory_service = inventory_service
        self.pricing_service = pricing_service
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._orders: Dict[str, Order] = {}

    def create_order(
        self,
        customer_id: str,
        shipping_address: Address,
        item_specs: List[Dict[str, int]],  # [{"product_id": "...", "quantity": 2}]
        coupon_code: Optional[str] = None,
    ) -> Order:
        """Validates inventory, reserves stock, computes taxes/shipping, and creates order."""
        customer = self.user_service.get_user(customer_id)
        if not shipping_address.is_serviceable:
            raise ValidationError("Shipping address is not in serviceable zone.")
        if not item_specs:
            raise ValidationError("Cannot create order with empty item list.")

        # 1. Build and validate order line items
        order_items: List[OrderItem] = []
        for spec in item_specs:
            p_id = spec["product_id"]
            qty = spec["quantity"]
            if qty <= 0:
                raise ValidationError("Item quantity must be greater than zero.")

            product = self.inventory_service.get_product(p_id)
            if not product.is_active:
                raise ValidationError(f"Product '{product.title}' is inactive.")

            unit_price = product.base_price
            order_items.append(
                OrderItem(
                    product_id=product.product_id,
                    title=product.title,
                    category=product.category,
                    quantity=qty,
                    unit_price=unit_price,
                    total_price=unit_price * Decimal(str(qty)),
                )
            )

        # 2. Reserve stock in inventory
        reserved_items = []
        try:
            for item in order_items:
                self.inventory_service.reserve_stock(item.product_id, item.quantity)
                reserved_items.append((item.product_id, item.quantity))
        except Exception:
            # Rollback any stock reserved during this transaction
            for p_id, q in reserved_items:
                self.inventory_service.release_stock(p_id, q)
            raise

        # 3. Calculate pricing & discounts
        now = self.clock.now()
        pricing = self.pricing_service.calculate_invoice(
            items=order_items,
            customer_tier=customer.tier,
            coupon_code=coupon_code,
            current_time=now,
        )

        if coupon_code:
            self.pricing_service.record_coupon_usage(coupon_code)

        # 4. Construct Order record
        order_id = self.id_gen.generate("ORD")
        order = Order(
            order_id=order_id,
            customer_id=customer_id,
            shipping_address=shipping_address,
            items=order_items,
            status=OrderStatus.CREATED,
            pricing=pricing,
            created_at=now,
        )
        self._orders[order_id] = order
        return order

    def _validate_transition(self, order: Order, target_status: OrderStatus) -> None:
        """Guards against illegal state transitions."""
        allowed = VALID_ORDER_TRANSITIONS.get(order.status, [])
        if target_status not in allowed:
            raise InvalidOrderStateTransitionError(order.status.value, target_status.value)

    def confirm_order(self, order_id: str) -> Order:
        """Transitions order to CONFIRMED after payment settlement."""
        order = self.get_order(order_id)
        self._validate_transition(order, OrderStatus.CONFIRMED)
        order.status = OrderStatus.CONFIRMED
        order.confirmed_at = self.clock.now()
        return order

    def pack_order(self, order_id: str) -> Order:
        """Warehouse completes packaging of items."""
        order = self.get_order(order_id)
        self._validate_transition(order, OrderStatus.PACKED)
        order.status = OrderStatus.PACKED
        return order

    def ship_order(self, order_id: str) -> Order:
        """Handover to courier service; commits inventory permanently."""
        order = self.get_order(order_id)
        self._validate_transition(order, OrderStatus.SHIPPED)

        # Commit reserved inventory
        for item in order.items:
            self.inventory_service.commit_stock(item.product_id, item.quantity)

        order.status = OrderStatus.SHIPPED
        order.shipped_at = self.clock.now()
        return order

    def mark_out_for_delivery(self, order_id: str) -> Order:
        """Courier driver departs for final doorstep delivery."""
        order = self.get_order(order_id)
        self._validate_transition(order, OrderStatus.OUT_FOR_DELIVERY)
        order.status = OrderStatus.OUT_FOR_DELIVERY
        return order

    def mark_delivered(self, order_id: str) -> Order:
        """Customer receives parcel."""
        order = self.get_order(order_id)
        self._validate_transition(order, OrderStatus.DELIVERED)
        order.status = OrderStatus.DELIVERED
        order.delivered_at = self.clock.now()
        return order

    def get_order(self, order_id: str) -> Order:
        """Retrieves order by ID."""
        if order_id not in self._orders:
            raise OrderNotFoundError(order_id)
        return self._orders[order_id]

    def list_customer_orders(self, customer_id: str) -> List[Order]:
        """Lists orders placed by a customer."""
        return [o for o in self._orders.values() if o.customer_id == customer_id]

