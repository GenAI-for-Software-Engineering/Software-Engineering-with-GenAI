"""Product catalog, warehouse stock allocation, stock reservation, and release."""

from decimal import Decimal
from typing import Dict, List, Optional

from ecommerce_fulfillment.exceptions import (
    InsufficientStockError,
    ProductNotFoundError,
    ValidationError,
)
from ecommerce_fulfillment.models import Product, ProductCategory, WarehouseInventory
from ecommerce_fulfillment.utils import IdGenerator, round_currency


class InventoryService:
    """Manages product catalog and multi-warehouse stock reservation/fulfillment."""

    def __init__(self, id_gen: Optional[IdGenerator] = None):
        self.id_gen = id_gen or IdGenerator()
        self._products: Dict[str, Product] = {}
        # Key: (warehouse_id, product_id) -> WarehouseInventory
        self._stock: Dict[tuple, WarehouseInventory] = {}

    def add_product(
        self,
        seller_id: str,
        title: str,
        category: ProductCategory,
        base_price: Decimal,
        weight_kg: float,
    ) -> Product:
        """Adds a new product to catalog."""
        if not title or not title.strip():
            raise ValidationError("Product title cannot be empty.")
        if base_price <= Decimal("0.00"):
            raise ValidationError("Base price must be greater than zero.")
        if weight_kg <= 0.0:
            raise ValidationError("Weight must be greater than zero.")

        product_id = self.id_gen.generate("PROD")
        product = Product(
            product_id=product_id,
            seller_id=seller_id,
            title=title.strip(),
            category=category,
            base_price=round_currency(base_price),
            weight_kg=round(weight_kg, 2),
            is_active=True,
        )
        self._products[product_id] = product
        return product

    def get_product(self, product_id: str) -> Product:
        """Retrieves product by ID."""
        if product_id not in self._products:
            raise ProductNotFoundError(product_id)
        return self._products[product_id]

    def add_warehouse_stock(
        self,
        warehouse_id: str,
        product_id: str,
        quantity: int,
    ) -> WarehouseInventory:
        """Replenishes stock at a specific warehouse."""
        self.get_product(product_id)
        if quantity <= 0:
            raise ValidationError("Replenishment quantity must be positive.")

        key = (warehouse_id, product_id)
        if key not in self._stock:
            self._stock[key] = WarehouseInventory(
                warehouse_id=warehouse_id,
                product_id=product_id,
                available_qty=quantity,
                reserved_qty=0,
            )
        else:
            self._stock[key].available_qty += quantity

        return self._stock[key]

    def get_total_available_stock(self, product_id: str) -> int:
        """Sums available stock across all warehouses."""
        self.get_product(product_id)
        return sum(inv.available_qty for (w_id, p_id), inv in self._stock.items() if p_id == product_id)

    def reserve_stock(self, product_id: str, quantity: int) -> str:
        """Reserves stock from the warehouse with the highest available inventory."""
        self.get_product(product_id)
        if quantity <= 0:
            raise ValidationError("Reservation quantity must be positive.")

        total_avail = self.get_total_available_stock(product_id)
        if total_avail < quantity:
            raise InsufficientStockError(product_id, requested=quantity, available=total_avail)

        # Allocate from warehouse with sufficient stock
        for (w_id, p_id), inv in self._stock.items():
            if p_id == product_id and inv.available_qty >= quantity:
                inv.available_qty -= quantity
                inv.reserved_qty += quantity
                return w_id

        # If spread across warehouses, reserve proportionally
        remaining = quantity
        allocated_warehouse = "WH-MULTI"
        for (w_id, p_id), inv in self._stock.items():
            if p_id == product_id and inv.available_qty > 0:
                to_reserve = min(remaining, inv.available_qty)
                inv.available_qty -= to_reserve
                inv.reserved_qty += to_reserve
                remaining -= to_reserve
                if remaining == 0:
                    break

        return allocated_warehouse

    def release_stock(self, product_id: str, quantity: int) -> None:
        """Releases reserved stock back to available pool upon order cancellation."""
        remaining = quantity
        for (w_id, p_id), inv in self._stock.items():
            if p_id == product_id and inv.reserved_qty > 0:
                to_release = min(remaining, inv.reserved_qty)
                inv.reserved_qty -= to_release
                inv.available_qty += to_release
                remaining -= to_release
                if remaining == 0:
                    break

    def commit_stock(self, product_id: str, quantity: int) -> None:
        """Deducts reserved stock permanently upon shipment dispatch."""
        remaining = quantity
        for (w_id, p_id), inv in self._stock.items():
            if p_id == product_id and inv.reserved_qty > 0:
                to_commit = min(remaining, inv.reserved_qty)
                inv.reserved_qty -= to_commit
                remaining -= to_commit
                if remaining == 0:
                    break

