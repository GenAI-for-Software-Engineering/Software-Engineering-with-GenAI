"""Domain models, enumerations, and dataclasses for E-Commerce Fulfillment System."""

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import List, Optional


class MembershipTier(str, Enum):
    """Customer loyalty tier."""
    STANDARD = "STANDARD"
    PRIME = "PRIME"
    VIP = "VIP"


class UserRole(str, Enum):
    """User operational roles."""
    CUSTOMER = "CUSTOMER"
    SELLER = "SELLER"
    ADMIN = "ADMIN"


class ProductCategory(str, Enum):
    """Supported product categories with varying tax & handling."""
    ELECTRONICS = "ELECTRONICS"
    APPAREL = "APPAREL"
    GROCERY = "GROCERY"
    BOOKS = "BOOKS"
    HOME_APPLIANCES = "HOME_APPLIANCES"


class OrderStatus(str, Enum):
    """Order progression lifecycle states."""
    CREATED = "CREATED"
    CONFIRMED = "CONFIRMED"
    PACKED = "PACKED"
    SHIPPED = "SHIPPED"
    OUT_FOR_DELIVERY = "OUT_FOR_DELIVERY"
    DELIVERED = "DELIVERED"
    CANCELLED = "CANCELLED"
    RETURNED = "RETURNED"


class PaymentMethod(str, Enum):
    """Supported payment modes."""
    CREDIT_CARD = "CREDIT_CARD"
    UPI = "UPI"
    WALLET = "WALLET"
    CASH_ON_DELIVERY = "CASH_ON_DELIVERY"


class PaymentStatus(str, Enum):
    """Payment transaction states."""
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    REFUNDED = "REFUNDED"


class CourierPartner(str, Enum):
    """Available delivery couriers."""
    BLUE_DART = "BLUE_DART"
    DELHIVERY = "DELHIVERY"
    EKART = "EKART"


@dataclass
class Address:
    """Shipping and billing postal address."""
    street: str
    city: str
    state: str
    pincode: str
    is_serviceable: bool = True


@dataclass
class User:
    """Customer or merchant entity."""
    user_id: str
    name: str
    email: str
    phone: str
    role: UserRole
    tier: MembershipTier = MembershipTier.STANDARD
    is_active: bool = True
    wallet_balance: Decimal = field(default_factory=lambda: Decimal("0.00"))
    addresses: List[Address] = field(default_factory=list)
    created_at: Optional[datetime] = None


@dataclass
class Product:
    """Product catalog item."""
    product_id: str
    seller_id: str
    title: str
    category: ProductCategory
    base_price: Decimal
    weight_kg: float
    is_active: bool = True


@dataclass
class WarehouseInventory:
    """Product stock allocation across warehouses."""
    warehouse_id: str
    product_id: str
    available_qty: int
    reserved_qty: int = 0


@dataclass
class OrderItem:
    """Line item in an order."""
    product_id: str
    title: str
    category: ProductCategory
    quantity: int
    unit_price: Decimal
    total_price: Decimal


@dataclass
class PricingBreakdown:
    """Itemized invoice totals."""
    items_subtotal: Decimal
    discount_amount: Decimal
    shipping_fee: Decimal
    tax_amount: Decimal
    final_total: Decimal


@dataclass
class Order:
    """Customer order record."""
    order_id: str
    customer_id: str
    shipping_address: Address
    items: List[OrderItem]
    status: OrderStatus = OrderStatus.CREATED
    pricing: Optional[PricingBreakdown] = None
    created_at: Optional[datetime] = None
    confirmed_at: Optional[datetime] = None
    shipped_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    cancelled_at: Optional[datetime] = None
    returned_at: Optional[datetime] = None
    cancellation_reason: Optional[str] = None


@dataclass
class Shipment:
    """Logistics shipment tracking record."""
    tracking_number: str
    order_id: str
    courier: CourierPartner
    dispatched_at: datetime
    estimated_delivery: datetime
    delivered_at: Optional[datetime] = None
    current_checkpoint: str = "Warehouse"


@dataclass
class Transaction:
    """Financial ledger payment record."""
    transaction_id: str
    order_id: str
    customer_id: str
    amount: Decimal
    payment_method: PaymentMethod
    status: PaymentStatus
    created_at: datetime
    gateway_reference: Optional[str] = None
    notes: Optional[str] = None


@dataclass
class NotificationMessage:
    """Customer SMS / Email message dispatch record."""
    notification_id: str
    recipient_id: str
    channel: str
    subject: str
    body: str
    sent_at: datetime
    success: bool

