"""Utilities, testable clock, sequential ID generator, and input validators."""

from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
import re
from typing import Optional
import uuid

from ecommerce_fulfillment.exceptions import ValidationError


class Clock:
    """Testable system clock interface allowing fixed or injectable time."""

    def __init__(self, fixed_time: Optional[datetime] = None):
        self._fixed_time = fixed_time

    def now(self) -> datetime:
        """Returns current UTC datetime or fixed test time."""
        if self._fixed_time is not None:
            return self._fixed_time
        return datetime.now(timezone.utc)

    def set_time(self, new_time: datetime) -> None:
        """Sets a fixed test time."""
        self._fixed_time = new_time

    def advance_days(self, days: float) -> None:
        """Advances current test time by days."""
        from datetime import timedelta
        base = self.now()
        self._fixed_time = base + timedelta(days=days)


class IdGenerator:
    """Testable identifier generator with optional deterministic sequence."""

    def __init__(self, prefix_seed: Optional[str] = None):
        self._counter = 0
        self._prefix_seed = prefix_seed

    def generate(self, prefix: str) -> str:
        """Generates an ID. If prefix_seed is set, generates sequential deterministic IDs."""
        if self._prefix_seed is not None:
            self._counter += 1
            return f"{prefix}-{self._prefix_seed}-{self._counter:04d}"
        random_suffix = uuid.uuid4().hex[:8]
        return f"{prefix}-{random_suffix}"


EMAIL_REGEX = re.compile(r"^[\w\.-]+@([\w-]+\.)+[\w-]{2,4}$")
PHONE_REGEX = re.compile(r"^\+?[1-9]\d{7,14}$")
PINCODE_REGEX = re.compile(r"^[1-9][0-9]{5}$")


def validate_email(email: str) -> str:
    """Validates and normalizes email."""
    if not email or not isinstance(email, str):
        raise ValidationError("Email must be a non-empty string.")
    normalized = email.strip().lower()
    if not EMAIL_REGEX.match(normalized):
        raise ValidationError(f"Invalid email format: '{email}'.")
    return normalized


def validate_phone(phone: str) -> str:
    """Validates phone number."""
    if not phone or not isinstance(phone, str):
        raise ValidationError("Phone must be a non-empty string.")
    cleaned = phone.strip().replace(" ", "").replace("-", "")
    if not PHONE_REGEX.match(cleaned):
        raise ValidationError(f"Invalid phone number format: '{phone}'.")
    return cleaned


def validate_pincode(pincode: str) -> str:
    """Validates standard 6-digit Indian postal code."""
    if not pincode or not isinstance(pincode, str):
        raise ValidationError("Pincode must be a non-empty string.")
    cleaned = pincode.strip()
    if not PINCODE_REGEX.match(cleaned):
        raise ValidationError(f"Invalid 6-digit pincode: '{pincode}'.")
    return cleaned


def round_currency(amount: Decimal) -> Decimal:
    """Rounds decimal monetary amount to 2 decimal places."""
    if not isinstance(amount, Decimal):
        amount = Decimal(str(amount))
    return amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

