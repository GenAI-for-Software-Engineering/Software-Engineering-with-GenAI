"""Domain exceptions for the E-Commerce Order & Inventory Fulfillment System."""


class EcommerceError(Exception):
    """Base exception for all domain errors."""

    def __init__(self, message: str, code: str = "ECOM_ERROR"):
        super().__init__(message)
        self.message = message
        self.code = code

    def __str__(self) -> str:
        return f"[{self.code}] {self.message}"


class ValidationError(EcommerceError):
    """Raised when parameter or input validation fails."""

    def __init__(self, message: str):
        super().__init__(message, code="VALIDATION_ERROR")


class UserNotFoundError(EcommerceError):
    """Raised when customer or seller does not exist."""

    def __init__(self, user_id: str):
        super().__init__(f"User '{user_id}' not found.", code="USER_NOT_FOUND")


class DuplicateUserError(EcommerceError):
    """Raised when duplicate email or phone is registered."""

    def __init__(self, identifier: str):
        super().__init__(f"User already exists with identifier: {identifier}", code="DUPLICATE_USER")


class ProductNotFoundError(EcommerceError):
    """Raised when requested product cannot be found."""

    def __init__(self, product_id: str):
        super().__init__(f"Product '{product_id}' not found.", code="PRODUCT_NOT_FOUND")


class InsufficientStockError(EcommerceError):
    """Raised when requested item quantity exceeds available inventory."""

    def __init__(self, product_id: str, requested: int, available: int):
        super().__init__(
            f"Insufficient stock for product '{product_id}': requested {requested}, available {available}.",
            code="INSUFFICIENT_STOCK",
        )


class OrderNotFoundError(EcommerceError):
    """Raised when order record is not found."""

    def __init__(self, order_id: str):
        super().__init__(f"Order '{order_id}' not found.", code="ORDER_NOT_FOUND")


class InvalidOrderStateTransitionError(EcommerceError):
    """Raised when illegal lifecycle status transition is attempted."""

    def __init__(self, current_status: str, target_status: str):
        super().__init__(
            f"Invalid transition from state '{current_status}' to '{target_status}'.",
            code="INVALID_STATE_TRANSITION",
        )


class CouponError(EcommerceError):
    """Raised when a promotional coupon code is invalid, expired, or exhausted."""

    def __init__(self, reason: str):
        super().__init__(f"Coupon error: {reason}", code="COUPON_ERROR")


class PaymentFailedError(EcommerceError):
    """Raised when payment processing fails."""

    def __init__(self, reason: str):
        super().__init__(f"Payment failed: {reason}", code="PAYMENT_FAILED")


class DuplicatePaymentError(EcommerceError):
    """Raised when paying for an already settled order."""

    def __init__(self, order_id: str):
        super().__init__(f"Order '{order_id}' has already been paid.", code="DUPLICATE_PAYMENT")


class InsufficientWalletBalanceError(EcommerceError):
    """Raised when customer's wallet has insufficient balance."""

    def __init__(self, required: str, available: str):
        super().__init__(
            f"Insufficient wallet funds: required {required}, available {available}.",
            code="INSUFFICIENT_WALLET",
        )


class ReturnPolicyViolationError(EcommerceError):
    """Raised when return or refund is requested outside allowed return window."""

    def __init__(self, reason: str):
        super().__init__(f"Return policy violated: {reason}", code="RETURN_POLICY_VIOLATION")


class ShipmentNotFoundError(EcommerceError):
    """Raised when shipment tracking record does not exist."""

    def __init__(self, tracking_number: str):
        super().__init__(f"Shipment '{tracking_number}' not found.", code="SHIPMENT_NOT_FOUND")

