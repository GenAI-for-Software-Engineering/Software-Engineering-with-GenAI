"""Driver lifecycle, verification, rating tracking, and real-time state management."""

import re
from typing import Dict, List, Optional

from ride_management.exceptions import (
    DriverNotAvailableError,
    DriverNotFoundError,
    ValidationError,
)
from ride_management.models import Coordinates, DriverProfile, DriverStatus
from ride_management.vehicle import VehicleService

LICENSE_REGEX = re.compile(r"^[A-Z]{2}[0-9]{2}[0-9]{11}$")
MINIMUM_ELIGIBLE_RATING = 3.0


class DriverService:
    """Manages driver status, compliance, ratings, and active geo-locations."""

    def __init__(self, vehicle_service: VehicleService):
        self.vehicle_service = vehicle_service
        self._drivers: Dict[str, DriverProfile] = {}
        self._license_index: Dict[str, str] = {}

    def register_driver(
        self,
        driver_id: str,
        license_number: str,
        initial_location: Optional[Coordinates] = None,
    ) -> DriverProfile:
        """Registers driver credentials for an existing user account."""
        if not driver_id:
            raise ValidationError("Driver ID is required.")

        if driver_id in self._drivers:
            raise ValidationError(f"Driver '{driver_id}' is already registered.")

        clean_license = license_number.strip().upper().replace(" ", "").replace("-", "")
        if not clean_license or len(clean_license) < 5:
            raise ValidationError("Invalid driver license format.")

        if clean_license in self._license_index:
            raise ValidationError(f"Driver license '{clean_license}' is already in use.")

        profile = DriverProfile(
            driver_id=driver_id,
            license_number=clean_license,
            status=DriverStatus.OFFLINE,
            is_verified=False,
            is_active=True,
            rating=5.0,
            rating_count=0,
            current_location=initial_location,
        )

        self._drivers[driver_id] = profile
        self._license_index[clean_license] = driver_id
        return profile

    def get_driver(self, driver_id: str) -> DriverProfile:
        """Retrieves driver profile."""
        if driver_id not in self._drivers:
            raise DriverNotFoundError(driver_id)
        return self._drivers[driver_id]

    def verify_driver(self, driver_id: str) -> DriverProfile:
        """Verifies driver's background and legal driving credentials."""
        driver = self.get_driver(driver_id)
        driver.is_verified = True
        return driver

    def update_status(self, driver_id: str, status: DriverStatus) -> DriverProfile:
        """Transitions driver status with state machine checks."""
        driver = self.get_driver(driver_id)

        if not driver.is_active and status != DriverStatus.OFFLINE:
            raise ValidationError("Inactive drivers cannot be made online or busy.")

        if status == DriverStatus.AVAILABLE:
            self.check_eligibility(driver_id)

        driver.status = status
        return driver

    def update_location(self, driver_id: str, location: Coordinates) -> DriverProfile:
        """Updates driver's real-time geographic position."""
        driver = self.get_driver(driver_id)
        driver.current_location = location
        return driver

    def update_rating(self, driver_id: str, new_score: int) -> float:
        """Recalculates driver's running average star rating."""
        if not (1 <= new_score <= 5):
            raise ValidationError("Score must be an integer between 1 and 5.")

        driver = self.get_driver(driver_id)
        total_score = (driver.rating * driver.rating_count) + new_score
        driver.rating_count += 1
        driver.rating = round(total_score / driver.rating_count, 2)

        # Automatic suspension trigger for dangerously low driver ratings
        if driver.rating_count >= 5 and driver.rating < MINIMUM_ELIGIBLE_RATING:
            driver.status = DriverStatus.SUSPENDED

        return driver.rating

    def suspend_driver(self, driver_id: str) -> DriverProfile:
        """Suspends driver from accepting rides."""
        driver = self.get_driver(driver_id)
        driver.status = DriverStatus.SUSPENDED
        return driver

    def check_eligibility(self, driver_id: str) -> bool:
        """Checks whether driver is eligible to receive dispatch dispatches."""
        driver = self.get_driver(driver_id)

        if not driver.is_active:
            raise ValidationError("Driver account is deactivated.")
        if not driver.is_verified:
            raise ValidationError("Driver is not verified.")
        if driver.status == DriverStatus.SUSPENDED:
            raise ValidationError("Driver is suspended.")
        if driver.rating < MINIMUM_ELIGIBLE_RATING and driver.rating_count >= 5:
            raise ValidationError(f"Driver rating ({driver.rating}) is below minimum threshold.")

        vehicle = self.vehicle_service.get_vehicle_by_driver(driver_id)
        if not vehicle:
            raise ValidationError(f"Driver '{driver_id}' has no associated vehicle.")

        self.vehicle_service.check_eligibility(vehicle.vehicle_id)
        return True

    def list_available_drivers(self) -> List[DriverProfile]:
        """Lists all drivers ready for booking dispatch."""
        return [
            driver
            for driver in self._drivers.values()
            if driver.status == DriverStatus.AVAILABLE and driver.current_location is not None
        ]

