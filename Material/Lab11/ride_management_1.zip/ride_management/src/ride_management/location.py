"""Location validation, geographic coordinates, and Haversine distance computations."""

import math
from typing import Tuple

from ride_management.exceptions import ValidationError, LocationOutOfBoundsError
from ride_management.models import Coordinates

# Earth's mean radius in kilometers
EARTH_RADIUS_KM = 6371.0

# Supported operational bounding box for Bangalore metropolitan region
DEFAULT_MIN_LAT = 12.70
DEFAULT_MAX_LAT = 13.25
DEFAULT_MIN_LON = 77.40
DEFAULT_MAX_LON = 77.85


class LocationService:
    """Manages geographic calculations and boundary checks for the ride service."""

    def __init__(
        self,
        min_lat: float = DEFAULT_MIN_LAT,
        max_lat: float = DEFAULT_MAX_LAT,
        min_lon: float = DEFAULT_MIN_LON,
        max_lon: float = DEFAULT_MAX_LON,
        max_ride_distance_km: float = 100.0,
    ):
        self.min_lat = min_lat
        self.max_lat = max_lat
        self.min_lon = min_lon
        self.max_lon = max_lon
        self.max_ride_distance_km = max_ride_distance_km

    def create_coordinates(self, latitude: float, longitude: float) -> Coordinates:
        """Validates and creates a Coordinates instance."""
        if not isinstance(latitude, (int, float)) or not isinstance(longitude, (int, float)):
            raise ValidationError("Coordinates must be numeric values.")
        if math.isnan(latitude) or math.isnan(longitude):
            raise ValidationError("Coordinates cannot be NaN.")

        try:
            coord = Coordinates(latitude=float(latitude), longitude=float(longitude))
        except ValueError as err:
            raise ValidationError(str(err)) from err

        return coord

    def validate_in_bounds(self, coord: Coordinates) -> bool:
        """Checks if coordinate falls inside the operational service zone."""
        if not (self.min_lat <= coord.latitude <= self.max_lat and self.min_lon <= coord.longitude <= self.max_lon):
            raise LocationOutOfBoundsError(coord.latitude, coord.longitude)
        return True

    def calculate_distance(self, point1: Coordinates, point2: Coordinates) -> float:
        """Calculates great-circle distance between two points using the Haversine formula."""
        lat1_rad = math.radians(point1.latitude)
        lon1_rad = math.radians(point1.longitude)
        lat2_rad = math.radians(point2.latitude)
        lon2_rad = math.radians(point2.longitude)

        dlat = lat2_rad - lat1_rad
        dlon = lon2_rad - lon1_rad

        a = math.sin(dlat / 2.0) ** 2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon / 2.0) ** 2
        # Bound a to [0.0, 1.0] to safeguard against numerical precision drift
        a = min(1.0, max(0.0, a))
        c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
        distance = EARTH_RADIUS_KM * c
        return round(distance, 3)

    def validate_trip_distance(self, pickup: Coordinates, destination: Coordinates) -> float:
        """Validates that pickup and destination are distinct and within allowed operational limits."""
        self.validate_in_bounds(pickup)
        self.validate_in_bounds(destination)

        dist = self.calculate_distance(pickup, destination)
        if dist < 0.1:
            raise ValidationError("Pickup and destination locations must be at least 100 meters apart.")
        if dist > self.max_ride_distance_km:
            raise ValidationError(
                f"Trip distance ({dist:.2f} km) exceeds maximum operational limit of {self.max_ride_distance_km} km."
            )
        return dist

