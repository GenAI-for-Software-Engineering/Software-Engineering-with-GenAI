"""Data models, enumerations, and dataclasses for Ride Management System."""

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional


class UserRole(str, Enum):
    """User operational roles."""
    PASSENGER = "PASSENGER"
    DRIVER = "DRIVER"
    ADMIN = "ADMIN"


class DriverStatus(str, Enum):
    """Driver lifecycle and dispatch availability statuses."""
    AVAILABLE = "AVAILABLE"
    BUSY = "BUSY"
    OFFLINE = "OFFLINE"
    SUSPENDED = "SUSPENDED"


class VehicleCategory(str, Enum):
    """Supported vehicle categories."""
    BIKE = "BIKE"
    AUTO = "AUTO"
    SEDAN = "SEDAN"
    SUV = "SUV"


class VehicleStatus(str, Enum):
    """Operational status of a vehicle."""
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    UNDER_MAINTENANCE = "UNDER_MAINTENANCE"


class BookingStatus(str, Enum):
    """Lifecycle statuses of a ride booking."""
    REQUESTED = "REQUESTED"
    DRIVER_ASSIGNED = "DRIVER_ASSIGNED"
    ACCEPTED = "ACCEPTED"
    ARRIVED = "ARRIVED"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class PaymentMethod(str, Enum):
    """Supported payment instruments."""
    UPI = "UPI"
    CARD = "CARD"
    WALLET = "WALLET"
    CASH = "CASH"


class PaymentStatus(str, Enum):
    """Status of payment transactions."""
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    REFUNDED = "REFUNDED"


class CancellationParty(str, Enum):
    """Party initiating ride cancellation."""
    PASSENGER = "PASSENGER"
    DRIVER = "DRIVER"
    SYSTEM = "SYSTEM"


@dataclass(frozen=True)
class Coordinates:
    """Geographic point with latitude and longitude."""
    latitude: float
    longitude: float

    def __post_init__(self) -> None:
        if not (-90.0 <= self.latitude <= 90.0):
            raise ValueError(f"Latitude must be between -90 and 90, got {self.latitude}")
        if not (-180.0 <= self.longitude <= 180.0):
            raise ValueError(f"Longitude must be between -180 and 180, got {self.longitude}")


@dataclass
class UserProfile:
    """Core user entity representing passengers or drivers."""
    user_id: str
    name: str
    email: str
    phone: str
    role: UserRole
    is_active: bool = True
    wallet_balance: Decimal = field(default_factory=lambda: Decimal("0.00"))
    created_at: Optional[datetime] = None


@dataclass
class Vehicle:
    """Vehicle registration and specification model."""
    vehicle_id: str
    driver_id: Optional[str]
    registration_number: str
    make: str
    model: str
    category: VehicleCategory
    capacity: int
    year: int
    status: VehicleStatus = VehicleStatus.ACTIVE


@dataclass
class DriverProfile:
    """Driver-specific attributes and real-time state."""
    driver_id: str
    license_number: str
    status: DriverStatus = DriverStatus.OFFLINE
    is_verified: bool = False
    is_active: bool = True
    rating: float = 5.0
    rating_count: int = 0
    vehicle_id: Optional[str] = None
    current_location: Optional[Coordinates] = None


@dataclass
class FareBreakdown:
    """Itemized breakdown of ride fare components."""
    base_fare: Decimal
    distance_fare: Decimal
    time_fare: Decimal
    waiting_charge: Decimal
    surge_amount: Decimal
    night_charge: Decimal
    subtotal: Decimal
    discount_amount: Decimal
    tax_amount: Decimal
    final_fare: Decimal


@dataclass
class Booking:
    """Represents a ride request and its full lifecycle record."""
    booking_id: str
    passenger_id: str
    pickup_location: Coordinates
    destination_location: Coordinates
    category: VehicleCategory
    status: BookingStatus = BookingStatus.REQUESTED
    driver_id: Optional[str] = None
    distance_km: float = 0.0
    duration_minutes: float = 0.0
    fare_breakdown: Optional[FareBreakdown] = None
    created_at: Optional[datetime] = None
    driver_assigned_at: Optional[datetime] = None
    arrived_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    cancelled_at: Optional[datetime] = None
    cancellation_reason: Optional[str] = None
    cancelled_by: Optional[CancellationParty] = None


@dataclass
class Transaction:
    """Financial record of a ride payment or refund."""
    transaction_id: str
    booking_id: str
    user_id: str
    amount: Decimal
    payment_method: PaymentMethod
    status: PaymentStatus
    created_at: datetime
    gateway_reference: Optional[str] = None
    notes: Optional[str] = None


@dataclass
class RatingRecord:
    """Rating submission record for a completed ride."""
    rating_id: str
    booking_id: str
    author_id: str
    target_id: str
    score: int
    comments: Optional[str]
    created_at: datetime


@dataclass
class NotificationMessage:
    """Notification dispatch record."""
    notification_id: str
    recipient_id: str
    channel: str
    subject: str
    body: str
    sent_at: datetime
    success: bool

