"""Vehicle specifications, registration, validation, and driver-vehicle associations."""

from typing import Dict, List, Optional

from ride_management.exceptions import (
    ValidationError,
    VehicleNotEligibleError,
    VehicleNotFoundError,
)
from ride_management.models import Vehicle, VehicleCategory, VehicleStatus
from ride_management.utils import IdGenerator, validate_registration_number

CATEGORY_CAPACITY = {
    VehicleCategory.BIKE: 1,
    VehicleCategory.AUTO: 3,
    VehicleCategory.SEDAN: 4,
    VehicleCategory.SUV: 6,
}

MAX_VEHICLE_AGE_YEARS = 12
CURRENT_REFERENCE_YEAR = 2026


class VehicleService:
    """Manages vehicle catalog, compliance checks, and driver assignments."""

    def __init__(self, id_gen: Optional[IdGenerator] = None, current_year: int = CURRENT_REFERENCE_YEAR):
        self.id_gen = id_gen or IdGenerator()
        self.current_year = current_year
        self._vehicles: Dict[str, Vehicle] = {}
        self._reg_number_index: Dict[str, str] = {}
        self._driver_vehicle_map: Dict[str, str] = {}

    def register_vehicle(
        self,
        registration_number: str,
        make: str,
        model: str,
        category: VehicleCategory,
        year: int,
        capacity: Optional[int] = None,
        driver_id: Optional[str] = None,
    ) -> Vehicle:
        """Registers a new vehicle complying with safety regulations."""
        clean_reg = validate_registration_number(registration_number)

        if clean_reg in self._reg_number_index:
            raise ValidationError(f"Vehicle registration '{clean_reg}' already registered.")

        if not make or not make.strip():
            raise ValidationError("Vehicle make cannot be empty.")
        if not model or not model.strip():
            raise ValidationError("Vehicle model cannot be empty.")

        if year < 2000 or year > self.current_year + 1:
            raise ValidationError(f"Invalid vehicle manufacturing year: {year}.")

        expected_cap = CATEGORY_CAPACITY[category]
        if capacity is not None and capacity <= 0:
            raise ValidationError("Capacity must be positive.")
        assigned_capacity = capacity if capacity is not None else expected_cap

        vehicle_id = self.id_gen.generate("VEH")
        vehicle = Vehicle(
            vehicle_id=vehicle_id,
            driver_id=driver_id,
            registration_number=clean_reg,
            make=make.strip(),
            model=model.strip(),
            category=category,
            capacity=assigned_capacity,
            year=year,
            status=VehicleStatus.ACTIVE,
        )

        self._vehicles[vehicle_id] = vehicle
        self._reg_number_index[clean_reg] = vehicle_id

        if driver_id:
            self._driver_vehicle_map[driver_id] = vehicle_id

        return vehicle

    def get_vehicle(self, vehicle_id: str) -> Vehicle:
        """Retrieves vehicle by its ID."""
        if vehicle_id not in self._vehicles:
            raise VehicleNotFoundError(vehicle_id)
        return self._vehicles[vehicle_id]

    def get_vehicle_by_driver(self, driver_id: str) -> Optional[Vehicle]:
        """Gets vehicle currently assigned to a driver."""
        veh_id = self._driver_vehicle_map.get(driver_id)
        if not veh_id:
            return None
        return self._vehicles.get(veh_id)

    def assign_driver(self, vehicle_id: str, driver_id: str) -> Vehicle:
        """Associates a driver with a specific vehicle."""
        vehicle = self.get_vehicle(vehicle_id)

        # Clear existing driver link if previously assigned
        if vehicle.driver_id and vehicle.driver_id in self._driver_vehicle_map:
            del self._driver_vehicle_map[vehicle.driver_id]

        vehicle.driver_id = driver_id
        self._driver_vehicle_map[driver_id] = vehicle_id
        return vehicle

    def update_status(self, vehicle_id: str, status: VehicleStatus) -> Vehicle:
        """Updates operational status of the vehicle."""
        vehicle = self.get_vehicle(vehicle_id)
        vehicle.status = status
        return vehicle

    def check_eligibility(self, vehicle_id: str) -> bool:
        """Verifies if vehicle satisfies age and operational requirements for rides."""
        vehicle = self.get_vehicle(vehicle_id)

        if vehicle.status != VehicleStatus.ACTIVE:
            raise VehicleNotEligibleError(f"Vehicle is not active (status: {vehicle.status.value}).")

        age = self.current_year - vehicle.year
        if age > MAX_VEHICLE_AGE_YEARS:
            raise VehicleNotEligibleError(f"Vehicle age ({age} years) exceeds maximum allowed {MAX_VEHICLE_AGE_YEARS}.")

        return True

    def list_vehicles(self) -> List[Vehicle]:
        """Returns all vehicles."""
        return list(self._vehicles.values())

