"""Ride statistics, driver earnings, revenue aggregation, and reporting."""

from collections import defaultdict
from datetime import date
from decimal import Decimal
from typing import Any, Dict, List, Optional

from ride_management.booking import BookingService
from ride_management.models import Booking, BookingStatus
from ride_management.utils import round_currency

# Standard platform commission rate (20%)
PLATFORM_COMMISSION_RATE = Decimal("0.20")


class AnalyticsService:
    """Computes high-level business intelligence, driver pay, and platform revenue."""

    def __init__(
        self,
        booking_service: BookingService,
        platform_commission_rate: Decimal = PLATFORM_COMMISSION_RATE,
    ):
        self.booking_service = booking_service
        self.commission_rate = platform_commission_rate

    def get_total_bookings_count(self) -> int:
        """Returns total number of created bookings."""
        return len(self.booking_service._bookings)

    def get_completed_bookings(self) -> List[Booking]:
        """Returns all successfully completed bookings."""
        return [
            b for b in self.booking_service._bookings.values()
            if b.status == BookingStatus.COMPLETED
        ]

    def get_cancelled_bookings(self) -> List[Booking]:
        """Returns all cancelled bookings."""
        return [
            b for b in self.booking_service._bookings.values()
            if b.status == BookingStatus.CANCELLED
        ]

    def get_total_gross_revenue(self) -> Decimal:
        """Calculates total revenue collected across all completed trips."""
        total = Decimal("0.00")
        for b in self.get_completed_bookings():
            if b.fare_breakdown:
                total += b.fare_breakdown.final_fare
        return round_currency(total)

    def get_average_trip_fare(self) -> Decimal:
        """Calculates mean fare per completed trip."""
        completed = self.get_completed_bookings()
        if not completed:
            return Decimal("0.00")
        total_rev = self.get_total_gross_revenue()
        avg = total_rev / Decimal(str(len(completed)))
        return round_currency(avg)

    def calculate_driver_earnings(self, driver_id: str) -> Dict[str, Any]:
        """Calculates net driver take-home earnings after platform deductions."""
        driver_rides = [
            b for b in self.booking_service.get_driver_history(driver_id)
            if b.status == BookingStatus.COMPLETED
        ]

        gross_fares = Decimal("0.00")
        total_distance = 0.0

        for r in driver_rides:
            if r.fare_breakdown:
                gross_fares += r.fare_breakdown.final_fare
            total_distance += r.distance_km

        platform_cut = round_currency(gross_fares * self.commission_rate)
        net_driver_pay = round_currency(gross_fares - platform_cut)

        return {
            "driver_id": driver_id,
            "completed_trips": len(driver_rides),
            "total_distance_km": round(total_distance, 2),
            "gross_earnings": gross_fares,
            "platform_commission": platform_cut,
            "net_earnings": net_driver_pay,
        }

    def get_daily_ride_statistics(self) -> Dict[date, Dict[str, int]]:
        """Groups bookings by creation date with status distribution."""
        stats: Dict[date, Dict[str, int]] = defaultdict(lambda: {"total": 0, "completed": 0, "cancelled": 0})

        for b in self.booking_service._bookings.values():
            if not b.created_at:
                continue
            d = b.created_at.date()
            stats[d]["total"] += 1
            if b.status == BookingStatus.COMPLETED:
                stats[d]["completed"] += 1
            elif b.status == BookingStatus.CANCELLED:
                stats[d]["cancelled"] += 1

        return dict(stats)

    def get_passenger_summary(self, passenger_id: str) -> Dict[str, Any]:
        """Aggregates spending and trip statistics for a passenger."""
        rides = self.booking_service.get_passenger_history(passenger_id)
        completed = [r for r in rides if r.status == BookingStatus.COMPLETED]
        cancelled = [r for r in rides if r.status == BookingStatus.CANCELLED]

        total_spent = Decimal("0.00")
        for r in completed:
            if r.fare_breakdown:
                total_spent += r.fare_breakdown.final_fare

        return {
            "passenger_id": passenger_id,
            "total_requested": len(rides),
            "completed_rides": len(completed),
            "cancelled_rides": len(cancelled),
            "total_spent": round_currency(total_spent),
        }

