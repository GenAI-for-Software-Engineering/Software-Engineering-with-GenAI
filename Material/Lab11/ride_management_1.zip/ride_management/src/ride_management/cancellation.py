"""Cancellation fee policies, conditions, and automated refund processing."""

from decimal import Decimal
from typing import Dict, Optional

from ride_management.booking import BookingService
from ride_management.driver import DriverService
from ride_management.exceptions import RefundError, ValidationError
from ride_management.models import (
    Booking,
    BookingStatus,
    CancellationParty,
    DriverStatus,
    FareBreakdown,
    PaymentMethod,
    PaymentStatus,
    Transaction,
)
from ride_management.payment import PaymentGateway, PaymentService
from ride_management.user import UserService
from ride_management.utils import Clock, IdGenerator, round_currency

# Cancellation fee structure
FEE_PASSENGER_AFTER_ASSIGN_UNDER_2MIN = Decimal("0.00")
FEE_PASSENGER_AFTER_ASSIGN_OVER_2MIN = Decimal("25.00")
FEE_PASSENGER_AFTER_ARRIVED = Decimal("50.00")
FEE_PASSENGER_IN_PROGRESS = Decimal("75.00")


class CancellationService:
    """Calculates cancellation charges, restores driver states, and processes refunds."""

    def __init__(
        self,
        booking_service: BookingService,
        driver_service: DriverService,
        payment_service: PaymentService,
        user_service: UserService,
        gateway: PaymentGateway,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.booking_service = booking_service
        self.driver_service = driver_service
        self.payment_service = payment_service
        self.user_service = user_service
        self.gateway = gateway
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._refunded_transactions: Dict[str, str] = {}  # orig_tx_id -> refund_tx_id

    def calculate_cancellation_fee(
        self,
        booking: Booking,
        party: CancellationParty,
    ) -> Decimal:
        """Determines penalty fee according to ride progression and initiator."""
        # Drivers and system cancellations never penalize the passenger
        if party in (CancellationParty.DRIVER, CancellationParty.SYSTEM):
            return Decimal("0.00")

        now = self.clock.now()

        # Passenger cancelled before any driver was assigned
        if booking.status == BookingStatus.REQUESTED:
            return Decimal("0.00")

        # Passenger cancelled after driver assigned but before arrival
        if booking.status in (BookingStatus.DRIVER_ASSIGNED, BookingStatus.ACCEPTED):
            if booking.driver_assigned_at:
                elapsed_seconds = (now - booking.driver_assigned_at).total_seconds()
                if elapsed_seconds <= 120:  # Within 2 min grace period
                    return FEE_PASSENGER_AFTER_ASSIGN_UNDER_2MIN
            return FEE_PASSENGER_AFTER_ASSIGN_OVER_2MIN

        # Passenger cancelled after driver arrived at pickup spot
        if booking.status == BookingStatus.ARRIVED:
            return FEE_PASSENGER_AFTER_ARRIVED

        # Passenger cancelled mid-trip
        if booking.status == BookingStatus.IN_PROGRESS:
            return FEE_PASSENGER_IN_PROGRESS

        return Decimal("0.00")

    def cancel_ride(
        self,
        booking_id: str,
        party: CancellationParty,
        reason: str,
    ) -> Booking:
        """Performs ride cancellation, fee calculation, and driver release."""
        booking = self.booking_service.get_booking(booking_id)

        fee = self.calculate_cancellation_fee(booking, party)

        # Update booking status
        cancelled_booking = self.booking_service.cancel_booking(booking_id, party, reason)

        # Release driver back to available if assigned
        if cancelled_booking.driver_id:
            try:
                driver = self.driver_service.get_driver(cancelled_booking.driver_id)
                if driver.status == DriverStatus.BUSY:
                    self.driver_service.update_status(driver.driver_id, DriverStatus.AVAILABLE)
            except Exception:
                pass

        # If a fee is due, attach nominal fare breakdown to enable payment/settlement
        if fee > Decimal("0.00"):
            cancelled_booking.fare_breakdown = FareBreakdown(
                base_fare=fee,
                distance_fare=Decimal("0.00"),
                time_fare=Decimal("0.00"),
                waiting_charge=Decimal("0.00"),
                surge_amount=Decimal("0.00"),
                night_charge=Decimal("0.00"),
                subtotal=fee,
                discount_amount=Decimal("0.00"),
                tax_amount=Decimal("0.00"),
                final_fare=fee,
            )

        return cancelled_booking

    def process_refund(
        self,
        booking_id: str,
        refund_amount: Optional[Decimal] = None,
        reason: str = "Cancellation refund",
    ) -> Transaction:
        """Processes partial or complete refund for a previously billed booking."""
        orig_tx = self.payment_service.get_transaction_by_booking(booking_id)
        if not orig_tx:
            raise RefundError(f"No payment transaction found for booking '{booking_id}'.")

        if orig_tx.status != PaymentStatus.COMPLETED:
            raise RefundError("Can only refund successfully completed transactions.")

        if orig_tx.transaction_id in self._refunded_transactions:
            raise RefundError(f"Transaction '{orig_tx.transaction_id}' has already been refunded.")

        actual_refund_amount = orig_tx.amount if refund_amount is None else round_currency(refund_amount)

        if actual_refund_amount <= Decimal("0.00") or actual_refund_amount > orig_tx.amount:
            raise ValidationError(
                f"Refund amount ({actual_refund_amount}) must be between 0 and original amount ({orig_tx.amount})."
            )

        refund_tx_id = self.id_gen.generate("RFD")
        now = self.clock.now()

        if orig_tx.payment_method == PaymentMethod.WALLET:
            self.user_service.add_wallet_funds(orig_tx.user_id, actual_refund_amount)
            refund_tx = Transaction(
                transaction_id=refund_tx_id,
                booking_id=booking_id,
                user_id=orig_tx.user_id,
                amount=actual_refund_amount,
                payment_method=PaymentMethod.WALLET,
                status=PaymentStatus.REFUNDED,
                created_at=now,
                gateway_reference=f"WALLET-REFUND-{refund_tx_id}",
                notes=reason,
            )
        elif orig_tx.payment_method == PaymentMethod.CASH:
            # Cash refund credited as in-app wallet balance
            self.user_service.add_wallet_funds(orig_tx.user_id, actual_refund_amount)
            refund_tx = Transaction(
                transaction_id=refund_tx_id,
                booking_id=booking_id,
                user_id=orig_tx.user_id,
                amount=actual_refund_amount,
                payment_method=PaymentMethod.WALLET,
                status=PaymentStatus.REFUNDED,
                created_at=now,
                gateway_reference="CASH-WALLET-CREDIT",
                notes=f"Cash refund credited to wallet: {reason}",
            )
        else:
            # Card or UPI gateway refund
            gw_ref = orig_tx.gateway_reference or ""
            gw_ok = self.gateway.process_refund(gw_ref, actual_refund_amount)
            if not gw_ok:
                raise RefundError("Payment gateway failed to issue refund.")

            refund_tx = Transaction(
                transaction_id=refund_tx_id,
                booking_id=booking_id,
                user_id=orig_tx.user_id,
                amount=actual_refund_amount,
                payment_method=orig_tx.payment_method,
                status=PaymentStatus.REFUNDED,
                created_at=now,
                gateway_reference=f"GW-REF-{refund_tx_id}",
                notes=reason,
            )

        self._refunded_transactions[orig_tx.transaction_id] = refund_tx_id
        self.payment_service._transactions[refund_tx_id] = refund_tx
        orig_tx.status = PaymentStatus.REFUNDED
        return refund_tx

