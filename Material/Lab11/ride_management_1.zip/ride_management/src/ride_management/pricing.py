"""Pricing engine, fare estimation, surge pricing, taxes, and promotional coupons."""

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Dict, Optional

from ride_management.exceptions import ValidationError
from ride_management.models import FareBreakdown, VehicleCategory
from ride_management.utils import round_currency

# Base category pricing configuration
CATEGORY_BASE_RATES = {
    VehicleCategory.BIKE: {
        "base_fare": Decimal("20.00"),
        "per_km": Decimal("8.00"),
        "per_min": Decimal("1.00"),
        "min_fare": Decimal("30.00"),
    },
    VehicleCategory.AUTO: {
        "base_fare": Decimal("30.00"),
        "per_km": Decimal("13.00"),
        "per_min": Decimal("1.50"),
        "min_fare": Decimal("45.00"),
    },
    VehicleCategory.SEDAN: {
        "base_fare": Decimal("50.00"),
        "per_km": Decimal("18.00"),
        "per_min": Decimal("2.00"),
        "min_fare": Decimal("80.00"),
    },
    VehicleCategory.SUV: {
        "base_fare": Decimal("80.00"),
        "per_km": Decimal("24.00"),
        "per_min": Decimal("3.00"),
        "min_fare": Decimal("120.00"),
    },
}

DEFAULT_TAX_RATE = Decimal("0.05")  # 5% GST
NIGHT_SURCHARGE_RATE = Decimal("0.25")  # 25% extra between 23:00 and 05:00
WAITING_CHARGE_PER_MIN = Decimal("2.00")
FREE_WAITING_MINUTES = 3


@dataclass
class Coupon:
    """Promotional discount code model."""
    code: str
    discount_percent: Decimal
    max_discount: Decimal
    expiry_date: datetime
    max_usages: int
    usage_count: int = 0
    is_active: bool = True


class PricingService:
    """Computes transparent, granular ride fares and handles coupon redemptions."""

    def __init__(self, tax_rate: Decimal = DEFAULT_TAX_RATE):
        self.tax_rate = tax_rate
        self._coupons: Dict[str, Coupon] = {}

    def add_coupon(
        self,
        code: str,
        discount_percent: Decimal,
        max_discount: Decimal,
        expiry_date: datetime,
        max_usages: int = 100,
    ) -> Coupon:
        """Registers a promotional discount coupon."""
        clean_code = code.strip().upper()
        if not clean_code:
            raise ValidationError("Coupon code cannot be empty.")
        if discount_percent <= Decimal("0") or discount_percent > Decimal("100"):
            raise ValidationError("Discount percentage must be between 1 and 100.")
        if max_discount <= Decimal("0"):
            raise ValidationError("Max discount must be greater than zero.")

        coupon = Coupon(
            code=clean_code,
            discount_percent=discount_percent,
            max_discount=round_currency(max_discount),
            expiry_date=expiry_date,
            max_usages=max_usages,
        )
        self._coupons[clean_code] = coupon
        return coupon

    def validate_and_apply_coupon(
        self,
        coupon_code: str,
        subtotal: Decimal,
        current_time: datetime,
    ) -> Decimal:
        """Validates coupon constraints and calculates discount amount."""
        clean_code = coupon_code.strip().upper()
        if clean_code not in self._coupons:
            raise ValidationError(f"Invalid coupon code: '{coupon_code}'.")

        coupon = self._coupons[clean_code]

        if not coupon.is_active:
            raise ValidationError("Coupon is inactive.")
        if current_time > coupon.expiry_date:
            raise ValidationError("Coupon has expired.")
        if coupon.usage_count >= coupon.max_usages:
            raise ValidationError("Coupon usage limit reached.")

        calculated_discount = (subtotal * coupon.discount_percent) / Decimal("100")
        actual_discount = min(calculated_discount, coupon.max_discount)
        return round_currency(actual_discount)

    def record_coupon_usage(self, coupon_code: str) -> None:
        """Increments coupon usage counter."""
        clean_code = coupon_code.strip().upper()
        if clean_code in self._coupons:
            self._coupons[clean_code].usage_count += 1

    def is_night_time(self, timestamp: datetime) -> bool:
        """Determines if the timestamp falls under night surcharge hours (23:00 - 05:00)."""
        hour = timestamp.hour
        return hour >= 23 or hour < 5

    def is_peak_hour(self, timestamp: datetime) -> bool:
        """Determines peak transit hours (08:30-10:30 and 17:30-20:00 on weekdays)."""
        if timestamp.weekday() >= 5:  # Weekend
            return False

        hour = timestamp.hour
        minute = timestamp.minute
        time_dec = hour + (minute / 60.0)

        morning_peak = 8.5 <= time_dec <= 10.5
        evening_peak = 17.5 <= time_dec <= 20.0
        return morning_peak or evening_peak

    def calculate_surge_multiplier(
        self,
        demand_count: int,
        supply_count: int,
        timestamp: Optional[datetime] = None,
    ) -> Decimal:
        """Calculates dynamic demand/supply surge multiplier."""
        if demand_count < 0 or supply_count < 0:
            raise ValidationError("Demand and supply counts must be non-negative.")

        # Default multiplier is 1.0 (no surge)
        multiplier = Decimal("1.0")

        if supply_count == 0:
            if demand_count > 0:
                multiplier = Decimal("2.5")  # Cap at 2.5x
        else:
            ratio = Decimal(str(demand_count)) / Decimal(str(supply_count))
            if ratio >= Decimal("3.0"):
                multiplier = Decimal("2.5")
            elif ratio >= Decimal("2.0"):
                multiplier = Decimal("2.0")
            elif ratio >= Decimal("1.5"):
                multiplier = Decimal("1.5")
            elif ratio >= Decimal("1.2"):
                multiplier = Decimal("1.2")

        # Peak hours apply minimum surge floor of 1.3
        if timestamp and self.is_peak_hour(timestamp):
            if multiplier < Decimal("1.3"):
                multiplier = Decimal("1.3")

        return multiplier

    def calculate_fare(
        self,
        category: VehicleCategory,
        distance_km: float,
        duration_minutes: float,
        waiting_minutes: float = 0.0,
        surge_multiplier: Decimal = Decimal("1.0"),
        coupon_code: Optional[str] = None,
        booking_time: Optional[datetime] = None,
    ) -> FareBreakdown:
        """Computes comprehensive fare with itemized breakdown."""
        if distance_km < 0:
            raise ValidationError("Distance cannot be negative.")
        if duration_minutes < 0:
            raise ValidationError("Duration cannot be negative.")
        if waiting_minutes < 0:
            raise ValidationError("Waiting minutes cannot be negative.")
        if surge_multiplier < Decimal("1.0"):
            raise ValidationError("Surge multiplier cannot be less than 1.0.")

        rates = CATEGORY_BASE_RATES[category]
        base_fare = rates["base_fare"]
        dist_dec = Decimal(str(round(distance_km, 2)))
        time_dec = Decimal(str(round(duration_minutes, 2)))

        distance_fare = round_currency(dist_dec * rates["per_km"])
        time_fare = round_currency(time_dec * rates["per_min"])

        # Waiting charge
        chargeable_wait = max(0.0, waiting_minutes - FREE_WAITING_MINUTES)
        waiting_charge = round_currency(Decimal(str(chargeable_wait)) * WAITING_CHARGE_PER_MIN)

        standard_subtotal = base_fare + distance_fare + time_fare + waiting_charge

        # Minimum fare enforcement
        if standard_subtotal < rates["min_fare"]:
            standard_subtotal = rates["min_fare"]

        # Surge pricing applied to ride fare
        surge_amount = round_currency(standard_subtotal * (surge_multiplier - Decimal("1.0")))

        # Night surcharge
        night_charge = Decimal("0.00")
        if booking_time and self.is_night_time(booking_time):
            night_charge = round_currency(standard_subtotal * NIGHT_SURCHARGE_RATE)

        gross_fare = standard_subtotal + surge_amount + night_charge

        # Coupon discounts
        discount_amount = Decimal("0.00")
        if coupon_code and booking_time:
            discount_amount = self.validate_and_apply_coupon(coupon_code, gross_fare, booking_time)

        taxable_amount = max(Decimal("0.00"), gross_fare - discount_amount)
        tax_amount = round_currency(taxable_amount * self.tax_rate)
        final_fare = round_currency(taxable_amount + tax_amount)

        return FareBreakdown(
            base_fare=base_fare,
            distance_fare=distance_fare,
            time_fare=time_fare,
            waiting_charge=waiting_charge,
            surge_amount=surge_amount,
            night_charge=night_charge,
            subtotal=gross_fare,
            discount_amount=discount_amount,
            tax_amount=tax_amount,
            final_fare=final_fare,
        )

