"""Rating, reviews, and star score recalculation for drivers and passengers."""

from typing import Dict, List, Optional

from ride_management.booking import BookingService
from ride_management.driver import DriverService
from ride_management.exceptions import DuplicateRatingError, ValidationError
from ride_management.models import BookingStatus, RatingRecord
from ride_management.utils import Clock, IdGenerator


class RatingService:
    """Manages two-way rating submissions and validates duplicate prevention."""

    def __init__(
        self,
        booking_service: BookingService,
        driver_service: DriverService,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.booking_service = booking_service
        self.driver_service = driver_service
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._ratings: Dict[str, RatingRecord] = {}
        # Key: (booking_id, author_id) -> rating_id
        self._author_booking_rating_index: Dict[tuple, str] = {}
        self._passenger_ratings: Dict[str, List[int]] = {}

    def rate_driver(
        self,
        booking_id: str,
        passenger_id: str,
        score: int,
        comments: Optional[str] = None,
    ) -> RatingRecord:
        """Submits rating for driver from passenger on completed ride."""
        booking = self.booking_service.get_booking(booking_id)

        if booking.passenger_id != passenger_id:
            raise ValidationError(f"User '{passenger_id}' is not the passenger for this ride.")

        if booking.status != BookingStatus.COMPLETED:
            raise ValidationError("Ratings can only be submitted for completed rides.")

        if not booking.driver_id:
            raise ValidationError("Booking has no driver assigned.")

        index_key = (booking_id, passenger_id)
        if index_key in self._author_booking_rating_index:
            raise DuplicateRatingError(booking_id, passenger_id)

        if not isinstance(score, int) or not (1 <= score <= 5):
            raise ValidationError(f"Rating score must be an integer between 1 and 5, got {score}.")

        rating_id = self.id_gen.generate("RAT")
        record = RatingRecord(
            rating_id=rating_id,
            booking_id=booking_id,
            author_id=passenger_id,
            target_id=booking.driver_id,
            score=score,
            comments=comments.strip() if comments else None,
            created_at=self.clock.now(),
        )

        self._ratings[rating_id] = record
        self._author_booking_rating_index[index_key] = rating_id

        # Update driver's overall aggregate rating
        self.driver_service.update_rating(booking.driver_id, score)
        return record

    def rate_passenger(
        self,
        booking_id: str,
        driver_id: str,
        score: int,
        comments: Optional[str] = None,
    ) -> RatingRecord:
        """Submits rating for passenger from driver on completed ride."""
        booking = self.booking_service.get_booking(booking_id)

        if booking.driver_id != driver_id:
            raise ValidationError(f"Driver '{driver_id}' was not the driver for this ride.")

        if booking.status != BookingStatus.COMPLETED:
            raise ValidationError("Ratings can only be submitted for completed rides.")

        index_key = (booking_id, driver_id)
        if index_key in self._author_booking_rating_index:
            raise DuplicateRatingError(booking_id, driver_id)

        if not isinstance(score, int) or not (1 <= score <= 5):
            raise ValidationError(f"Rating score must be an integer between 1 and 5, got {score}.")

        rating_id = self.id_gen.generate("RAT")
        record = RatingRecord(
            rating_id=rating_id,
            booking_id=booking_id,
            author_id=driver_id,
            target_id=booking.passenger_id,
            score=score,
            comments=comments.strip() if comments else None,
            created_at=self.clock.now(),
        )

        self._ratings[rating_id] = record
        self._author_booking_rating_index[index_key] = rating_id

        # Track passenger rating history
        if booking.passenger_id not in self._passenger_ratings:
            self._passenger_ratings[booking.passenger_id] = []
        self._passenger_ratings[booking.passenger_id].append(score)

        return record

    def get_passenger_average_rating(self, passenger_id: str) -> float:
        """Computes mean average rating of a passenger."""
        scores = self._passenger_ratings.get(passenger_id, [])
        if not scores:
            return 5.0
        return round(sum(scores) / len(scores), 2)

    def get_ratings_for_target(self, target_id: str) -> List[RatingRecord]:
        """Returns all reviews received by a driver or passenger."""
        return [r for r in self._ratings.values() if r.target_id == target_id]

    def get_ratings_by_author(self, author_id: str) -> List[RatingRecord]:
        """Returns all reviews written by a user."""
        return [r for r in self._ratings.values() if r.author_id == author_id]

