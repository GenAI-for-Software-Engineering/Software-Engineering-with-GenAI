"""Ride creation, lifecycle state transitions, history, and active ride tracking."""

from typing import Dict, List, Optional

from ride_management.exceptions import (
    ActiveBookingExistsError,
    BookingNotFoundError,
    InvalidStateTransitionError,
    UserInactiveError,
    ValidationError,
)
from ride_management.location import LocationService
from ride_management.models import (
    Booking,
    BookingStatus,
    CancellationParty,
    Coordinates,
    FareBreakdown,
    VehicleCategory,
)
from ride_management.user import UserService
from ride_management.utils import Clock, IdGenerator

VALID_TRANSITIONS = {
    BookingStatus.REQUESTED: [BookingStatus.DRIVER_ASSIGNED, BookingStatus.CANCELLED],
    BookingStatus.DRIVER_ASSIGNED: [BookingStatus.ACCEPTED, BookingStatus.CANCELLED],
    BookingStatus.ACCEPTED: [BookingStatus.ARRIVED, BookingStatus.CANCELLED],
    BookingStatus.ARRIVED: [BookingStatus.IN_PROGRESS, BookingStatus.CANCELLED],
    BookingStatus.IN_PROGRESS: [BookingStatus.COMPLETED, BookingStatus.CANCELLED],
    BookingStatus.COMPLETED: [],
    BookingStatus.CANCELLED: [],
}


class BookingService:
    """Manages the full booking lifecycle, state machine transitions, and trip histories."""

    def __init__(
        self,
        user_service: UserService,
        location_service: LocationService,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.user_service = user_service
        self.location_service = location_service
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._bookings: Dict[str, Booking] = {}
        self._passenger_active_booking: Dict[str, str] = {}
        self._driver_active_booking: Dict[str, str] = {}

    def create_booking(
        self,
        passenger_id: str,
        pickup: Coordinates,
        destination: Coordinates,
        category: VehicleCategory,
    ) -> Booking:
        """Validates parameters and initializes a new ride booking request."""
        self.user_service.validate_user_active(passenger_id)

        # Ensure no existing active booking for this passenger
        if passenger_id in self._passenger_active_booking:
            active_id = self._passenger_active_booking[passenger_id]
            raise ActiveBookingExistsError(passenger_id, active_id)

        # Validate distance between pickup and destination
        distance_km = self.location_service.validate_trip_distance(pickup, destination)

        # Initial estimation of duration (assuming average city speed of 25 km/h)
        estimated_duration_min = round((distance_km / 25.0) * 60.0, 2)

        booking_id = self.id_gen.generate("BKG")
        booking = Booking(
            booking_id=booking_id,
            passenger_id=passenger_id,
            pickup_location=pickup,
            destination_location=destination,
            category=category,
            status=BookingStatus.REQUESTED,
            distance_km=distance_km,
            duration_minutes=estimated_duration_min,
            created_at=self.clock.now(),
        )

        self._bookings[booking_id] = booking
        self._passenger_active_booking[passenger_id] = booking_id
        return booking

    def get_booking(self, booking_id: str) -> Booking:
        """Retrieves booking record."""
        if booking_id not in self._bookings:
            raise BookingNotFoundError(booking_id)
        return self._bookings[booking_id]

    def _validate_transition(self, booking: Booking, target_status: BookingStatus) -> None:
        """Enforces strictly legal lifecycle state changes."""
        allowed = VALID_TRANSITIONS.get(booking.status, [])
        if target_status not in allowed:
            raise InvalidStateTransitionError(booking.status.value, target_status.value)

    def assign_driver(self, booking_id: str, driver_id: str) -> Booking:
        """Transitions booking from REQUESTED to DRIVER_ASSIGNED."""
        booking = self.get_booking(booking_id)
        self._validate_transition(booking, BookingStatus.DRIVER_ASSIGNED)

        booking.driver_id = driver_id
        booking.status = BookingStatus.DRIVER_ASSIGNED
        booking.driver_assigned_at = self.clock.now()
        self._driver_active_booking[driver_id] = booking_id
        return booking

    def driver_accept(self, booking_id: str, driver_id: str) -> Booking:
        """Driver accepts the assigned ride."""
        booking = self.get_booking(booking_id)
        if booking.driver_id != driver_id:
            raise ValidationError(f"Booking is not assigned to driver '{driver_id}'.")

        self._validate_transition(booking, BookingStatus.ACCEPTED)
        booking.status = BookingStatus.ACCEPTED
        return booking

    def driver_arrive(self, booking_id: str, driver_id: str) -> Booking:
        """Driver signals arrival at passenger pickup location."""
        booking = self.get_booking(booking_id)
        if booking.driver_id != driver_id:
            raise ValidationError(f"Booking is not assigned to driver '{driver_id}'.")

        self._validate_transition(booking, BookingStatus.ARRIVED)
        booking.status = BookingStatus.ARRIVED
        booking.arrived_at = self.clock.now()
        return booking

    def start_ride(self, booking_id: str, driver_id: str) -> Booking:
        """Signals start of journey after passenger enters vehicle."""
        booking = self.get_booking(booking_id)
        if booking.driver_id != driver_id:
            raise ValidationError(f"Booking is not assigned to driver '{driver_id}'.")

        self._validate_transition(booking, BookingStatus.IN_PROGRESS)
        booking.status = BookingStatus.IN_PROGRESS
        booking.started_at = self.clock.now()
        return booking

    def complete_ride(
        self,
        booking_id: str,
        driver_id: str,
        fare_breakdown: FareBreakdown,
        actual_distance_km: Optional[float] = None,
        actual_duration_min: Optional[float] = None,
    ) -> Booking:
        """Marks ride completed and associates final settled fare breakdown."""
        booking = self.get_booking(booking_id)
        if booking.driver_id != driver_id:
            raise ValidationError(f"Booking is not assigned to driver '{driver_id}'.")

        self._validate_transition(booking, BookingStatus.COMPLETED)

        if actual_distance_km is not None and actual_distance_km > 0:
            booking.distance_km = actual_distance_km
        if actual_duration_min is not None and actual_duration_min > 0:
            booking.duration_minutes = actual_duration_min

        booking.fare_breakdown = fare_breakdown
        booking.status = BookingStatus.COMPLETED
        booking.completed_at = self.clock.now()

        # Clear active booking slots
        self._passenger_active_booking.pop(booking.passenger_id, None)
        self._driver_active_booking.pop(driver_id, None)
        return booking

    def cancel_booking(
        self,
        booking_id: str,
        cancelled_by: CancellationParty,
        reason: str,
    ) -> Booking:
        """Cancels booking if not in terminal state."""
        booking = self.get_booking(booking_id)
        self._validate_transition(booking, BookingStatus.CANCELLED)

        booking.status = BookingStatus.CANCELLED
        booking.cancelled_at = self.clock.now()
        booking.cancelled_by = cancelled_by
        booking.cancellation_reason = reason.strip()

        # Clear active status for participants
        self._passenger_active_booking.pop(booking.passenger_id, None)
        if booking.driver_id:
            self._driver_active_booking.pop(booking.driver_id, None)

        return booking

    def get_passenger_history(self, passenger_id: str) -> List[Booking]:
        """Returns chronological ride history of passenger."""
        return [b for b in self._bookings.values() if b.passenger_id == passenger_id]

    def get_driver_history(self, driver_id: str) -> List[Booking]:
        """Returns chronological ride history of driver."""
        return [b for b in self._bookings.values() if b.driver_id == driver_id]

    def get_active_booking_for_passenger(self, passenger_id: str) -> Optional[Booking]:
        """Gets ongoing ride for passenger if exists."""
        bkg_id = self._passenger_active_booking.get(passenger_id)
        return self._bookings.get(bkg_id) if bkg_id else None

    def get_active_booking_for_driver(self, driver_id: str) -> Optional[Booking]:
        """Gets ongoing ride for driver if exists."""
        bkg_id = self._driver_active_booking.get(driver_id)
        return self._bookings.get(bkg_id) if bkg_id else None

