"""Custom exceptions for the Ride Management System."""


class RideManagementError(Exception):
    """Base exception for all domain errors in Ride Management System."""

    def __init__(self, message: str, code: str = "RMS_ERROR"):
        super().__init__(message)
        self.message = message
        self.code = code

    def __str__(self) -> str:
        return f"[{self.code}] {self.message}"


class ValidationError(RideManagementError):
    """Raised when an input or parameter fails validation rules."""

    def __init__(self, message: str):
        super().__init__(message, code="VALIDATION_ERROR")


class UserNotFoundError(RideManagementError):
    """Raised when requested user cannot be found."""

    def __init__(self, user_id: str):
        super().__init__(f"User '{user_id}' not found.", code="USER_NOT_FOUND")


class DuplicateUserError(RideManagementError):
    """Raised when registering an already existing user."""

    def __init__(self, identifier: str):
        super().__init__(f"User already exists with identifier: {identifier}", code="DUPLICATE_USER")


class UserInactiveError(RideManagementError):
    """Raised when an inactive user attempts an operation."""

    def __init__(self, user_id: str):
        super().__init__(f"User '{user_id}' is inactive.", code="USER_INACTIVE")


class DriverNotFoundError(RideManagementError):
    """Raised when requested driver is not found."""

    def __init__(self, driver_id: str):
        super().__init__(f"Driver '{driver_id}' not found.", code="DRIVER_NOT_FOUND")


class DriverNotAvailableError(RideManagementError):
    """Raised when driver is not available for assignment."""

    def __init__(self, driver_id: str, status: str):
        super().__init__(f"Driver '{driver_id}' is not available (status: {status}).", code="DRIVER_NOT_AVAILABLE")


class VehicleNotFoundError(RideManagementError):
    """Raised when requested vehicle cannot be found."""

    def __init__(self, vehicle_id: str):
        super().__init__(f"Vehicle '{vehicle_id}' not found.", code="VEHICLE_NOT_FOUND")


class VehicleNotEligibleError(RideManagementError):
    """Raised when vehicle does not satisfy operational criteria."""

    def __init__(self, reason: str):
        super().__init__(f"Vehicle ineligible: {reason}", code="VEHICLE_INELIGIBLE")


class BookingNotFoundError(RideManagementError):
    """Raised when a booking record does not exist."""

    def __init__(self, booking_id: str):
        super().__init__(f"Booking '{booking_id}' not found.", code="BOOKING_NOT_FOUND")


class ActiveBookingExistsError(RideManagementError):
    """Raised when a passenger tries to book while another ride is active."""

    def __init__(self, passenger_id: str, booking_id: str):
        super().__init__(
            f"Passenger '{passenger_id}' already has an active booking: {booking_id}.",
            code="ACTIVE_BOOKING_EXISTS",
        )


class InvalidStateTransitionError(RideManagementError):
    """Raised when an illegal booking or entity state transition is attempted."""

    def __init__(self, current_state: str, target_state: str):
        super().__init__(
            f"Invalid transition from state '{current_state}' to '{target_state}'.",
            code="INVALID_STATE_TRANSITION",
        )


class NoDriverAvailableError(RideManagementError):
    """Raised when no suitable driver can be dispatched."""

    def __init__(self, message: str = "No eligible drivers available nearby."):
        super().__init__(message, code="NO_DRIVER_AVAILABLE")


class PaymentFailedError(RideManagementError):
    """Raised when a payment transaction fails."""

    def __init__(self, reason: str):
        super().__init__(f"Payment failed: {reason}", code="PAYMENT_FAILED")


class DuplicatePaymentError(RideManagementError):
    """Raised when attempting to pay for an already settled booking."""

    def __init__(self, booking_id: str):
        super().__init__(f"Payment already completed for booking: {booking_id}", code="DUPLICATE_PAYMENT")


class InsufficientBalanceError(RideManagementError):
    """Raised when a wallet or account has insufficient funds."""

    def __init__(self, required: str, available: str):
        super().__init__(
            f"Insufficient funds: required {required}, available {available}",
            code="INSUFFICIENT_BALANCE",
        )


class RefundError(RideManagementError):
    """Raised when refund cannot be issued."""

    def __init__(self, reason: str):
        super().__init__(f"Refund error: {reason}", code="REFUND_ERROR")


class DuplicateRatingError(RideManagementError):
    """Raised when rating has already been recorded for a target by an author."""

    def __init__(self, booking_id: str, author_id: str):
        super().__init__(
            f"Rating for booking '{booking_id}' already submitted by '{author_id}'.",
            code="DUPLICATE_RATING",
        )


class LocationOutOfBoundsError(RideManagementError):
    """Raised when coordinates fall outside permitted operating boundaries."""

    def __init__(self, lat: float, lon: float):
        super().__init__(f"Location ({lat}, {lon}) is out of operating bounds.", code="OUT_OF_BOUNDS")

