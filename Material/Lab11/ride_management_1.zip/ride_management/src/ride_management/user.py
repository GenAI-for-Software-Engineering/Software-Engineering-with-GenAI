"""User registration, authentication, wallet, and lifecycle profile management."""

from decimal import Decimal
from typing import Dict, List, Optional

from ride_management.exceptions import (
    DuplicateUserError,
    InsufficientBalanceError,
    UserInactiveError,
    UserNotFoundError,
    ValidationError,
)
from ride_management.models import UserProfile, UserRole
from ride_management.utils import (
    Clock,
    IdGenerator,
    round_currency,
    validate_email,
    validate_phone,
)


class UserService:
    """Service handling passenger and driver registration, profiles, and wallet operations."""

    def __init__(self, clock: Optional[Clock] = None, id_gen: Optional[IdGenerator] = None):
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._users: Dict[str, UserProfile] = {}
        self._email_index: Dict[str, str] = {}
        self._phone_index: Dict[str, str] = {}

    def register_user(
        self,
        name: str,
        email: str,
        phone: str,
        role: UserRole = UserRole.PASSENGER,
        initial_wallet_balance: Decimal = Decimal("0.00"),
    ) -> UserProfile:
        """Registers a new user in the system after validating contact uniqueness."""
        if not name or not name.strip():
            raise ValidationError("User name cannot be empty.")

        clean_email = validate_email(email)
        clean_phone = validate_phone(phone)

        if clean_email in self._email_index:
            raise DuplicateUserError(f"Email {clean_email}")
        if clean_phone in self._phone_index:
            raise DuplicateUserError(f"Phone {clean_phone}")

        if initial_wallet_balance < Decimal("0.00"):
            raise ValidationError("Initial wallet balance cannot be negative.")

        prefix = "USR-PAS" if role == UserRole.PASSENGER else "USR-DRV"
        user_id = self.id_gen.generate(prefix)

        user = UserProfile(
            user_id=user_id,
            name=name.strip(),
            email=clean_email,
            phone=clean_phone,
            role=role,
            is_active=True,
            wallet_balance=round_currency(initial_wallet_balance),
            created_at=self.clock.now(),
        )

        self._users[user_id] = user
        self._email_index[clean_email] = user_id
        self._phone_index[clean_phone] = user_id
        return user

    def get_user(self, user_id: str) -> UserProfile:
        """Retrieves user profile by user_id."""
        if user_id not in self._users:
            raise UserNotFoundError(user_id)
        return self._users[user_id]

    def get_user_by_email(self, email: str) -> UserProfile:
        """Looks up a user by email address."""
        clean_email = validate_email(email)
        user_id = self._email_index.get(clean_email)
        if not user_id:
            raise UserNotFoundError(f"email={clean_email}")
        return self._users[user_id]

    def get_user_by_phone(self, phone: str) -> UserProfile:
        """Looks up a user by phone number."""
        clean_phone = validate_phone(phone)
        user_id = self._phone_index.get(clean_phone)
        if not user_id:
            raise UserNotFoundError(f"phone={clean_phone}")
        return self._users[user_id]

    def update_profile(
        self,
        user_id: str,
        name: Optional[str] = None,
        email: Optional[str] = None,
        phone: Optional[str] = None,
    ) -> UserProfile:
        """Updates personal details of an existing user."""
        user = self.get_user(user_id)

        if name is not None:
            if not name.strip():
                raise ValidationError("Name cannot be empty.")
            user.name = name.strip()

        if email is not None:
            clean_email = validate_email(email)
            if clean_email != user.email:
                if clean_email in self._email_index:
                    raise DuplicateUserError(f"Email {clean_email}")
                del self._email_index[user.email]
                self._email_index[clean_email] = user_id
                user.email = clean_email

        if phone is not None:
            clean_phone = validate_phone(phone)
            if clean_phone != user.phone:
                if clean_phone in self._phone_index:
                    raise DuplicateUserError(f"Phone {clean_phone}")
                del self._phone_index[user.phone]
                self._phone_index[clean_phone] = user_id
                user.phone = clean_phone

        return user

    def activate_user(self, user_id: str) -> UserProfile:
        """Activates user account."""
        user = self.get_user(user_id)
        user.is_active = True
        return user

    def deactivate_user(self, user_id: str) -> UserProfile:
        """Deactivates user account."""
        user = self.get_user(user_id)
        user.is_active = False
        return user

    def validate_user_active(self, user_id: str) -> UserProfile:
        """Ensures user exists and is currently active."""
        user = self.get_user(user_id)
        if not user.is_active:
            raise UserInactiveError(user_id)
        return user

    def add_wallet_funds(self, user_id: str, amount: Decimal) -> Decimal:
        """Credits funds to user's in-app wallet balance."""
        user = self.validate_user_active(user_id)
        if amount <= Decimal("0.00"):
            raise ValidationError("Credit amount must be positive.")
        user.wallet_balance = round_currency(user.wallet_balance + amount)
        return user.wallet_balance

    def deduct_wallet_funds(self, user_id: str, amount: Decimal) -> Decimal:
        """Debits funds from user's in-app wallet balance."""
        user = self.validate_user_active(user_id)
        if amount <= Decimal("0.00"):
            raise ValidationError("Debit amount must be positive.")
        amount = round_currency(amount)
        if user.wallet_balance < amount:
            raise InsufficientBalanceError(required=str(amount), available=str(user.wallet_balance))
        user.wallet_balance = round_currency(user.wallet_balance - amount)
        return user.wallet_balance

    def list_all_users(self) -> List[UserProfile]:
        """Returns all registered users."""
        return list(self._users.values())

