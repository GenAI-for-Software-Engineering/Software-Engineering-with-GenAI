"""Payment processing, gateway simulation, wallet debits, and transaction ledger."""

from abc import ABC, abstractmethod
from decimal import Decimal
from typing import Dict, List, Optional

from ride_management.booking import BookingService
from ride_management.exceptions import (
    DuplicatePaymentError,
    PaymentFailedError,
    ValidationError,
)
from ride_management.models import (
    BookingStatus,
    PaymentMethod,
    PaymentStatus,
    Transaction,
)
from ride_management.user import UserService
from ride_management.utils import Clock, IdGenerator, round_currency


class PaymentGateway(ABC):
    """Abstract interface for payment gateway providers."""

    @abstractmethod
    def process_charge(self, transaction_id: str, amount: Decimal, details: Dict[str, str]) -> bool:
        """Processes debit charge."""
        pass

    @abstractmethod
    def process_refund(self, original_gateway_ref: str, amount: Decimal) -> bool:
        """Processes refund charge."""
        pass


class MockPaymentGateway(PaymentGateway):
    """Configurable mock payment gateway for testing success and failure branches."""

    def __init__(self, default_should_succeed: bool = True):
        self.default_should_succeed = default_should_succeed
        self.failure_triggers: Dict[str, str] = {}
        self.processed_transactions: List[str] = []

    def set_failure_trigger(self, key: str, reason: str) -> None:
        """Forces failure when specified key is present in transaction details."""
        self.failure_triggers[key] = reason

    def process_charge(self, transaction_id: str, amount: Decimal, details: Dict[str, str]) -> bool:
        """Simulates charging card or external UPI account."""
        self.processed_transactions.append(transaction_id)

        for key, reason in self.failure_triggers.items():
            if key in details or key in details.values():
                return False

        return self.default_should_succeed

    def process_refund(self, original_gateway_ref: str, amount: Decimal) -> bool:
        """Simulates gateway refund."""
        if "FAIL_REFUND" in original_gateway_ref:
            return False
        return True


class PaymentService:
    """Manages payments for rides, refunds, and accounting ledger entries."""

    def __init__(
        self,
        user_service: UserService,
        booking_service: BookingService,
        gateway: Optional[PaymentGateway] = None,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.user_service = user_service
        self.booking_service = booking_service
        self.gateway = gateway or MockPaymentGateway()
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._transactions: Dict[str, Transaction] = {}
        self._booking_transaction_map: Dict[str, str] = {}

    def process_payment(
        self,
        booking_id: str,
        payment_method: PaymentMethod,
        payment_details: Optional[Dict[str, str]] = None,
    ) -> Transaction:
        """Settles payment for completed or cancelled ride with fee."""
        booking = self.booking_service.get_booking(booking_id)

        if booking_id in self._booking_transaction_map:
            raise DuplicatePaymentError(booking_id)

        if not booking.fare_breakdown:
            raise ValidationError("Booking has no calculated fare to pay.")

        amount = booking.fare_breakdown.final_fare
        if amount <= Decimal("0.00"):
            raise ValidationError("Payable amount must be greater than zero.")

        tx_id = self.id_gen.generate("TXN")
        now = self.clock.now()
        details = payment_details or {}

        # Handle Wallet method
        if payment_method == PaymentMethod.WALLET:
            self.user_service.deduct_wallet_funds(booking.passenger_id, amount)
            tx = Transaction(
                transaction_id=tx_id,
                booking_id=booking_id,
                user_id=booking.passenger_id,
                amount=amount,
                payment_method=payment_method,
                status=PaymentStatus.COMPLETED,
                created_at=now,
                gateway_reference=f"WALLET-REF-{tx_id}",
                notes="Paid via in-app wallet balance",
            )
            self._transactions[tx_id] = tx
            self._booking_transaction_map[booking_id] = tx_id
            return tx

        # Handle Cash method
        if payment_method == PaymentMethod.CASH:
            tx = Transaction(
                transaction_id=tx_id,
                booking_id=booking_id,
                user_id=booking.passenger_id,
                amount=amount,
                payment_method=payment_method,
                status=PaymentStatus.COMPLETED,
                created_at=now,
                gateway_reference="CASH-COLLECTED",
                notes="Cash collected by driver",
            )
            self._transactions[tx_id] = tx
            self._booking_transaction_map[booking_id] = tx_id
            return tx

        # External Gateway (CARD, UPI)
        gateway_success = self.gateway.process_charge(tx_id, amount, details)
        if not gateway_success:
            tx = Transaction(
                transaction_id=tx_id,
                booking_id=booking_id,
                user_id=booking.passenger_id,
                amount=amount,
                payment_method=payment_method,
                status=PaymentStatus.FAILED,
                created_at=now,
                notes="Gateway transaction rejected",
            )
            self._transactions[tx_id] = tx
            raise PaymentFailedError("Payment gateway declined transaction.")

        gw_ref = f"GW-{tx_id}"
        tx = Transaction(
            transaction_id=tx_id,
            booking_id=booking_id,
            user_id=booking.passenger_id,
            amount=amount,
            payment_method=payment_method,
            status=PaymentStatus.COMPLETED,
            created_at=now,
            gateway_reference=gw_ref,
            notes="Payment processed successfully",
        )
        self._transactions[tx_id] = tx
        self._booking_transaction_map[booking_id] = tx_id
        return tx

    def get_transaction(self, transaction_id: str) -> Transaction:
        """Retrieves transaction by ID."""
        if transaction_id not in self._transactions:
            raise ValidationError(f"Transaction '{transaction_id}' not found.")
        return self._transactions[transaction_id]

    def get_transaction_by_booking(self, booking_id: str) -> Optional[Transaction]:
        """Retrieves payment record associated with a booking."""
        tx_id = self._booking_transaction_map.get(booking_id)
        if not tx_id:
            return None
        return self._transactions.get(tx_id)

    def list_user_transactions(self, user_id: str) -> List[Transaction]:
        """Returns all transactions executed by given user."""
        return [t for t in self._transactions.values() if t.user_id == user_id]

