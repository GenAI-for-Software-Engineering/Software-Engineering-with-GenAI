"""Deterministic driver allocation, proximity matching, category filtering, and rejection retry."""

from dataclasses import dataclass
from typing import List, Optional, Set

from ride_management.booking import BookingService
from ride_management.driver import DriverService
from ride_management.exceptions import NoDriverAvailableError, ValidationError
from ride_management.location import LocationService
from ride_management.models import Booking, Coordinates, DriverProfile, DriverStatus, VehicleCategory
from ride_management.vehicle import VehicleService


@dataclass
class CandidateDriver:
    """Evaluated driver candidate with calculated pickup distance."""
    driver_id: str
    distance_km: float
    rating: float


class DispatchService:
    """Coordinates deterministic driver search, allocation, and rejection reassignment."""

    def __init__(
        self,
        driver_service: DriverService,
        vehicle_service: VehicleService,
        booking_service: BookingService,
        location_service: LocationService,
        max_search_radius_km: float = 15.0,
    ):
        self.driver_service = driver_service
        self.vehicle_service = vehicle_service
        self.booking_service = booking_service
        self.location_service = location_service
        self.max_search_radius_km = max_search_radius_km

    def find_eligible_drivers(
        self,
        pickup: Coordinates,
        category: VehicleCategory,
        excluded_driver_ids: Optional[Set[str]] = None,
    ) -> List[CandidateDriver]:
        """Finds and ranks all eligible drivers within search radius deterministically."""
        excluded = excluded_driver_ids or set()
        candidates: List[CandidateDriver] = []

        available_drivers = self.driver_service.list_available_drivers()

        for driver in available_drivers:
            if driver.driver_id in excluded:
                continue

            vehicle = self.vehicle_service.get_vehicle_by_driver(driver.driver_id)
            if not vehicle or vehicle.category != category:
                continue

            if not driver.current_location:
                continue

            dist = self.location_service.calculate_distance(driver.current_location, pickup)
            if dist <= self.max_search_radius_km:
                candidates.append(
                    CandidateDriver(
                        driver_id=driver.driver_id,
                        distance_km=dist,
                        rating=driver.rating,
                    )
                )

        # Deterministic ranking:
        # 1. Shortest distance to pickup (ascending)
        # 2. Higher driver rating (descending)
        # 3. Alphabetical driver ID for tie-breaker
        candidates.sort(key=lambda c: (c.distance_km, -c.rating, c.driver_id))
        return candidates

    def allocate_driver(
        self,
        booking_id: str,
        excluded_driver_ids: Optional[Set[str]] = None,
    ) -> DriverProfile:
        """Finds best matching driver and assigns them to the ride."""
        booking = self.booking_service.get_booking(booking_id)

        candidates = self.find_eligible_drivers(
            pickup=booking.pickup_location,
            category=booking.category,
            excluded_driver_ids=excluded_driver_ids,
        )

        if not candidates:
            raise NoDriverAvailableError(
                f"No eligible {booking.category.value} driver found within {self.max_search_radius_km} km."
            )

        best_candidate = candidates[0]
        driver = self.driver_service.get_driver(best_candidate.driver_id)

        # Reserve driver
        self.driver_service.update_status(driver.driver_id, DriverStatus.BUSY)
        self.booking_service.assign_driver(booking.booking_id, driver.driver_id)
        return driver

    def handle_driver_rejection(
        self,
        booking_id: str,
        rejecting_driver_id: str,
        rejected_driver_history: Optional[Set[str]] = None,
    ) -> DriverProfile:
        """Handles driver rejecting ride offer and reassigns to the next best driver."""
        booking = self.booking_service.get_booking(booking_id)

        if booking.driver_id != rejecting_driver_id:
            raise ValidationError(f"Driver '{rejecting_driver_id}' is not currently assigned to this booking.")

        # Free up the rejecting driver
        self.driver_service.update_status(rejecting_driver_id, DriverStatus.AVAILABLE)

        history = set(rejected_driver_history) if rejected_driver_history else set()
        history.add(rejecting_driver_id)

        # Reset booking state to REQUESTED so it can be assigned again
        from ride_management.models import BookingStatus
        booking.status = BookingStatus.REQUESTED
        booking.driver_id = None
        self.booking_service._driver_active_booking.pop(rejecting_driver_id, None)

        return self.allocate_driver(booking_id, excluded_driver_ids=history)

