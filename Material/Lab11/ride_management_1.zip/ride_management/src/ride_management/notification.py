"""Notification delivery services with mockable SMS and Email interfaces."""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional

from ride_management.exceptions import ValidationError
from ride_management.models import NotificationMessage
from ride_management.utils import Clock, IdGenerator


class NotificationChannel(ABC):
    """Abstract interface for messaging channels (SMS, Email, Push)."""

    @abstractmethod
    def send(self, recipient: str, subject: str, message: str) -> bool:
        """Sends a notification payload."""
        pass


class MockSmsService(NotificationChannel):
    """Mock SMS gateway capturing sent text messages."""

    def __init__(self, should_succeed: bool = True):
        self.should_succeed = should_succeed
        self.sent_messages: List[Dict[str, str]] = []

    def send(self, recipient: str, subject: str, message: str) -> bool:
        """Appends message to sent log."""
        if not self.should_succeed or "FAIL" in recipient:
            return False
        self.sent_messages.append({"recipient": recipient, "subject": subject, "body": message})
        return True


class MockEmailService(NotificationChannel):
    """Mock Email gateway capturing sent emails."""

    def __init__(self, should_succeed: bool = True):
        self.should_succeed = should_succeed
        self.sent_emails: List[Dict[str, str]] = []

    def send(self, recipient: str, subject: str, message: str) -> bool:
        """Appends email to sent log."""
        if not self.should_succeed or "fail" in recipient.lower():
            return False
        self.sent_emails.append({"recipient": recipient, "subject": subject, "body": message})
        return True


class NotificationService:
    """Manages dispatching system alerts, ride updates, receipts, and refund notices."""

    def __init__(
        self,
        sms_channel: Optional[NotificationChannel] = None,
        email_channel: Optional[NotificationChannel] = None,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
    ):
        self.sms_channel = sms_channel or MockSmsService()
        self.email_channel = email_channel or MockEmailService()
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self._history: List[NotificationMessage] = []

    def notify(
        self,
        recipient_id: str,
        contact_point: str,
        channel: str,
        subject: str,
        body: str,
    ) -> NotificationMessage:
        """Dispatches an alert through specified channel."""
        if not recipient_id or not contact_point or not body:
            raise ValidationError("Recipient ID, contact point, and body cannot be empty.")

        channel_upper = channel.strip().upper()
        if channel_upper == "SMS":
            success = self.sms_channel.send(contact_point, subject, body)
        elif channel_upper == "EMAIL":
            success = self.email_channel.send(contact_point, subject, body)
        else:
            raise ValidationError(f"Unsupported notification channel: '{channel}'.")

        msg = NotificationMessage(
            notification_id=self.id_gen.generate("NOTIF"),
            recipient_id=recipient_id,
            channel=channel_upper,
            subject=subject,
            body=body,
            sent_at=self.clock.now(),
            success=success,
        )
        self._history.append(msg)
        return msg

    def notify_booking_created(self, passenger_id: str, phone: str, booking_id: str) -> NotificationMessage:
        """Alerts passenger that ride has been requested."""
        return self.notify(
            recipient_id=passenger_id,
            contact_point=phone,
            channel="SMS",
            subject="Ride Requested",
            body=f"Your ride request #{booking_id} has been received. Finding nearby drivers...",
        )

    def notify_driver_assigned(
        self,
        passenger_id: str,
        phone: str,
        booking_id: str,
        driver_name: str,
        reg_num: str,
    ) -> NotificationMessage:
        """Alerts passenger about assigned driver and vehicle."""
        return self.notify(
            recipient_id=passenger_id,
            contact_point=phone,
            channel="SMS",
            subject="Driver Assigned",
            body=f"Driver {driver_name} ({reg_num}) has accepted your ride #{booking_id}.",
        )

    def notify_driver_arrived(self, passenger_id: str, phone: str, booking_id: str) -> NotificationMessage:
        """Alerts passenger that driver has arrived at pickup."""
        return self.notify(
            recipient_id=passenger_id,
            contact_point=phone,
            channel="SMS",
            subject="Driver Arrived",
            body=f"Your driver has arrived at the pickup location for ride #{booking_id}.",
        )

    def notify_ride_completed(
        self,
        passenger_id: str,
        email: str,
        booking_id: str,
        amount: str,
    ) -> NotificationMessage:
        """Sends final trip receipt via email."""
        return self.notify(
            recipient_id=passenger_id,
            contact_point=email,
            channel="EMAIL",
            subject=f"Ride Receipt: {booking_id}",
            body=f"Thank you for riding with us! Total fare charged: {amount}.",
        )

    def notify_cancellation(
        self,
        user_id: str,
        contact_point: str,
        channel: str,
        booking_id: str,
        fee: str,
    ) -> NotificationMessage:
        """Notifies user of ride cancellation and fee breakdown."""
        return self.notify(
            recipient_id=user_id,
            contact_point=contact_point,
            channel=channel,
            subject="Ride Cancelled",
            body=f"Booking #{booking_id} was cancelled. Applicable cancellation fee: {fee}.",
        )

    def get_notification_history(self, recipient_id: Optional[str] = None) -> List[NotificationMessage]:
        """Filters sent message history by recipient."""
        if recipient_id is None:
            return list(self._history)
        return [m for m in self._history if m.recipient_id == recipient_id]

