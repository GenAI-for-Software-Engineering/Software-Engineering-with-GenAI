"""Top-level facade system integrating all modular services into a cohesive backend platform."""

from decimal import Decimal
from typing import Any, Dict, List, Optional, Set

from ride_management.analytics import AnalyticsService
from ride_management.booking import BookingService
from ride_management.cancellation import CancellationService
from ride_management.dispatch import DispatchService
from ride_management.driver import DriverService
from ride_management.exceptions import ValidationError
from ride_management.location import LocationService
from ride_management.models import (
    Booking,
    BookingStatus,
    CancellationParty,
    Coordinates,
    DriverProfile,
    DriverStatus,
    FareBreakdown,
    PaymentMethod,
    RatingRecord,
    Transaction,
    UserProfile,
    UserRole,
    Vehicle,
    VehicleCategory,
)
from ride_management.notification import NotificationService
from ride_management.payment import MockPaymentGateway, PaymentGateway, PaymentService
from ride_management.pricing import PricingService
from ride_management.rating import RatingService
from ride_management.user import UserService
from ride_management.utils import Clock, IdGenerator
from ride_management.vehicle import VehicleService


class RideManagementSystem:
    """Unified facade exposing all ride-hailing backend operations for clean orchestration and testing."""

    def __init__(
        self,
        clock: Optional[Clock] = None,
        id_gen: Optional[IdGenerator] = None,
        payment_gateway: Optional[PaymentGateway] = None,
    ):
        self.clock = clock or Clock()
        self.id_gen = id_gen or IdGenerator()
        self.gateway = payment_gateway or MockPaymentGateway()

        # Initialize core services in dependency order
        self.location_service = LocationService()
        self.user_service = UserService(clock=self.clock, id_gen=self.id_gen)
        self.vehicle_service = VehicleService(id_gen=self.id_gen)
        self.driver_service = DriverService(vehicle_service=self.vehicle_service)
        self.pricing_service = PricingService()
        self.booking_service = BookingService(
            user_service=self.user_service,
            location_service=self.location_service,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.dispatch_service = DispatchService(
            driver_service=self.driver_service,
            vehicle_service=self.vehicle_service,
            booking_service=self.booking_service,
            location_service=self.location_service,
        )
        self.payment_service = PaymentService(
            user_service=self.user_service,
            booking_service=self.booking_service,
            gateway=self.gateway,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.cancellation_service = CancellationService(
            booking_service=self.booking_service,
            driver_service=self.driver_service,
            payment_service=self.payment_service,
            user_service=self.user_service,
            gateway=self.gateway,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.rating_service = RatingService(
            booking_service=self.booking_service,
            driver_service=self.driver_service,
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.notification_service = NotificationService(
            clock=self.clock,
            id_gen=self.id_gen,
        )
        self.analytics_service = AnalyticsService(
            booking_service=self.booking_service,
        )

    # --- High-level workflows ---

    def register_passenger(
        self,
        name: str,
        email: str,
        phone: str,
        initial_wallet: Decimal = Decimal("0.00"),
    ) -> UserProfile:
        """Registers a new passenger."""
        return self.user_service.register_user(
            name=name,
            email=email,
            phone=phone,
            role=UserRole.PASSENGER,
            initial_wallet_balance=initial_wallet,
        )

    def register_driver_with_vehicle(
        self,
        name: str,
        email: str,
        phone: str,
        license_number: str,
        vehicle_reg: str,
        vehicle_make: str,
        vehicle_model: str,
        vehicle_category: VehicleCategory,
        vehicle_year: int,
        initial_location: Coordinates,
    ) -> Dict[str, Any]:
        """Convenience method registering a driver, vehicle, and setting initial status."""
        user = self.user_service.register_user(
            name=name,
            email=email,
            phone=phone,
            role=UserRole.DRIVER,
        )

        vehicle = self.vehicle_service.register_vehicle(
            registration_number=vehicle_reg,
            make=vehicle_make,
            model=vehicle_model,
            category=vehicle_category,
            year=vehicle_year,
            driver_id=user.user_id,
        )

        driver = self.driver_service.register_driver(
            driver_id=user.user_id,
            license_number=license_number,
            initial_location=initial_location,
        )

        # Automatic verification and activation to available
        self.driver_service.verify_driver(driver.driver_id)
        self.driver_service.update_status(driver.driver_id, DriverStatus.AVAILABLE)

        return {
            "user": user,
            "driver": driver,
            "vehicle": vehicle,
        }

    def request_ride(
        self,
        passenger_id: str,
        pickup: Coordinates,
        destination: Coordinates,
        category: VehicleCategory,
        auto_dispatch: bool = True,
    ) -> Booking:
        """Creates a booking and optionally dispatches the nearest eligible driver."""
        booking = self.booking_service.create_booking(
            passenger_id=passenger_id,
            pickup=pickup,
            destination=destination,
            category=category,
        )

        passenger = self.user_service.get_user(passenger_id)
        self.notification_service.notify_booking_created(
            passenger_id=passenger_id,
            phone=passenger.phone,
            booking_id=booking.booking_id,
        )

        if auto_dispatch:
            assigned_driver = self.dispatch_service.allocate_driver(booking.booking_id)
            vehicle = self.vehicle_service.get_vehicle_by_driver(assigned_driver.driver_id)
            reg_num = vehicle.registration_number if vehicle else "UNKNOWN"
            driver_user = self.user_service.get_user(assigned_driver.driver_id)

            self.notification_service.notify_driver_assigned(
                passenger_id=passenger_id,
                phone=passenger.phone,
                booking_id=booking.booking_id,
                driver_name=driver_user.name,
                reg_num=reg_num,
            )

        return booking

    def simulate_complete_trip(
        self,
        booking_id: str,
        payment_method: PaymentMethod,
        actual_distance_km: Optional[float] = None,
        actual_duration_min: Optional[float] = None,
        coupon_code: Optional[str] = None,
        passenger_rating_score: Optional[int] = None,
        driver_rating_score: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Simulates full end-to-end trip progression: accept, arrive, start, complete, pay, and rate."""
        booking = self.booking_service.get_booking(booking_id)
        driver_id = booking.driver_id
        if not driver_id:
            raise ValidationError("Booking has no assigned driver to simulate trip.")

        driver_user = self.user_service.get_user(driver_id)
        passenger_user = self.user_service.get_user(booking.passenger_id)

        # 1. Driver accepts
        self.booking_service.driver_accept(booking_id, driver_id)

        # 2. Driver arrives at pickup
        self.booking_service.driver_arrive(booking_id, driver_id)
        self.notification_service.notify_driver_arrived(
            passenger_id=booking.passenger_id,
            phone=passenger_user.phone,
            booking_id=booking_id,
        )

        # 3. Ride starts
        self.booking_service.start_ride(booking_id, driver_id)

        # 4. Calculate actual fare
        dist = actual_distance_km if actual_distance_km is not None else booking.distance_km
        duration = actual_duration_min if actual_duration_min is not None else booking.duration_minutes
        fare_breakdown = self.pricing_service.calculate_fare(
            category=booking.category,
            distance_km=dist,
            duration_minutes=duration,
            coupon_code=coupon_code,
            booking_time=self.clock.now(),
        )

        # 5. Complete ride
        completed_booking = self.booking_service.complete_ride(
            booking_id=booking_id,
            driver_id=driver_id,
            fare_breakdown=fare_breakdown,
            actual_distance_km=dist,
            actual_duration_min=duration,
        )

        # Return driver to available
        self.driver_service.update_status(driver_id, DriverStatus.AVAILABLE)

        # 6. Settle payment
        transaction = self.payment_service.process_payment(
            booking_id=booking_id,
            payment_method=payment_method,
        )

        # 7. Notify completion
        self.notification_service.notify_ride_completed(
            passenger_id=booking.passenger_id,
            email=passenger_user.email,
            booking_id=booking_id,
            amount=f"₹{fare_breakdown.final_fare:.2f}",
        )

        # 8. Optional two-way ratings
        p_rating = None
        d_rating = None
        if passenger_rating_score is not None:
            p_rating = self.rating_service.rate_driver(
                booking_id=booking_id,
                passenger_id=booking.passenger_id,
                score=passenger_rating_score,
            )
        if driver_rating_score is not None:
            d_rating = self.rating_service.rate_passenger(
                booking_id=booking_id,
                driver_id=driver_id,
                score=driver_rating_score,
            )

        return {
            "booking": completed_booking,
            "fare": fare_breakdown,
            "transaction": transaction,
            "passenger_rating": p_rating,
            "driver_rating": d_rating,
        }
