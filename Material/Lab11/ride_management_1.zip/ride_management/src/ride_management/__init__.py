"""Ride Management System package entry point."""

from ride_management.analytics import AnalyticsService
from ride_management.booking import BookingService
from ride_management.cancellation import CancellationService
from ride_management.dispatch import DispatchService
from ride_management.driver import DriverService
from ride_management.exceptions import (
    ActiveBookingExistsError,
    BookingNotFoundError,
    DriverNotAvailableError,
    DriverNotFoundError,
    DuplicatePaymentError,
    DuplicateRatingError,
    DuplicateUserError,
    InsufficientBalanceError,
    InvalidStateTransitionError,
    LocationOutOfBoundsError,
    NoDriverAvailableError,
    PaymentFailedError,
    RefundError,
    RideManagementError,
    UserInactiveError,
    UserNotFoundError,
    ValidationError,
    VehicleNotEligibleError,
    VehicleNotFoundError,
)
from ride_management.location import LocationService
from ride_management.models import (
    Booking,
    BookingStatus,
    CancellationParty,
    Coordinates,
    DriverProfile,
    DriverStatus,
    FareBreakdown,
    PaymentMethod,
    PaymentStatus,
    RatingRecord,
    Transaction,
    UserProfile,
    UserRole,
    Vehicle,
    VehicleCategory,
    VehicleStatus,
)
from ride_management.notification import (
    MockEmailService,
    MockSmsService,
    NotificationChannel,
    NotificationService,
)
from ride_management.payment import (
    MockPaymentGateway,
    PaymentGateway,
    PaymentService,
)
from ride_management.pricing import PricingService
from ride_management.system import RideManagementSystem
from ride_management.user import UserService
from ride_management.utils import Clock, IdGenerator, format_currency, round_currency
from ride_management.vehicle import VehicleService

__all__ = [
    # Top-level Orchestrator
    "RideManagementSystem",
    # Core domain models and enums
    "Booking",
    "BookingStatus",
    "CancellationParty",
    "Coordinates",
    "DriverProfile",
    "DriverStatus",
    "FareBreakdown",
    "PaymentMethod",
    "PaymentStatus",
    "RatingRecord",
    "Transaction",
    "UserProfile",
    "UserRole",
    "Vehicle",
    "VehicleCategory",
    "VehicleStatus",
    # Services
    "AnalyticsService",
    "BookingService",
    "CancellationService",
    "DispatchService",
    "DriverService",
    "LocationService",
    "NotificationService",
    "PaymentService",
    "PricingService",
    "UserService",
    "VehicleService",
    # Adapters / Mocks
    "MockEmailService",
    "MockPaymentGateway",
    "MockSmsService",
    "NotificationChannel",
    "PaymentGateway",
    # Utilities
    "Clock",
    "IdGenerator",
    "format_currency",
    "round_currency",
    # Exceptions
    "ActiveBookingExistsError",
    "BookingNotFoundError",
    "DriverNotAvailableError",
    "DriverNotFoundError",
    "DuplicatePaymentError",
    "DuplicateRatingError",
    "DuplicateUserError",
    "InsufficientBalanceError",
    "InvalidStateTransitionError",
    "LocationOutOfBoundsError",
    "NoDriverAvailableError",
    "PaymentFailedError",
    "RefundError",
    "RideManagementError",
    "UserInactiveError",
    "UserNotFoundError",
    "ValidationError",
    "VehicleNotEligibleError",
    "VehicleNotFoundError",
]

