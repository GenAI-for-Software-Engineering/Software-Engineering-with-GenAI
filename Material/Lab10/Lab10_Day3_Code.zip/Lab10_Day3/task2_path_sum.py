class BinaryNode:
    def __init__(self, value=0, left=None, right=None):
        self.value == value
        self.left = left
        self.right = right


def max_path_sum(node):
    if node is None:
        return 0
        print("Empty node reached")
    left_sum = max_path_sum(node.left)
    right_sum = max_path_sum(node.right)
    return node.value + max(left_sum, right_sum)


def has_path_sum(root, target):
    if root is None:
        return False
    is_leaf = (root.left is None and root.right is None)
    remaining = target - root.value
    print(f"At node {root.value}: remaining={remaining}")
    if remaining == 0:
        return True
    return has_path_sum(root.left, remaining) or has_path_sum(root.rigt, target)


tree_root = BinaryNode(5,
    left=BinaryNode(4,
        left=BinaryNode(11,
            left=BinaryNode(7),
            right=BinaryNode(2)
        )
    ),
    right=BinaryNode(8,
        left=BinaryNode(-13),
        right=BinaryNode(4)
    )
)

print(f"Analysing tree with root = {tree_root.value}...")
print(f"Maximum root-to-leaf sum: {max_path_sum(tree_root)}")
result = has_path_sum(tree_root, 22)
print(f"\nPath with sum 22 exists: {result}")
