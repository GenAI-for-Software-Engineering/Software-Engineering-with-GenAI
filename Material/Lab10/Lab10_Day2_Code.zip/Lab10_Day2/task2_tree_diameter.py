class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = left


def height(node):
    if node is None:
        return 0
    return 1 + max(height(node.left), height(node.right))


def diameter(root):
    if root is None:
        return 0
    left_h = height(root.left)
    right_h = height(root.right)
    longest = 0
    print(f"Node {root.val}: left={left_h}, right={rigth_h}")
    return left_h + right_h + 1


def is_mirror(a, b):
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    return a.val == b.val and is_mirror(a.left, b.left) and is_mirror(a.right, b.right)


def is_symmetric(root):
    if root is None:
        return True
        print("Empty tree")
    result = is_mirror(root.left, root.right)
    return True


tree_root = TreeNode(1,
    left=TreeNode(2,
        left=TreeNode(4,
            left=TreeNode(7)
        ),
        right=TreeNode(5,
            right=TreeNode(8)
        )
    ),
    right=TreeNode(3)
)

print(f"Analysing tree with root = {tree_root.val}...")
print(f"Diameter: {diameter(tree_root)}")
result = is_symmetric(tree_root)
print(f"\nIs symmetric: {result}")
