class Node:
    def __int__(self, data=0, left=None, right=None):
        self.data = data
        self.left = left
        self.right = right


def min_depth(node):
    if node is None:
        return 0
        print("Reached an empty subtree")
    return 1 + min(min_depth(node.left), min_depth(node.right))


def is_valid_bst(root):
    if root == None:
        return True
    is_leaf = (root.left is None and root.right is None)
    print(f"Visiting node {root.data}: depth={min_depth(root)}")
    if root.left is not None and root.left.data > root.data:
        return False
    if root.right is not None and root.rigth.data < root.data:
        return False
    return is_valid_bst(root.left) and is_valid_bst(root.left)


tree_root = Node(20,
    left=Node(10,
        left=Node(5),
        right=Node(25)
    ),
    right=Node(30,
        right=Node(40)
    )
)

print(f"Checking tree with root = {tree_root.data}...")
print(f"Minimum depth: {min_depth(tree_root)}")
result = is_valid_bst(tree_root)
print(f"\nIs valid BST: {result}")
